import Link from "next/link";
import { getPublicSchoolInfo } from "@/lib/publicSchoolInfo";

export const metadata = {
  title: "Panduan Pengguna - SIMMAS",
  description: "Panduan singkat penggunaan SIMMAS untuk Admin, Guru, Siswa, dan DUDI.",
};

const sections = [
  {
    icon: "👨‍💼",
    role: "Admin",
    color: "#38bdf8",
    steps: [
      "Login menggunakan akun admin yang telah disediakan.",
      "Kelola data Siswa, Guru, dan DUDI lewat menu masing-masing di sidebar.",
      "Tempatkan siswa ke DUDI dan guru pembimbing lewat menu Magang.",
      "Atur nama sekolah, logo, dan template sertifikat PKL lewat menu Pengaturan.",
      "Pantau seluruh aktivitas perubahan data lewat menu Activity Logs.",
    ],
  },
  {
    icon: "👨‍🏫",
    role: "Guru",
    color: "#a78bfa",
    steps: [
      "Login menggunakan akun guru yang telah didaftarkan admin.",
      "Tinjau pendaftaran magang siswa bimbingan pada menu Magang — terima atau tolak lengkap dengan catatan.",
      "Periksa dan setujui/tolak jurnal harian siswa bimbingan pada menu Jurnal.",
      "Berikan nilai akhir (0-100) setelah masa magang siswa selesai.",
      "Perbarui status magang (aktif/selesai/dibatalkan) sesuai perkembangan siswa.",
    ],
  },
  {
    icon: "🎓",
    role: "Siswa",
    color: "#34d399",
    steps: [
      "Login menggunakan akun yang telah didaftarkan admin/wali kelas.",
      "Daftar ke tempat magang (DUDI) yang tersedia lewat menu Magang.",
      "Isi jurnal kegiatan harian secara rutin lewat menu Jurnal, lampirkan dokumen pendukung jika perlu.",
      "Pantau status pendaftaran dan magang lewat Dashboard.",
      "Unduh sertifikat PKL setelah status magang berubah menjadi \"Selesai\" dan sertifikat tersedia.",
    ],
  },
  {
    icon: "🏢",
    role: "DUDI (Perusahaan Mitra)",
    color: "#fb923c",
    steps: [
      "Login menggunakan akun perusahaan yang dibuatkan admin sekolah.",
      "Pantau siswa yang sedang magang di perusahaan Anda lewat Dashboard.",
      "Lihat jurnal harian siswa magang lewat menu Jurnal.",
      "Berikan evaluasi akhir berupa catatan dan nilai (0-100) untuk setiap siswa.",
    ],
  },
];

const faqs = [
  {
    q: "Saya lupa password, bagaimana cara reset?",
    a: "Klik \"Lupa password?\" di halaman login, masukkan email akun Anda, lalu ikuti link reset yang diberikan. Fitur ini tersedia untuk semua jenis akun, termasuk akun DUDI.",
  },
  {
    q: "Format email apa yang bisa dipakai untuk login?",
    a: "Email apa saja dengan format yang valid (mis. nama@gmail.com atau nama@sekolah.sch.id) bisa dipakai, selama email tersebut sudah didaftarkan oleh admin sekolah ke akun Anda.",
  },
  {
    q: "Kenapa sertifikat PKL saya belum bisa diunduh?",
    a: "Sertifikat hanya tersedia setelah status magang Anda berubah menjadi \"Selesai\" DAN admin sekolah sudah mengunggah template sertifikat. Jika sudah memenuhi syarat tapi masih gagal, hubungi admin sekolah.",
  },
  {
    q: "Saya guru, tapi tidak melihat siswa bimbingan saya. Kenapa?",
    a: "Pastikan akun Anda sudah ditautkan dengan benar oleh admin lewat menu Manajemen Guru, dan siswa tersebut sudah ditempatkan dengan Anda sebagai guru pembimbing lewat menu Magang.",
  },
];

export default async function PanduanPenggunaPage() {
  // Perbaikan Bug #12 (konsisten dengan halaman publik lainnya): ambil nama
  // sekolah dari database, bukan hardcode.
  const school = await getPublicSchoolInfo();
  const schoolName = school?.nama || "Sekolah";

  return (
    <div className="landing-page">
      <nav className="landing-nav">
        <div className="landing-nav-inner">
          <div className="landing-nav-brand">
            <div className="logo-circle" style={{ display: "flex", justifyContent: "center", alignItems: "center", background: "transparent" }}>
              <img
                src="/logo.png.webp"
                alt={`Logo ${schoolName}`}
                style={{ width: "30px", height: "auto", objectFit: "contain" }}
              />
            </div>
            <span>SIMMAS</span>
          </div>
          <div className="landing-nav-links">
            <Link href="/#features">Fitur</Link>
            <Link href="/#how-it-works">Cara Kerja</Link>
            <Link href="/panduan">Panduan</Link>
          </div>
          <Link href="/login" className="landing-nav-cta">
            Masuk →
          </Link>
        </div>
      </nav>

      <section className="landing-hero" id="home" style={{ paddingBottom: 40 }}>
        <div className="landing-hero-badge">Panduan Pengguna</div>
        <h1 className="landing-hero-title">
          Panduan Singkat<br />
          <span>Menggunakan SIMMAS</span>
        </h1>
        <p className="landing-hero-desc">
          Ringkasan langkah-langkah dasar untuk masing-masing peran pengguna di {schoolName}.
          Untuk bantuan lebih lanjut, hubungi admin sekolah Anda.
        </p>
      </section>

      <section className="landing-section" id="panduan-role">
        <div className="landing-section-inner">
          <div className="landing-section-header">
            <div className="landing-section-badge">Per Peran</div>
            <h2>Cara Menggunakan SIMMAS</h2>
          </div>
          <div className="landing-benefits-grid">
            {sections.map((s) => (
              <div className="landing-benefit-card" key={s.role}>
                <div className="landing-benefit-icon" style={{ background: s.color + "22", color: s.color }}>
                  {s.icon}
                </div>
                <h3>{s.role}</h3>
                <ul>
                  {s.steps.map((step, i) => (
                    <li key={i}>
                      <span className="landing-check" style={{ color: s.color }}>✓</span>
                      {step}
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="landing-section landing-section-dark" id="panduan-faq">
        <div className="landing-section-inner">
          <div className="landing-section-header">
            <div className="landing-section-badge">FAQ</div>
            <h2>Pertanyaan yang Sering Ditanyakan</h2>
          </div>
          <div className="landing-features-grid">
            {faqs.map((f) => (
              <div className="landing-feature-card" key={f.q}>
                <h3 style={{ fontSize: 16 }}>{f.q}</h3>
                <p>{f.a}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="landing-cta-section">
        <div className="landing-cta-inner">
          <h2>Siap Mulai Menggunakan SIMMAS?</h2>
          <p>Masuk dengan akun yang sudah didaftarkan admin sekolah Anda.</p>
          <Link href="/login" className="landing-btn-white">
            Ke Halaman Login →
          </Link>
        </div>
      </section>

      <footer className="landing-footer">
        <div className="landing-footer-bottom" style={{ borderTop: "none", paddingTop: 0 }}>
          <span>© {new Date().getFullYear()} SIMMAS — {schoolName}. All rights reserved.</span>
        </div>
      </footer>
    </div>
  );
}
