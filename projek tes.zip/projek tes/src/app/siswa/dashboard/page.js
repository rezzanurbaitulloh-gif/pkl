import { getCurrentSiswa } from "@/lib/auth";
import { query } from "@/lib/db";
import { formatDate } from "@/lib/utils";
import Badge from "@/components/Badge";
import Link from "next/link";

export const dynamic = "force-dynamic";

export default async function DashboardPage() {
  const siswa = await getCurrentSiswa();

  const jurnalStats = await query(
    `SELECT
      COUNT(*) as total,
      SUM(status = 'disetujui') as disetujui,
      SUM(status = 'menunggu') as menunggu,
      SUM(status = 'ditolak') as ditolak
     FROM jurnal WHERE siswa_id = ?`,
    [siswa.id]
  );

  const magangRows = await query(
    `SELECT m.*, d.nama as dudi_nama, d.alamat as dudi_alamat, g.nama as guru_nama, g.mapel as guru_mapel
     FROM magang m
     LEFT JOIN dudi d ON d.id = m.dudi_id
     LEFT JOIN guru g ON g.id = m.guru_id
     WHERE m.siswa_id = ? ORDER BY m.id DESC LIMIT 1`,
    [siswa.id]
  );

  const pendaftaranRows = await query(
    `SELECT p.*, d.nama as dudi_nama, d.alamat as dudi_alamat, g.nama as guru_nama
     FROM pendaftaran p
     LEFT JOIN dudi d ON d.id = p.dudi_id
     LEFT JOIN guru g ON g.id = p.guru_id
     WHERE p.siswa_id = ? AND p.status = 'pending'
     ORDER BY p.id DESC LIMIT 1`,
    [siswa.id]
  );

  const recentJurnal = await query(
    `SELECT * FROM jurnal WHERE siswa_id = ? ORDER BY tanggal DESC, id DESC LIMIT 5`,
    [siswa.id]
  );

  const stats = jurnalStats[0] || {};
  const magang = magangRows[0] || null;
  const pendaftaran = pendaftaranRows[0] || null;

  const today = new Date().toLocaleDateString("id-ID", {
    day: "numeric",
    month: "long",
    year: "numeric",
  });

  return (
    <div className="page">
      <div className="welcome-banner">
        <div>
          <h2>Selamat Datang, {siswa.nama}! 👋</h2>
          <p>
            {siswa.nis} • {siswa.kelas} • {siswa.jurusan}
          </p>
        </div>
        <div className="welcome-date">📅 {today}</div>
      </div>

      <div className="stat-grid">
        <StatCard icon="📄" label="Total Jurnal" sub="Jurnal yang dibuat" value={stats.total || 0} />
        <StatCard icon="✅" label="Disetujui" sub="Jurnal disetujui" value={stats.disetujui || 0} />
        <StatCard icon="⏱️" label="Pending" sub="Menunggu verifikasi" value={stats.menunggu || 0} />
        <StatCard icon="⛔" label="Ditolak" sub="Jurnal ditolak" value={stats.ditolak || 0} />
      </div>

      <div className="dashboard-cols">
        <div className="card">
          <div className="card-header"><h3>🏢 Informasi Magang</h3></div>
          <div className="card-body">
            {magang ? (
              <>
                <div className="info-row">
                  <div className="info-box">
                    <div className="info-icon">🏢</div>
                    <div>
                      <div className="info-label">Tempat Magang</div>
                      <div className="info-title">{magang.dudi_nama || "-"}</div>
                      <div className="info-desc">{magang.dudi_alamat || "-"}</div>
                    </div>
                  </div>
                  <div className="info-box">
                    <div className="info-icon">👤</div>
                    <div>
                      <div className="info-label">Guru Pembimbing</div>
                      <div className="info-title">{magang.guru_nama || "-"}</div>
                      <div className="info-desc">{magang.guru_mapel || "-"}</div>
                    </div>
                  </div>
                </div>
                <div className="schedule-row">
                  <span>📅 {formatDate(magang.tanggal_mulai)} - {formatDate(magang.tanggal_selesai)}</span>
                  <Badge status={magang.status} />
                </div>
              </>
            ) : pendaftaran ? (
              <>
                <div className="info-row">
                  <div className="info-box">
                    <div className="info-icon">🏢</div>
                    <div>
                      <div className="info-label">Tempat Magang</div>
                      <div className="info-title">{pendaftaran.dudi_nama || "-"}</div>
                      <div className="info-desc">{pendaftaran.dudi_alamat || "-"}</div>
                    </div>
                  </div>
                  <div className="info-box">
                    <div className="info-icon">👤</div>
                    <div>
                      <div className="info-label">Guru Pembimbing</div>
                      <div className="info-title">{pendaftaran.guru_nama || "-"}</div>
                    </div>
                  </div>
                </div>
                <div className="schedule-row">
                  <span>📅 {formatDate(pendaftaran.tanggal_daftar)}</span>
                  <Badge status={pendaftaran.status} />
                </div>
              </>
            ) : (
              <div className="empty-state">
                <div className="empty-icon">🏢</div>
                <div className="empty-title">Belum ada data magang</div>
                <div className="empty-sub">Daftar tempat magang melalui menu Magang</div>
                <Link href="/siswa/magang" className="btn btn-primary">Cari Tempat Magang</Link>
              </div>
            )}
          </div>
        </div>

        <div className="card">
          <div className="card-header"><h3>⚡ Aksi Cepat</h3></div>
          <div className="card-body quick-actions">
            <Link href="/siswa/jurnal?new=1" className="btn btn-primary btn-block">+ Buat Jurnal Baru</Link>
            <Link href="/siswa/jurnal" className="btn btn-outline btn-block">📖 Lihat Semua Jurnal</Link>
            <Link href="/siswa/magang" className="btn btn-outline btn-block">🎓 Info Magang</Link>
          </div>
        </div>
      </div>

      <div className="card">
        <div className="card-header">
          <h3>📖 Aktivitas Jurnal Terbaru</h3>
          <Link href="/siswa/jurnal">Lihat Semua</Link>
        </div>
        <div className="card-body">
          {recentJurnal.length === 0 ? (
            <div className="empty-state">
              <div className="empty-icon">📖</div>
              <div className="empty-title">Belum ada jurnal</div>
              <div className="empty-sub">Mulai dokumentasikan kegiatan magang Anda</div>
              <Link href="/siswa/jurnal?new=1" className="btn btn-primary">+ Buat Jurnal Pertama</Link>
            </div>
          ) : (
            recentJurnal.map((l) => (
              <div className="logbook-item" key={l.id}>
                <div className="logbook-dot" />
                <div className="logbook-content">
                  <div className="logbook-text">{l.kegiatan}</div>
                  {l.kendala && <div className="kendala-text">⚠️ {l.kendala}</div>}
                  {l.catatan_guru && <div style={{ fontSize: 11, color: "#0ea5e9", marginTop: 2 }}>💬 Guru: {l.catatan_guru}</div>}
                  <div className="logbook-meta">📅 {formatDate(l.tanggal)}</div>
                </div>
                <Badge status={l.status} />
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
}

function StatCard({ icon, label, sub, value }) {
  return (
    <div className="stat-card">
      <div className="stat-card-head">
        <span>{label}</span>
        <span>{icon}</span>
      </div>
      <div className="stat-num">{value}</div>
      <div className="stat-sub">{sub}</div>
    </div>
  );
}
