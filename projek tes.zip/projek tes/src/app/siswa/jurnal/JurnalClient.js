"use client";

import { useEffect, useState, useCallback } from "react";
import { useSearchParams, useRouter } from "next/navigation";
import Badge from "@/components/Badge";
import { formatDate, today } from "@/lib/utils";
import JurnalModal from "./JurnalModal";

export default function JurnalClient() {
  const searchParams = useSearchParams();
  const router = useRouter();

  const [jurnal, setJurnal] = useState([]);
  const [stats, setStats] = useState({ total: 0, disetujui: 0, menunggu: 0, ditolak: 0 });
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState("");
  const [loading, setLoading] = useState(true);
  const [magangInfo, setMagangInfo] = useState(null);
  const [magangLoading, setMagangLoading] = useState(true);
  const [showModal, setShowModal] = useState(searchParams.get("new") === "1");

  const loadMagang = useCallback(async () => {
    setMagangLoading(true);
    const res = await fetch("/api/magang", { cache: "no-store" });
    const data = await res.json();
    setMagangInfo(data);
    setMagangLoading(false);
  }, []);

  const load = useCallback(async () => {
    setLoading(true);
    const params = new URLSearchParams();
    if (search) params.set("search", search);
    if (statusFilter) params.set("status", statusFilter);
    const res = await fetch(`/api/jurnal?${params.toString()}`);
    const data = await res.json();
    setJurnal(data.data || []);
    setStats(data.stats || {});
    setLoading(false);
  }, [search, statusFilter]);

  useEffect(() => {
    load();
    loadMagang();
  }, [load, loadMagang]);

  const hasJurnalToday = jurnal.some((j) => j.tanggal === today());
  const isMagangAktif = magangInfo?.magang?.status === "aktif";
  const pendingPendaftaran = (magangInfo?.pendaftaran || []).filter((p) => p.status === "pending");

  const handleCreated = () => {
    setShowModal(false);
    if (searchParams.get("new")) router.replace("/siswa/jurnal");
    load();
  };

  return (
    <div className="page">
      <div className="page-header">
        <div>
          <h2>Jurnal Harian Magang</h2>
          <p>Dokumentasikan kegiatan magang harian Anda</p>
        </div>
        {!magangLoading && isMagangAktif && (
          <button className="btn btn-primary" onClick={() => setShowModal(true)}>+ Tambah Jurnal</button>
        )}
      </div>

      {!magangLoading && !isMagangAktif && (
        <div className="notice notice-warning">
          <div>
            <div className="notice-title">⚠️ Anda Belum Terdaftar di Tempat Magang</div>
            <div>
              {pendingPendaftaran.length > 0
                ? "Pendaftaran magang Anda sedang menunggu konfirmasi dari guru pembimbing. Anda dapat mengisi jurnal setelah pendaftaran disetujui."
                : "Anda harus mendaftarkan diri ke tempat magang (DUDI) dan menunggu persetujuan guru pembimbing sebelum dapat mengisi jurnal harian."}
            </div>
          </div>
          {pendingPendaftaran.length === 0 && (
            <button className="notice-btn" onClick={() => router.push("/siswa/magang")}>Daftar Magang</button>
          )}
        </div>
      )}

      {isMagangAktif && !hasJurnalToday && (
        <div className="notice notice-warning">
          <div>
            <div className="notice-title">⚠️ Jangan Lupa Jurnal Hari Ini!</div>
            <div>Anda belum membuat jurnal untuk hari ini. Dokumentasikan kegiatan magang Anda sekarang.</div>
          </div>
          <button className="notice-btn" onClick={() => setShowModal(true)}>Buat Sekarang</button>
        </div>
      )}

      <div className="stat-grid">
        <div className="stat-card">
          <div className="stat-card-head"><span>Total Jurnal</span><span>📄</span></div>
          <div className="stat-num">{stats.total || 0}</div>
          <div className="stat-sub">Jurnal yang telah dibuat</div>
        </div>
        <div className="stat-card">
          <div className="stat-card-head"><span>Disetujui</span><span>✅</span></div>
          <div className="stat-num">{stats.disetujui || 0}</div>
          <div className="stat-sub">Jurnal disetujui guru</div>
        </div>
        <div className="stat-card">
          <div className="stat-card-head"><span>Menunggu</span><span>⏱️</span></div>
          <div className="stat-num">{stats.menunggu || 0}</div>
          <div className="stat-sub">Belum diverifikasi</div>
        </div>
        <div className="stat-card">
          <div className="stat-card-head"><span>Ditolak</span><span>⛔</span></div>
          <div className="stat-num">{stats.ditolak || 0}</div>
          <div className="stat-sub">Perlu diperbaiki</div>
        </div>
      </div>

      <div className="card">
        <div className="card-header"><h3>📄 Riwayat Jurnal</h3></div>
        <div className="table-controls">
          <input
            className="search-input"
            placeholder="Cari kegiatan atau kendala..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
          <select className="filter-select" value={statusFilter} onChange={(e) => setStatusFilter(e.target.value)}>
            <option value="">Semua Status</option>
            <option value="menunggu">Menunggu</option>
            <option value="disetujui">Disetujui</option>
            <option value="ditolak">Ditolak</option>
          </select>
        </div>
        <table>
          <thead>
            <tr>
              <th>Tanggal</th>
              <th>Kegiatan & Kendala</th>
              <th>Status</th>
              <th>Feedback Guru</th>
              <th>Aksi</th>
            </tr>
          </thead>
          <tbody>
            {loading ? (
              <tr><td colSpan={5} style={{ textAlign: "center", padding: 30, color: "#94a3b8" }}>Memuat data...</td></tr>
            ) : jurnal.length === 0 ? (
              <tr>
                <td colSpan={5}>
                  <div className="empty-state">
                    <div className="empty-icon">📄</div>
                    <div className="empty-title">Belum ada jurnal</div>
                    <div className="empty-sub">Mulai dokumentasikan kegiatan magang Anda</div>
                  </div>
                </td>
              </tr>
            ) : jurnal.map((l) => (
              <tr key={l.id}>
                <td style={{ fontSize: 12, whiteSpace: "nowrap" }}>{formatDate(l.tanggal)}</td>
                <td style={{ fontSize: 13, maxWidth: 320 }}>
                  {l.kegiatan}
                  {l.kendala && <div className="kendala-text">⚠️ {l.kendala}</div>}
                  {l.file_name && <div style={{ fontSize: 11, color: "#0ea5e9", marginTop: 3 }}>📎 {l.file_name}</div>}
                </td>
                <td><Badge status={l.status} /></td>
                <td style={{ fontSize: 12, color: "#0ea5e9" }}>{l.catatan_guru || "-"}</td>
                <td>
                  {l.file_path && (
                    <a className="btn-icon btn-view" href={l.file_path} target="_blank" rel="noreferrer" title="Lihat lampiran">📎</a>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {showModal && isMagangAktif && (
        <JurnalModal
          onClose={() => {
            setShowModal(false);
            if (searchParams.get("new")) router.replace("/siswa/jurnal");
          }}
          onCreated={handleCreated}
        />
      )}
    </div>
  );
}
