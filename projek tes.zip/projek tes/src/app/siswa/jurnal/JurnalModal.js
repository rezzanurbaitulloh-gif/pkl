"use client";

import { useState, useRef } from "react";
import { today } from "@/lib/utils";

const MIN_CHARS = 50;
const MAX_FILE_SIZE = 5 * 1024 * 1024;

export default function JurnalModal({ onClose, onCreated }) {
  const [tanggal, setTanggal] = useState(today());
  const [kegiatan, setKegiatan] = useState("");
  const [kendala, setKendala] = useState("");
  const [file, setFile] = useState(null);
  const [error, setError] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const fileInputRef = useRef(null);

  const charCount = kegiatan.trim().length;
  const isValidDesc = charCount >= MIN_CHARS;

  const handleFileChange = (e) => {
    const f = e.target.files?.[0];
    if (!f) return;
    if (f.size > MAX_FILE_SIZE) {
      setError("Ukuran file maksimal 5MB.");
      return;
    }
    setError("");
    setFile(f);
  };

  const handleSubmit = async () => {
    if (!tanggal || !isValidDesc) {
      setError("Lengkapi form terlebih dahulu: tanggal dan deskripsi kegiatan (minimal 50 karakter) wajib diisi.");
      return;
    }

    setSubmitting(true);
    setError("");

    try {
      const formData = new FormData();
      formData.append("tanggal", tanggal);
      formData.append("kegiatan", kegiatan);
      formData.append("kendala", kendala);
      if (file) formData.append("file", file);

      const res = await fetch("/api/jurnal", { method: "POST", body: formData });
      const data = await res.json();

      if (!res.ok) {
        setError(data.message || "Gagal menyimpan jurnal.");
        return;
      }

      onCreated?.(data.data);
    } catch (err) {
      setError("Terjadi kesalahan, silakan coba lagi.");
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal" onClick={(e) => e.stopPropagation()}>
        <div className="modal-header">
          <div>
            <h3>Tambah Jurnal Harian</h3>
            <p>Dokumentasikan kegiatan magang harian Anda</p>
          </div>
          <button className="close-btn" onClick={onClose}>×</button>
        </div>
        <div className="modal-body">
          <div className="guide-box">
            <div className="guide-box-title">ℹ️ Panduan Penulisan Jurnal</div>
            <ul>
              <li>Minimal 50 karakter untuk deskripsi kegiatan</li>
              <li>Deskripsikan kegiatan dengan detail dan spesifik</li>
              <li>Sertakan kendala yang dihadapi (jika ada)</li>
              <li>Upload dokumentasi pendukung untuk memperkuat laporan</li>
              <li>Pastikan tanggal sesuai dengan hari kerja</li>
            </ul>
          </div>

          <div className="form-section-title">Informasi Dasar</div>
          <div className="form-grid">
            <div className="form-group">
              <label>📅 Tanggal *</label>
              <input
                className="form-control"
                type="date"
                value={tanggal}
                max={today()}
                onChange={(e) => setTanggal(e.target.value)}
              />
            </div>
            <div className="form-group">
              <label>Status</label>
              <input className="form-control" value="Menunggu Verifikasi" disabled />
            </div>
          </div>

          <div className="form-section-title">Kegiatan Harian</div>
          <div className="form-grid">
            <div className="form-group full">
              <label>
                <span>📝 Deskripsi Kegiatan *</span>
                <span className={`char-counter ${charCount === 0 ? "" : isValidDesc ? "valid" : "invalid"}`}>
                  {charCount}/{MIN_CHARS} minimum
                </span>
              </label>
              <textarea
                className={`form-control ${charCount > 0 && !isValidDesc ? "error" : ""}`}
                style={{ minHeight: 110 }}
                value={kegiatan}
                onChange={(e) => setKegiatan(e.target.value)}
                placeholder="Deskripsikan kegiatan yang Anda lakukan hari ini secara detail. Contoh: Membuat wireframe untuk halaman login menggunakan Figma, kemudian melakukan coding HTML dan CSS untuk implementasi desain tersebut..."
              />
            </div>
            <div className="form-group full">
              <label>⚠️ Kendala (Opsional)</label>
              <textarea
                className="form-control"
                value={kendala}
                onChange={(e) => setKendala(e.target.value)}
                placeholder="Tuliskan kendala yang dihadapi selama kegiatan (jika ada)..."
              />
            </div>
          </div>

          <div className="form-section-title">Dokumentasi Pendukung</div>
          <label>Upload File (Opsional)</label>
          <div className="upload-box">
            <div className="upload-icon">📤</div>
            <div className="upload-title">Pilih file dokumentasi</div>
            <div className="upload-sub">PDF, DOC, DOCX, JPG, PNG (Max 5MB)</div>
            <button type="button" className="btn btn-primary" onClick={() => fileInputRef.current?.click()}>
              Browse File
            </button>
            <input
              ref={fileInputRef}
              type="file"
              accept=".pdf,.doc,.docx,.jpg,.jpeg,.png"
              style={{ display: "none" }}
              onChange={handleFileChange}
            />
            {file && (
              <div className="file-chip">
                <span>📎 {file.name}</span>
                <button type="button" className="close-btn" onClick={() => setFile(null)}>×</button>
              </div>
            )}
          </div>
          <div className="upload-hint">Jenis file yang dapat diupload: Screenshot hasil kerja, dokumentasi code, foto kegiatan</div>

          {error && <div className="form-error">⚠️ {error}</div>}
        </div>
        <div className="modal-footer">
          <button className="btn btn-secondary" onClick={onClose}>Batal</button>
          <button className="btn btn-primary" onClick={handleSubmit} disabled={submitting || !isValidDesc}>
            {submitting ? "Menyimpan..." : "Simpan Jurnal"}
          </button>
        </div>
      </div>
    </div>
  );
}
