"use client";

import { useEffect, useState, useCallback } from "react";
import Badge from "@/components/Badge";
import { formatDate } from "@/lib/utils";
import GuruModal from "./GuruModal";

export default function MagangClient() {
  const [tab, setTab] = useState("status");
  const [magangData, setMagangData] = useState(null);
  const [dudiList, setDudiList] = useState([]);
  const [search, setSearch] = useState("");
  const [loading, setLoading] = useState(true);
  const [dudiLoading, setDudiLoading] = useState(false);
  const [selectedDudi, setSelectedDudi] = useState(null);
  const [toast, setToast] = useState("");

  const loadStatus = useCallback(async () => {
    setLoading(true);
    const res = await fetch("/api/magang");
    const data = await res.json();
    setMagangData(data);
    setLoading(false);
  }, []);

  const loadDudi = useCallback(async () => {
    setDudiLoading(true);
    const params = new URLSearchParams();
    if (search) params.set("search", search);
    const res = await fetch(`/api/dudi?${params.toString()}`);
    const data = await res.json();
    setDudiList(data.data || []);
    setDudiLoading(false);
  }, [search]);

  useEffect(() => {
    loadStatus();
  }, [loadStatus]);

  useEffect(() => {
    if (tab === "cari") loadDudi();
  }, [tab, loadDudi]);

  const pendingCount = magangData?.pendingCount || 0;
  const maxPending = magangData?.maxPending || 3;
  const magang = magangData?.magang || null;
  const dismissedMagang = magangData?.dismissedMagang || null;
  const hasSertifikatTemplate = magangData?.hasSertifikatTemplate || false;

  const isAccepted = magang && magang.status === "aktif";
  const isSelesai = magang && magang.status === "selesai";
  const isDismissed = dismissedMagang && dismissedMagang.status === "dibatalkan";
  const canRegister = !isAccepted && !isSelesai;

  const handleConfirmed = () => {
    setSelectedDudi(null);
    setToast("Pendaftaran berhasil dikirim, menunggu konfirmasi guru/admin.");
    loadStatus();
    loadDudi();
    setTimeout(() => setToast(""), 4000);
  };

  return (
    <div className="page">
      <div className="welcome-banner">
        <div>
          <h2>Magang Siswa</h2>
          <p>Cari tempat magang dan pantau status pendaftaran Anda</p>
        </div>
      </div>

      {toast && <div className="notice notice-info"><div>{toast}</div></div>}

      {/* ✅ Banner Selesai Magang + Sertifikat */}
      {isSelesai && (
        <div className="notice notice-selesai-magang">
          <div className="notice-selesai-left">
            <div className="notice-selesai-icon">🎓</div>
            <div className="notice-selesai-content">
              <div className="notice-title">Selamat! Anda Telah Menyelesaikan Magang</div>
              <div className="notice-selesai-dudi">🏢 {magang.dudi_nama}</div>
              <p className="notice-selesai-desc">
                Anda telah berhasil menyelesaikan program magang. Sertifikat kelulusan magang Anda
                telah tersedia dan dapat diunduh di bawah ini.
              </p>
              {magang.nomor_sertifikat && (
                <div className="notice-selesai-nomor">
                  📄 No. Sertifikat: <strong>{magang.nomor_sertifikat}</strong>
                </div>
              )}
              <div className="notice-selesai-actions">
                {hasSertifikatTemplate ? (
                  <>
                    <a
                      href={`/api/sertifikat/${magang.id}`}
                      target="_blank"
                      rel="noreferrer"
                      className="btn-sertifikat btn-sertifikat-view"
                    >
                      👁️ Lihat Sertifikat
                    </a>
                    <a
                      href={`/api/sertifikat/${magang.id}`}
                      download
                      className="btn-sertifikat btn-sertifikat-download"
                    >
                      ⬇️ Unduh PDF
                    </a>
                  </>
                ) : (
                  <div className="notice-sertifikat-belum-ada">
                    ⏳ Sertifikat sedang disiapkan oleh admin. Pantau terus halaman ini.
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Banner: Diterima & aktif */}
      {isAccepted && (
        <div className="notice notice-accepted-permanent">
          <div className="notice-icon-big">✅</div>
          <div className="notice-accepted-content">
            <div className="notice-title">Anda Telah Diterima di Tempat Magang</div>
            <div className="notice-accepted-dudi">🏢 {magang.dudi_nama}</div>
            <p>
              Anda sudah tercatat sebagai peserta magang aktif di tempat ini.
              Anda <strong>tidak dapat mendaftarkan magang ke tempat lain</strong> selama masih aktif magang.
            </p>
          </div>
        </div>
      )}

      {/* Banner: Dibatalkan/dikeluarkan */}
      {isDismissed && (
        <div className="notice notice-dismissed">
          <div className="notice-icon-big">⚠️</div>
          <div className="notice-accepted-content">
            <div className="notice-title">Anda Telah Diberhentikan dari Tempat Magang</div>
            <div className="notice-accepted-dudi">🏢 {dismissedMagang.dudi_nama}</div>
            {dismissedMagang.catatan && (
              <div className="notice-dismissal-reason">
                <strong>Alasan pemberhentian:</strong> {dismissedMagang.catatan}
              </div>
            )}
            <p>
              Magang Anda di tempat tersebut telah <strong>dibatalkan/diberhentikan</strong> sebelum waktu yang ditentukan selesai.
              Silakan segera <strong>mendaftarkan diri ke tempat magang yang baru</strong> melalui tab &quot;Cari Tempat Magang&quot; di bawah.
            </p>
          </div>
        </div>
      )}

      <div className="tabs">
        <button className={`tab-item ${tab === "status" ? "active" : ""}`} onClick={() => setTab("status")}>
          🕐 Status Magang Saya
        </button>
        {canRegister && (
          <button className={`tab-item ${tab === "cari" ? "active" : ""}`} onClick={() => setTab("cari")}>
            🔍 Cari Tempat Magang
          </button>
        )}
        {(isAccepted || isSelesai) && (
          <button className="tab-item tab-item-disabled" disabled title="Anda sudah memiliki magang aktif atau selesai">
            🔒 Cari Tempat Magang
          </button>
        )}
      </div>

      {tab === "status" && (
        <StatusTab
          loading={loading}
          magangData={magangData}
          pendingCount={pendingCount}
          maxPending={maxPending}
          hasSertifikatTemplate={hasSertifikatTemplate}
        />
      )}

      {tab === "cari" && canRegister && (
        <CariTab
          loading={dudiLoading}
          dudiList={dudiList}
          search={search}
          setSearch={setSearch}
          pendingCount={pendingCount}
          maxPending={maxPending}
          onDaftar={(dudi) => setSelectedDudi(dudi)}
        />
      )}

      {selectedDudi && (
        <GuruModal
          dudi={selectedDudi}
          onClose={() => setSelectedDudi(null)}
          onConfirmed={handleConfirmed}
        />
      )}
    </div>
  );
}

function StatusTab({ loading, magangData, pendingCount, maxPending, hasSertifikatTemplate }) {
  if (loading) {
    return <div className="empty-state"><div className="empty-sub">Memuat data...</div></div>;
  }

  const { siswa, magang, pendaftaran, riwayatMagang } = magangData || {};
  const magangDibatalkan = (riwayatMagang || []).filter((m) => m.status === "dibatalkan");
  const isSelesai = magang?.status === "selesai";

  return (
    <>
      <div className="status-card">
        <div>
          <h3>{siswa?.nama} • {siswa?.nis}</h3>
          <p>{siswa?.kelas} • {siswa?.jurusan}</p>
        </div>
        {magang?.status !== "aktif" && magang?.status !== "selesai" && (
          <div className="status-fraction">
            {pendingCount}/{maxPending}
            <small>Pendaftaran Pending</small>
          </div>
        )}
      </div>

      {magang && (
        <div className="card">
          <div className="card-header">
            <h3>
              {magang.status === "aktif" && "🏢 Magang Aktif"}
              {magang.status === "dibatalkan" && "❌ Magang Dibatalkan"}
              {magang.status === "selesai" && "🎓 Magang Selesai"}
            </h3>
          </div>
          <div className="card-body">
            <div className="dudi-card" style={{ marginBottom: 0 }}>
              <h4>{magang.dudi_nama}</h4>
              <div className="dudi-meta">📍 {magang.dudi_alamat}</div>
              <div className="dudi-meta">👤 Pembimbing: {magang.guru_nama}</div>
              <div className="dudi-meta">
                📅 {formatDate(magang.tanggal_mulai)} - {formatDate(magang.tanggal_selesai)}
              </div>
              {magang.status === "dibatalkan" && magang.catatan && (
                <div className="dudi-meta dismissal-note">
                  💬 <strong>Alasan pemberhentian:</strong> {magang.catatan}
                </div>
              )}
              {isSelesai && magang.nomor_sertifikat && (
                <div className="dudi-meta">
                  📄 No. Sertifikat: <strong>{magang.nomor_sertifikat}</strong>
                </div>
              )}
              <div style={{ marginTop: 10, display: "flex", gap: 8, alignItems: "center", flexWrap: "wrap" }}>
                <Badge status={magang.status} />
                {isSelesai && hasSertifikatTemplate && (
                  <>
                    <a
                      href={`/api/sertifikat/${magang.id}`}
                      target="_blank"
                      rel="noreferrer"
                      className="btn-sertifikat btn-sertifikat-view btn-sertifikat-sm"
                    >
                      👁️ Lihat
                    </a>
                    <a
                      href={`/api/sertifikat/${magang.id}`}
                      download
                      className="btn-sertifikat btn-sertifikat-download btn-sertifikat-sm"
                    >
                      ⬇️ Unduh PDF
                    </a>
                  </>
                )}
              </div>
            </div>
          </div>
        </div>
      )}

      <div className="section-title">Riwayat Pendaftaran</div>

      {magangDibatalkan.map((m) => (
        <div className="riwayat-magang-dibatalkan" key={`magang-batal-${m.id}`}>
          <div className="riwayat-dismissed-header">
            <div className="riwayat-dismissed-icon">❌</div>
            <div className="riwayat-dismissed-title">Pernah Dikeluarkan dari Tempat Magang</div>
            <Badge status="dibatalkan" />
          </div>
          <div className="riwayat-dismissed-body">
            <h4>{m.dudi_nama}</h4>
            <div className="dudi-meta">📍 {m.dudi_alamat}</div>
            <div className="dudi-meta">👤 Pembimbing: {m.guru_nama}</div>
            <div className="dudi-meta">
              📅 {formatDate(m.tanggal_mulai)} — {formatDate(m.tanggal_selesai)}
            </div>
          </div>
          <div className="riwayat-dismissed-reason">
            <div className="riwayat-dismissed-reason-label">💬 Alasan Pemberhentian:</div>
            <div className="riwayat-dismissed-reason-text">
              {m.catatan && m.catatan.trim() ? m.catatan : "Tidak ada keterangan alasan yang diberikan."}
            </div>
          </div>
        </div>
      ))}

      {(!pendaftaran || pendaftaran.length === 0) ? (
        <div className="card">
          <div className="card-body">
            <div className="empty-state">
              <div className="empty-icon">🏢</div>
              <div className="empty-title">Belum ada riwayat pendaftaran</div>
              <div className="empty-sub">Cari dan daftar tempat magang melalui tab &quot;Cari Tempat Magang&quot;</div>
            </div>
          </div>
        </div>
      ) : (
        pendaftaran.map((p) => (
          <div className="dudi-card" key={p.id}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
              <div>
                <h4>{p.dudi_nama}</h4>
                <div className="dudi-meta">📍 {p.dudi_alamat}</div>
                <div className="dudi-meta">👤 Pembimbing: {p.guru_nama}</div>
                <div className="dudi-meta">📅 Daftar: {formatDate(p.tanggal_daftar)}</div>
                {p.status === "ditolak" && p.alasan_pembatalan && (
                  <div className="dudi-meta" style={{ color: "#ef4444", fontSize: 12, marginTop: 4 }}>
                    ⚠️ {p.alasan_pembatalan}
                  </div>
                )}
                {p.status === "ditolak" && p.catatan && !p.alasan_pembatalan && (
                  <div className="dudi-meta" style={{ color: "#ef4444", fontSize: 12, marginTop: 4 }}>
                    ⚠️ {p.catatan}
                  </div>
                )}
              </div>
              <Badge status={p.status} />
            </div>
          </div>
        ))
      )}
    </>
  );
}

function CariTab({ loading, dudiList, search, setSearch, pendingCount, maxPending, onDaftar }) {
  const reachedLimit = pendingCount >= maxPending;

  return (
    <>
      <div className="notice notice-info" style={{ display: "block" }}>
        <div className="notice-title">ℹ️ Informasi Pendaftaran</div>
        <ul style={{ margin: "6px 0 0", paddingLeft: 18, lineHeight: 1.6 }}>
          <li>Maksimal {maxPending} pendaftaran dengan status pending.</li>
          <li>Pendaftaran langsung masuk ke sistem magang (menunggu konfirmasi).</li>
          <li>Jika diterima di salah satu tempat, pendaftaran lain akan otomatis dibatalkan.</li>
          <li>Saat ini: <strong>{pendingCount}/{maxPending}</strong> pending.</li>
        </ul>
      </div>

      <input
        className="search-input"
        style={{ marginBottom: 16 }}
        placeholder="Cari perusahaan atau lokasi..."
        value={search}
        onChange={(e) => setSearch(e.target.value)}
      />

      {loading ? (
        <div className="empty-state"><div className="empty-sub">Memuat data...</div></div>
      ) : dudiList.length === 0 ? (
        <div className="empty-state">
          <div className="empty-icon">🏢</div>
          <div className="empty-title">Tidak ada tempat magang ditemukan</div>
        </div>
      ) : (
        dudiList.map((d) => (
          <div className="dudi-card" key={d.id}>
            <h4>{d.nama}</h4>
            <div className="dudi-meta">📍 {d.alamat}</div>
            <div className="dudi-meta">📞 {d.telepon}</div>
            {d.pendaftaranStatus ? (
              <div className={`dudi-status-banner ${d.pendaftaranStatus}`}>
                {d.pendaftaranStatus === "pending" && "⏱️ Menunggu Konfirmasi"}
                {d.pendaftaranStatus === "diterima" && "✅ Diterima"}
                {d.pendaftaranStatus === "ditolak" && "⛔ Ditolak"}
              </div>
            ) : (
              <button
                className="dudi-daftar-btn"
                onClick={() => onDaftar(d)}
                disabled={reachedLimit}
                title={reachedLimit ? `Maksimal ${maxPending} pendaftaran pending` : ""}
              >
                ✈️ Daftar
              </button>
            )}
          </div>
        ))
      )}
    </>
  );
}
