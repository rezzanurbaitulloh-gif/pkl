"use client";

import { useEffect, useState } from "react";

export default function GuruModal({ dudi, onClose, onConfirmed }) {
  const [guruList, setGuruList] = useState([]);
  const [selectedGuru, setSelectedGuru] = useState(null);
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => {
    fetch("/api/guru")
      .then((res) => res.json())
      .then((data) => setGuruList(data.data || []))
      .finally(() => setLoading(false));
  }, []);

  const handleConfirm = async () => {
    if (!selectedGuru) {
      setError("Pilih salah satu guru pembimbing terlebih dahulu.");
      return;
    }
    setSubmitting(true);
    setError("");
    try {
      const res = await fetch("/api/pendaftaran", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ dudiId: dudi.id, guruId: selectedGuru }),
      });
      const data = await res.json();
      if (!res.ok) {
        setError(data.message || "Gagal mengirim pendaftaran.");
        return;
      }
      onConfirmed?.(data.data);
    } catch (err) {
      setError("Terjadi kesalahan, silakan coba lagi.");
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal modal-lg" onClick={(e) => e.stopPropagation()}>
        <div className="modal-header">
          <div>
            <h3>👤 Pilih Guru Pembimbing</h3>
          </div>
          <button className="close-btn" onClick={onClose}>×</button>
        </div>
        <div className="modal-body">
          <p style={{ fontSize: 13, color: "#475569", marginBottom: 16 }}>
            Pilih guru pembimbing yang akan mendampingi Anda selama magang di <strong>{dudi.nama}</strong>
          </p>

          {loading ? (
            <div className="empty-state"><div className="empty-sub">Memuat daftar guru...</div></div>
          ) : (
            guruList.map((g) => (
              <div
                key={g.id}
                className={`guru-option ${selectedGuru === g.id ? "selected" : ""}`}
                onClick={() => setSelectedGuru(g.id)}
              >
                <div className="guru-avatar">👤</div>
                <div>
                  <h5>{g.nama}</h5>
                  <p>NIP: {g.nip}</p>
                  <p>Mata Pelajaran: {g.mapel}</p>
                  <p>{g.email}</p>
                </div>
              </div>
            ))
          )}

          {error && <div className="form-error">⚠️ {error}</div>}
        </div>
        <div className="modal-footer">
          <button className="btn btn-secondary" onClick={onClose}>Batal</button>
          <button className="btn btn-primary" onClick={handleConfirm} disabled={submitting || !selectedGuru}>
            {submitting ? "Mengirim..." : "📨 Konfirmasi Pendaftaran"}
          </button>
        </div>
      </div>
    </div>
  );
}
