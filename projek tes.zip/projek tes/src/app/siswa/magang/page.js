import MagangClient from "./MagangClient";

export const dynamic = "force-dynamic";

export default function MagangPage() {
  return <MagangClient />;
}
