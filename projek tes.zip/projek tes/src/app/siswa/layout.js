import { redirect } from "next/navigation";
import { getCurrentSiswa } from "@/lib/auth";
import { getPublicSchoolInfo } from "@/lib/publicSchoolInfo";
import SiswaLayoutClient from "./SiswaLayoutClient";

export default async function SiswaLayout({ children }) {
  const siswa = await getCurrentSiswa();
  if (!siswa) redirect("/login");

  // Perbaikan Bug #12: ambil nama sekolah asli dari database, bukan
  // hardcode, supaya render pertama sudah menampilkan nama yang benar.
  const school = await getPublicSchoolInfo();

  return (
    <SiswaLayoutClient schoolName={school.nama} user={{ nama: siswa.nama }}>
      {children}
    </SiswaLayoutClient>
  );
}
