"use client";

import { useState, useEffect, useCallback } from "react";
import Badge from "@/components/Badge";

const formatDate = (d) =>
  d ? new Date(d).toLocaleDateString("id-ID", { day: "2-digit", month: "short", year: "numeric" }) : "-";

const statusJurnalLabel = { menunggu: "Menunggu", disetujui: "Disetujui", ditolak: "Ditolak" };

export default function DudiMagangPage() {
  const [list, setList] = useState([]);
  const [selected, setSelected] = useState(null); // magang yang dipilih
  const [jurnal, setJurnal] = useState([]);
  const [evalForm, setEvalForm] = useState({ catatan_dudi: "", nilai_dudi: "" });
  const [loadingEval, setLoadingEval] = useState(false);
  const [evalMsg, setEvalMsg] = useState("");
  const [loadingJurnal, setLoadingJurnal] = useState(false);

  const loadList = () =>
    fetch("/api/dudi/magang").then((r) => r.json()).then((d) => setList(Array.isArray(d) ? d : []));

  useEffect(() => { loadList(); }, []);

  const pilihSiswa = useCallback(async (m) => {
    setSelected(m);
    setEvalForm({ catatan_dudi: m.catatan_dudi || "", nilai_dudi: m.nilai_dudi ?? "" });
    setEvalMsg("");
    setLoadingJurnal(true);
    const res = await fetch(`/api/dudi/magang/${m.id}/jurnal`);
    const data = await res.json();
    setJurnal(Array.isArray(data) ? data : []);
    setLoadingJurnal(false);
  }, []);

  const simpanEvaluasi = async () => {
    if (!selected) return;
    const nilai = evalForm.nilai_dudi === "" ? null : Number(evalForm.nilai_dudi);
    if (nilai !== null && (isNaN(nilai) || nilai < 0 || nilai > 100)) {
      setEvalMsg("Nilai harus berupa angka 0–100.");
      return;
    }
    setLoadingEval(true);
    setEvalMsg("");
    try {
      const res = await fetch(`/api/dudi/magang/${selected.id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ catatan_dudi: evalForm.catatan_dudi, nilai_dudi: nilai }),
      });
      const data = await res.json();
      if (!res.ok) { setEvalMsg(data.message || "Gagal menyimpan."); return; }
      setEvalMsg("✅ Evaluasi berhasil disimpan.");
      // Refresh list dan update selected
      const updated = await fetch("/api/dudi/magang").then((r) => r.json());
      const arr = Array.isArray(updated) ? updated : [];
      setList(arr);
      const updatedSelected = arr.find((m) => m.id === selected.id);
      if (updatedSelected) setSelected(updatedSelected);
    } finally {
      setLoadingEval(false);
    }
  };

  return (
    <div className="page">
      <div className="page-header">
        <h2>Data Magang Siswa</h2>
        <p>Lihat jurnal harian dan berikan evaluasi untuk setiap siswa</p>
      </div>

      <div style={{ display: "grid", gridTemplateColumns: selected ? "1fr 2fr" : "1fr", gap: 20 }}>
        {/* Daftar Siswa */}
        <div className="card">
          <div className="card-header"><h3>🎓 Daftar Siswa</h3></div>
          <div className="card-body">
            {list.length === 0 ? (
              <p style={{ color: "#94a3b8", fontSize: 13 }}>Belum ada siswa magang.</p>
            ) : (
              list.map((m) => (
                <div
                  key={m.id}
                  className="magang-item"
                  onClick={() => pilihSiswa(m)}
                  style={{
                    cursor: "pointer",
                    background: selected?.id === m.id ? "#eff6ff" : undefined,
                    borderRadius: 8,
                    padding: "8px 4px",
                    borderLeft: selected?.id === m.id ? "3px solid #3b82f6" : "3px solid transparent",
                  }}
                >
                  <div>
                    <div style={{ fontWeight: 600, fontSize: 13 }}>{m.siswa_nama}</div>
                    <div style={{ fontSize: 12, color: "#64748b" }}>{m.kelas} · {m.jurusan}</div>
                    <div style={{ fontSize: 11, color: "#94a3b8" }}>
                      📅 {formatDate(m.tanggal_mulai)} — {formatDate(m.tanggal_selesai)}
                    </div>
                    {m.nilai_dudi != null && (
                      <div style={{ fontSize: 11, color: "#22c55e", fontWeight: 600 }}>
                        ⭐ Nilai: {m.nilai_dudi}
                      </div>
                    )}
                  </div>
                  <Badge status={m.status} />
                </div>
              ))
            )}
          </div>
        </div>

        {/* Detail & Evaluasi */}
        {selected && (
          <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
            {/* Form Evaluasi */}
            <div className="card">
              <div className="card-header">
                <h3>📝 Evaluasi: {selected.siswa_nama}</h3>
                <button
                  className="btn btn-secondary"
                  style={{ fontSize: 12, padding: "4px 10px" }}
                  onClick={() => setSelected(null)}
                >
                  ✕ Tutup
                </button>
              </div>
              <div className="card-body">
                <div className="form-grid" style={{ gridTemplateColumns: "1fr" }}>
                  <div className="form-group">
                    <label>Nilai (0–100)</label>
                    <input
                      className="form-control"
                      type="number"
                      min={0}
                      max={100}
                      placeholder="Kosongkan jika belum dinilai"
                      value={evalForm.nilai_dudi}
                      onChange={(e) => setEvalForm({ ...evalForm, nilai_dudi: e.target.value })}
                    />
                  </div>
                  <div className="form-group">
                    <label>Catatan / Evaluasi DUDI</label>
                    <textarea
                      className="form-control"
                      rows={4}
                      placeholder="Tuliskan catatan atau evaluasi untuk siswa ini..."
                      value={evalForm.catatan_dudi}
                      onChange={(e) => setEvalForm({ ...evalForm, catatan_dudi: e.target.value })}
                    />
                  </div>
                </div>
                {evalMsg && (
                  <div
                    style={{
                      marginTop: 8, padding: "8px 12px", borderRadius: 6, fontSize: 13,
                      background: evalMsg.startsWith("✅") ? "#f0fdf4" : "#fef2f2",
                      color: evalMsg.startsWith("✅") ? "#16a34a" : "#dc2626",
                    }}
                  >
                    {evalMsg}
                  </div>
                )}
                <div style={{ marginTop: 12 }}>
                  <button className="btn btn-primary" onClick={simpanEvaluasi} disabled={loadingEval}>
                    {loadingEval ? "Menyimpan..." : "💾 Simpan Evaluasi"}
                  </button>
                </div>
              </div>
            </div>

            {/* Jurnal Harian */}
            <div className="card">
              <div className="card-header"><h3>📋 Jurnal Harian</h3></div>
              <div className="card-body">
                {loadingJurnal ? (
                  <p style={{ color: "#94a3b8", fontSize: 13 }}>Memuat jurnal...</p>
                ) : jurnal.length === 0 ? (
                  <p style={{ color: "#94a3b8", fontSize: 13 }}>Belum ada jurnal dari siswa ini.</p>
                ) : (
                  jurnal.map((j) => (
                    <div className="logbook-item" key={j.id} style={{ marginBottom: 16 }}>
                      <div className="logbook-dot" />
                      <div className="logbook-content" style={{ flex: 1 }}>
                        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 4 }}>
                          <div style={{ fontWeight: 600, fontSize: 12, color: "#64748b" }}>
                            📅 {formatDate(j.tanggal)}
                          </div>
                          <Badge status={j.status} />
                        </div>
                        <div className="logbook-text" style={{ marginBottom: 4 }}>{j.kegiatan}</div>
                        {j.kendala && (
                          <div style={{ fontSize: 12, color: "#f59e0b" }}>⚠️ Kendala: {j.kendala}</div>
                        )}
                        {j.file_path && (
                          <div style={{ marginTop: 4 }}>
                            <a href={j.file_path} target="_blank" rel="noreferrer" style={{ fontSize: 12, color: "#0ea5e9" }}>
                              📎 {j.file_name || "Lihat lampiran"}
                            </a>
                          </div>
                        )}
                        {j.catatan_guru && (
                          <div
                            style={{
                              marginTop: 6, padding: "6px 10px", background: "#f0f9ff",
                              borderRadius: 6, fontSize: 12, color: "#0369a1",
                            }}
                          >
                            💬 Catatan Guru: {j.catatan_guru}
                          </div>
                        )}
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
