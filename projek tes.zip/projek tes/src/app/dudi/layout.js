import { redirect } from "next/navigation";
import { getCurrentDudi } from "@/lib/auth";
import { getPublicSchoolInfo } from "@/lib/publicSchoolInfo";
import DudiLayoutClient from "./DudiLayoutClient";

export default async function DudiLayout({ children }) {
  const dudi = await getCurrentDudi();
  if (!dudi) redirect("/login");

  // Perbaikan Bug #12: ambil nama sekolah asli dari database, bukan
  // hardcode, supaya render pertama sudah menampilkan nama yang benar.
  const school = await getPublicSchoolInfo();

  return (
    <DudiLayoutClient schoolName={school.nama} user={{ nama: dudi.nama }}>
      {children}
    </DudiLayoutClient>
  );
}
