"use client";

import { useState, useEffect } from "react";
import Badge from "@/components/Badge";

const formatDate = (d) =>
  d ? new Date(d).toLocaleDateString("id-ID", { day: "2-digit", month: "short", year: "numeric" }) : "-";

export default function DudiDashboardPage() {
  const [data, setData] = useState(null);

  useEffect(() => {
    fetch("/api/dudi/magang").then((r) => r.json()).then(setData);
  }, []);

  if (!data) return <div className="page"><p style={{ color: "#94a3b8" }}>Memuat data...</p></div>;

  const list = Array.isArray(data) ? data : [];
  const aktif = list.filter((m) => m.status === "aktif");
  const selesai = list.filter((m) => m.status === "selesai");
  const sudahDinilai = list.filter((m) => m.nilai_dudi != null);

  return (
    <div className="page">
      <div className="page-header">
        <h2>Dashboard DUDI</h2>
        <p>Pantau siswa magang di perusahaan Anda</p>
      </div>

      <div className="stat-grid">
        {[
          { num: list.length, label: "Total Siswa", sub: "Semua periode" },
          { num: aktif.length, label: "Sedang Magang", sub: "Status aktif" },
          { num: selesai.length, label: "Selesai Magang", sub: "Sudah selesai" },
          { num: sudahDinilai.length, label: "Sudah Dievaluasi", sub: "Diberi nilai DUDI" },
        ].map((s) => (
          <div className="stat-card" key={s.label}>
            <div className="stat-num">{s.num}</div>
            <div className="stat-label">{s.label}</div>
            <div className="stat-sub">{s.sub}</div>
          </div>
        ))}
      </div>

      <div className="card">
        <div className="card-header">
          <h3>🎓 Daftar Siswa Magang</h3>
        </div>
        <div className="card-body">
          {list.length === 0 ? (
            <p style={{ color: "#94a3b8", fontSize: 13 }}>Belum ada siswa magang di perusahaan ini.</p>
          ) : (
            list.map((m) => (
              <div className="magang-item" key={m.id}>
                <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                  <div
                    style={{
                      width: 36, height: 36, borderRadius: "50%", background: "#38bdf8",
                      display: "flex", alignItems: "center", justifyContent: "center",
                      color: "#fff", fontWeight: 700, fontSize: 12,
                    }}
                  >
                    {m.siswa_nama?.split(" ").slice(0, 2).map((w) => w[0]).join("").toUpperCase() || "?"}
                  </div>
                  <div>
                    <div style={{ fontWeight: 600, fontSize: 13 }}>{m.siswa_nama || "-"}</div>
                    <div style={{ fontSize: 12, color: "#64748b" }}>
                      {m.kelas} · {m.jurusan}
                    </div>
                    <div style={{ fontSize: 11, color: "#94a3b8" }}>
                      📅 {formatDate(m.tanggal_mulai)} — {formatDate(m.tanggal_selesai)}
                      {m.nilai_dudi != null && (
                        <span style={{ marginLeft: 8, color: "#22c55e", fontWeight: 600 }}>
                          ⭐ Nilai: {m.nilai_dudi}
                        </span>
                      )}
                    </div>
                  </div>
                </div>
                <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                  <Badge status={m.status} />
                  <a
                    href="/dudi/magang"
                    style={{ fontSize: 12, color: "#3b82f6", textDecoration: "underline" }}
                  >
                    Detail →
                  </a>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
}
