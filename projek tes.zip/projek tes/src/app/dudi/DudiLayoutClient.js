"use client";

import { useState } from "react";
import DudiSidebar from "@/components/DudiSidebar";
import DudiTopbar from "@/components/DudiTopbar";

export default function DudiLayoutClient({ schoolName, user, children }) {
  const [sidebarOpen, setSidebarOpen] = useState(false);

  return (
    <div className="app">
      <DudiSidebar
        schoolName={schoolName}
        isOpen={sidebarOpen}
        onClose={() => setSidebarOpen(false)}
      />
      <div className="main-content">
        <DudiTopbar
          schoolName={schoolName}
          user={user}
          onMenuToggle={() => setSidebarOpen((prev) => !prev)}
        />
        {children}
      </div>
    </div>
  );
}
