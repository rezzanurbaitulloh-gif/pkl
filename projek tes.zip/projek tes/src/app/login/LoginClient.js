"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { isValidEmailForRole } from "@/lib/utils";

export default function LoginClient({ school }) {
  const schoolName = school?.nama || "Sekolah";
  const router = useRouter();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const handleLogin = async () => {
    setError("");

    if (!email.trim()) {
      setError("Email wajib diisi.");
      return;
    }
    if (!isValidEmailForRole(email)) {
      setError("Format email tidak valid");
      return;
    }
    if (!password) {
      setError("Password wajib diisi.");
      return;
    }

    setLoading(true);
    try {
      const res = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, password }),
      });
      const data = await res.json();
      if (!res.ok) {
        setError(data.message || "Login gagal.");
        return;
      }
      router.push(data.redirectTo || "/siswa/dashboard");
      router.refresh();
    } catch (err) {
      setError("Tidak dapat terhubung ke server.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="login-page">
      <div className="login-left">
        <h1>
          Sistem Manajemen
          <br />
          <span>Magang Siswa</span>
        </h1>
        <p>
          Platform terpadu untuk mengelola program magang siswa SMK secara
          digital, efisien, dan transparan.
        </p>
        <div className="login-features">
          {[
            ["🎓", "Manajemen Siswa Magang"],
            ["🏢", "Data DUDI Terintegrasi"],
            ["📋", "Jurnal Harian Digital"],
            ["📊", "Monitoring Real-time"],
          ].map(([icon, text]) => (
            <div className="login-feature" key={text}>
              <div className="login-feature-icon">{icon}</div>
              <p>{text}</p>
            </div>
          ))}
        </div>
      </div>
      <div className="login-right">
        <div className="login-box">
          <div className="login-logo">
            <div className="logo-circle" style={{ display: "flex", justifyContent: "center", alignItems: "center", background: "transparent" }}>
              <img 
                src="/logo.png.webp" 
                alt={`Logo ${schoolName}`}
                style={{ width: "60px", height: "auto", objectFit: "contain" }} 
              />
            </div>
            <h2>SIMMAS</h2>
            <p>{schoolName}</p>
          </div>
          <div className="form-group">
            <label>📧 Alamat Email</label>
            <input
              className="form-control"
              type="email"
              placeholder="nama@gmail.com"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && handleLogin()}
            />
          </div>
          <div className="form-group" style={{ marginTop: 12 }}>
            <label>🔑 Password</label>
            <div style={{ position: "relative" }}>
              <input
                className="form-control"
                type={showPassword ? "text" : "password"}
                placeholder="Masukkan password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && handleLogin()}
                style={{ paddingRight: 40 }}
              />
              <button
                type="button"
                onClick={() => setShowPassword((v) => !v)}
                title={showPassword ? "Sembunyikan password" : "Tampilkan password"}
                style={{
                  position: "absolute", right: 8, top: "50%", transform: "translateY(-50%)",
                  background: "none", border: "none", cursor: "pointer", fontSize: 16,
                  color: "#94a3b8", padding: 4, lineHeight: 1,
                }}
              >
                {showPassword ? "⦻" : "👁"}
              </button>
            </div>
          </div>
          <p style={{ fontSize: 12, color: "#0ea5e9", textAlign: "right", marginTop: 8 }}>
            <Link href="/forgot-password">Lupa password?</Link>
          </p>
          {error && <div className="login-error">{error}</div>}
          <button className="login-btn" onClick={handleLogin} disabled={loading}>
            {loading ? "Memproses..." : "Masuk →"}
          </button>
          {/* Perbaikan Bug #13: hint sebelumnya menyiratkan domain email
              dibatasi per role (mis. "siswa: @student.sch.id"), padahal
              isValidEmailForRole() di src/lib/utils.js sudah tidak lagi
              membatasi domain per-role — email format apapun yang valid
              bisa dipakai role manapun. Hint baru ini netral dan akurat. */}
          <p style={{ fontSize: 11, color: "#94a3b8", textAlign: "center", marginTop: 16 }}>
            Gunakan email dan password yang telah didaftarkan oleh admin sekolah.
            <br />
            Format email bebas, contoh: nama@gmail.com / nama@sekolah.sch.id
          </p>
        </div>
      </div>
    </div>
  );
}
