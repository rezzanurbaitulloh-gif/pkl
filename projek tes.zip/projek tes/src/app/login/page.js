import LoginClient from "./LoginClient";
import { getPublicSchoolInfo } from "@/lib/publicSchoolInfo";

export const dynamic = "force-dynamic";

// Perbaikan Bug #12: ambil nama sekolah dari database (bukan hardcode
// "SMK Negeri 1 Kertosono"), supaya halaman login ikut berubah saat admin
// mengubah nama sekolah lewat menu Pengaturan.
export const metadata = {
  title: "Masuk - SIMMAS",
};

export default async function LoginPage() {
  const school = await getPublicSchoolInfo();
  return <LoginClient school={school} />;
}
