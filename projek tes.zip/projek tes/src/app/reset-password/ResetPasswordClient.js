"use client";

import { useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import Link from "next/link";

export default function ResetPasswordClient({ school }) {
  const router = useRouter();
  const searchParams = useSearchParams();
  const token = searchParams.get("token") || "";
  const schoolName = school?.nama || "Sekolah";

  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState("");
  const [sukses, setSukses] = useState("");
  const [loading, setLoading] = useState(false);

  const handleSubmit = async () => {
    setError("");
    setSukses("");

    if (!token) {
      setError("Token reset password tidak ditemukan. Gunakan link dari halaman lupa password.");
      return;
    }
    if (!password) {
      setError("Password baru wajib diisi.");
      return;
    }
    if (password.length < 6) {
      setError("Password minimal 6 karakter.");
      return;
    }
    if (password !== confirmPassword) {
      setError("Konfirmasi password tidak sesuai.");
      return;
    }

    setLoading(true);
    try {
      const res = await fetch("/api/auth/reset-password", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ token, password, confirmPassword }),
      });
      const data = await res.json();
      if (!res.ok) {
        setError(data.message || "Gagal mereset password.");
        return;
      }
      setSukses(data.message);
      setTimeout(() => router.push("/login"), 2000);
    } catch (err) {
      setError("Tidak dapat terhubung ke server.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="login-page">
      <div className="login-left">
        <h1>
          Sistem Manajemen
          <br />
          <span>Magang Siswa</span>
        </h1>
        <p>Buat password baru untuk akun Anda.</p>
      </div>
      <div className="login-right">
        <div className="login-box">
          <div className="login-logo">
            <div
              className="logo-circle"
              style={{ display: "flex", justifyContent: "center", alignItems: "center", background: "transparent" }}
            >
              <img
                src="/logo.png.webp"
                alt={`Logo ${schoolName}`}
                style={{ width: "60px", height: "auto", objectFit: "contain" }}
              />
            </div>
            <h2>Reset Password</h2>
            <p>Masukkan password baru Anda</p>
          </div>

          {!token && (
            <div className="login-error">
              Link tidak valid. Pastikan Anda membuka link reset password yang lengkap dari email/halaman lupa password.
            </div>
          )}

          <div className="form-group">
            <label>🔑 Password Baru</label>
            <div style={{ position: "relative" }}>
              <input
                className="form-control"
                type={showPassword ? "text" : "password"}
                placeholder="Minimal 6 karakter"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                style={{ paddingRight: 40 }}
              />
              <button
                type="button"
                onClick={() => setShowPassword((v) => !v)}
                title={showPassword ? "Sembunyikan password" : "Tampilkan password"}
                style={{
                  position: "absolute", right: 8, top: "50%", transform: "translateY(-50%)",
                  background: "none", border: "none", cursor: "pointer", fontSize: 16,
                  color: "#94a3b8", padding: 4, lineHeight: 1,
                }}
              >
                {showPassword ? "⦻" : "👁"}
              </button>
            </div>
          </div>

          <div className="form-group" style={{ marginTop: 12 }}>
            <label>🔑 Konfirmasi Password</label>
            <input
              className="form-control"
              type={showPassword ? "text" : "password"}
              placeholder="Ulangi password baru"
              value={confirmPassword}
              onChange={(e) => setConfirmPassword(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && handleSubmit()}
            />
          </div>

          {error && <div className="login-error">{error}</div>}
          {sukses && <div className="login-success">{sukses}</div>}

          <button className="login-btn" onClick={handleSubmit} disabled={loading || !token}>
            {loading ? "Memproses..." : "Simpan Password Baru →"}
          </button>

          <p style={{ fontSize: 12, color: "#64748b", textAlign: "center", marginTop: 16 }}>
            <Link href="/login">← Kembali ke halaman login</Link>
          </p>
        </div>
      </div>
    </div>
  );
}
