import { Suspense } from "react";
import ResetPasswordClient from "./ResetPasswordClient";
import { getPublicSchoolInfo } from "@/lib/publicSchoolInfo";

export const dynamic = "force-dynamic";

export default async function ResetPasswordPage() {
  // Perbaikan Bug #12: ambil nama sekolah dari database (bukan hardcode),
  // supaya halaman publik ini ikut berubah saat admin mengubah nama sekolah
  // lewat menu Pengaturan.
  const school = await getPublicSchoolInfo();
  return (
    <Suspense fallback={null}>
      <ResetPasswordClient school={school} />
    </Suspense>
  );
}
