import "./globals.css";

// Perbaikan Bug #12: deskripsi ini sebelumnya hardcode "SMK Negeri 1
// Kertosono". Next.js metadata di root layout dievaluasi saat build/request
// awal sebelum data sekolah sempat diambil, jadi dibuat generik (tidak
// merujuk nama sekolah tertentu) alih-alih hardcode nama yang bisa berbeda
// dari yang diatur admin lewat menu Pengaturan.
export const metadata = {
  title: "SIMMAS - Sistem Manajemen Magang Siswa",
  description: "Sistem Manajemen Magang Siswa untuk pengelolaan program PKL/magang secara digital.",
};

export const viewport = {
  width: "device-width",
  initialScale: 1,
};

export default function RootLayout({ children }) {
  return (
    <html lang="id">
      <body>{children}</body>
    </html>
  );
}
