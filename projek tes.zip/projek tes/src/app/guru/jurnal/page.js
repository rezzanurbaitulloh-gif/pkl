"use client";

import { useState, useEffect } from "react";
import Badge from "@/components/Badge";

const formatDate = (d) => d ? new Date(d).toLocaleDateString("id-ID",{day:"2-digit",month:"short",year:"numeric"}) : "-";

export default function GuruJurnalPage() {
  const [list, setList] = useState([]);
  const [search, setSearch] = useState("");
  const [modal, setModal] = useState(null);
  const [selected, setSelected] = useState(null);
  const [catatan, setCatatan] = useState("");
  const [loading, setLoading] = useState(false);

  const load = () => fetch("/api/guru/jurnal").then(r=>r.json()).then(d=>setList(Array.isArray(d)?d:[]));
  useEffect(()=>{ load(); },[]);

  const filtered = list.filter(l => {
    if (search && !l.siswa_nama?.toLowerCase().includes(search.toLowerCase()) && !l.kegiatan?.toLowerCase().includes(search.toLowerCase())) return false;
    return true;
  });

  const handleAction = async (status) => {
    setLoading(true);
    await fetch(`/api/guru/jurnal/${selected.id}`, { method:"PUT", headers:{"Content-Type":"application/json"}, body:JSON.stringify({status, catatan_guru:catatan}) });
    setLoading(false); setModal(null); load();
  };

  return (
    <div className="page">
      <div className="page-header"><h2>Approval Jurnal Harian</h2><p>Review dan setujui jurnal harian siswa bimbingan</p></div>
      <div className="stat-grid">
        {[{num:list.length,label:"Total Jurnal",sub:"Semua laporan"},{num:list.filter(l=>l.status==="menunggu").length,label:"Belum Diverifikasi",sub:"Menunggu review"},
          {num:list.filter(l=>l.status==="disetujui").length,label:"Disetujui",sub:"Sudah diverifikasi"},{num:list.filter(l=>l.status==="ditolak").length,label:"Ditolak",sub:"Perlu perbaikan"}
        ].map(s=><div className="stat-card" key={s.label}><div className="stat-num">{s.num}</div><div className="stat-label">{s.label}</div><div className="stat-sub">{s.sub}</div></div>)}
      </div>
      <div className="card">
        <div className="card-header"><h3>📋 Daftar Jurnal</h3></div>
        <div className="table-controls"><input className="search-input" placeholder="Cari siswa atau kegiatan..." value={search} onChange={e=>setSearch(e.target.value)} /></div>
        <table>
          <thead><tr><th>Siswa & Tanggal</th><th>Kegiatan & Kendala</th><th>Status</th><th>Catatan Guru</th><th>Aksi</th></tr></thead>
          <tbody>
            {filtered.map(l => (
              <tr key={l.id} className="jurnal-row">
                <td>
                  <div style={{fontWeight:600,fontSize:13}}>{l.siswa_nama}</div>
                  <div style={{fontSize:11,color:"#94a3b8"}}>NIS: {l.siswa_nis}</div>
                  <div style={{fontSize:11,color:"#94a3b8"}}>📅 {formatDate(l.tanggal)}</div>
                </td>
                <td>
                  <div style={{fontSize:12}}><strong>Kegiatan:</strong><br/>{l.kegiatan}</div>
                  {l.kendala&&<div style={{fontSize:12,marginTop:4}}><strong>Kendala:</strong><br/>{l.kendala}</div>}
                  {l.file_path&&(
                    <a href={l.file_path} target="_blank" rel="noreferrer" style={{fontSize:11,color:"#0ea5e9",marginTop:4,display:"inline-block"}} title="Lihat lampiran dari siswa">
                      📎 {l.file_name||"Lihat lampiran"}
                    </a>
                  )}
                </td>
                <td><Badge status={l.status} /></td>
                <td style={{fontSize:12}}>{l.catatan_guru?<span style={{background:"#f0fdf4",padding:"4px 8px",borderRadius:6}}>{l.catatan_guru}</span>:<span style={{color:"#94a3b8"}}>Belum ada</span>}</td>
                <td>
                  <div className="action-btns" style={{flexDirection:"column",gap:4}}>
                    <button className="btn-icon btn-view" onClick={()=>{setSelected(l);setCatatan(l.catatan_guru||"");setModal("view");}}>👁️</button>
                    {l.status==="menunggu"&&<>
                      <button className="btn-icon btn-approve" onClick={()=>{setSelected(l);setCatatan("");setModal("approve");}}>✅</button>
                      <button className="btn-icon btn-reject" onClick={()=>{setSelected(l);setCatatan("");setModal("reject");}}>❌</button>
                    </>}
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {modal==="view"&&selected&&(
        <div className="modal-overlay" onClick={e=>e.target===e.currentTarget&&setModal(null)}>
          <div className="modal">
            <div className="modal-header"><h3>📋 Detail Jurnal</h3><button className="close-btn" onClick={()=>setModal(null)}>×</button></div>
            <div className="modal-body">
              <div style={{background:"#f8fafc",borderRadius:8,padding:16,marginBottom:16}}>
                <div style={{fontWeight:600,marginBottom:4}}>{selected.siswa_nama} — {formatDate(selected.tanggal)}</div>
              </div>
              <div style={{marginBottom:12}}><label style={{fontWeight:600,fontSize:12}}>Kegiatan:</label><p style={{fontSize:13,marginTop:4}}>{selected.kegiatan}</p></div>
              {selected.kendala&&<div style={{marginBottom:12}}><label style={{fontWeight:600,fontSize:12}}>Kendala:</label><p style={{fontSize:13,color:"#f59e0b",marginTop:4}}>{selected.kendala}</p></div>}
              {selected.file_path&&(
                <div style={{marginBottom:12}}>
                  <label style={{fontWeight:600,fontSize:12}}>📎 Lampiran dari Siswa:</label>
                  {/\.(jpe?g|png|gif|webp)$/i.test(selected.file_path) ? (
                    <a href={selected.file_path} target="_blank" rel="noreferrer" style={{display:"block",marginTop:6}}>
                      <img src={selected.file_path} alt={selected.file_name||"Lampiran jurnal"} style={{maxWidth:"100%",maxHeight:300,borderRadius:8,border:"1px solid #e2e8f0"}} />
                    </a>
                  ) : (
                    <p style={{fontSize:13,marginTop:4}}>
                      <a href={selected.file_path} target="_blank" rel="noreferrer" style={{color:"#0ea5e9"}}>📄 {selected.file_name||"Lihat berkas"}</a>
                    </p>
                  )}
                </div>
              )}
              <div><label style={{fontWeight:600,fontSize:12}}>Status:</label><div style={{marginTop:4}}><Badge status={selected.status} /></div></div>
              {selected.catatan_guru&&<div style={{marginTop:12}}><label style={{fontWeight:600,fontSize:12}}>Catatan Guru:</label><p style={{fontSize:13,marginTop:4}}>{selected.catatan_guru}</p></div>}
            </div>
          </div>
        </div>
      )}

      {(modal==="approve"||modal==="reject")&&selected&&(
        <div className="modal-overlay" onClick={e=>e.target===e.currentTarget&&setModal(null)}>
          <div className="modal">
            <div className="modal-header"><h3>{modal==="approve"?"✅ Setujui Jurnal":"❌ Tolak Jurnal"}</h3><button className="close-btn" onClick={()=>setModal(null)}>×</button></div>
            <div className="modal-body">
              <p style={{fontSize:13,color:"#64748b",marginBottom:12}}>Jurnal: <strong>{selected.kegiatan?.substring(0,60)}...</strong></p>
              {selected.file_path&&(
                <p style={{fontSize:12,marginBottom:12}}>
                  <a href={selected.file_path} target="_blank" rel="noreferrer" style={{color:"#0ea5e9"}}>📎 Lihat lampiran: {selected.file_name||"berkas"}</a>
                </p>
              )}
              <div className="form-group"><label>📝 Catatan Guru (opsional)</label><textarea className="form-control" value={catatan} onChange={e=>setCatatan(e.target.value)} placeholder="Tambahkan catatan..." /></div>
            </div>
            <div className="modal-footer">
              <button className="btn btn-secondary" onClick={()=>setModal(null)}>Batal</button>
              {modal==="approve"
                ? <button className="btn btn-success" onClick={()=>handleAction("disetujui")} disabled={loading}>{loading?"...":"✅ Setujui"}</button>
                : <button className="btn btn-danger" onClick={()=>handleAction("ditolak")} disabled={loading}>{loading?"...":"❌ Tolak"}</button>
              }
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
