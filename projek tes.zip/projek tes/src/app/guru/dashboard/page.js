"use client";

import { useState, useEffect } from "react";
import Badge from "@/components/Badge";

const formatDate = (d) => d ? new Date(d).toLocaleDateString("id-ID",{day:"2-digit",month:"short",year:"numeric"}) : "-";

export default function GuruDashboardPage() {
  const [data, setData] = useState(null);

  useEffect(() => {
    fetch("/api/guru/stats").then(r=>r.json()).then(setData);
  }, []);

  if (!data) return <div className="page"><p style={{color:"#94a3b8"}}>Memuat data...</p></div>;

  return (
    <div className="page">
      <div className="page-header"><h2>Dashboard Guru</h2><p>Pantau dan kelola siswa bimbingan Anda</p></div>
      <div className="stat-grid">
        {[
          {num:data.stats?.total||0,label:"Total Siswa",sub:"Seluruh siswa bimbingan"},
          {num:data.stats?.aktif||0,label:"Magang Aktif",sub:"Sedang aktif magang"},
          {num:(data.magang||[]).filter(m=>m.nilai!=null).length,label:"Sudah Dinilai",sub:"Siswa dengan nilai"},
          {num:data.stats?.jurnal_hari_ini||0,label:"Jurnal Hari Ini",sub:"Laporan masuk hari ini"},
        ].map(s=><div className="stat-card" key={s.label}><div className="stat-num">{s.num}</div><div className="stat-label">{s.label}</div><div className="stat-sub">{s.sub}</div></div>)}
      </div>
      <div className="card">
        <div className="card-header"><h3>🎓 Siswa Magang Bimbingan</h3></div>
        <div className="card-body">
          {(data.magang||[]).length === 0 ? <p style={{color:"#94a3b8",fontSize:13}}>Belum ada data magang</p> :
            (data.magang||[]).slice(0,5).map(m => (
              <div className="magang-item" key={m.id}>
                <div style={{display:"flex",alignItems:"center",gap:10}}>
                  <div style={{width:36,height:36,borderRadius:"50%",background:"#38bdf8",display:"flex",alignItems:"center",justifyContent:"center",color:"#fff",fontWeight:700,fontSize:12}}>
                    {m.siswa_nama?.split(" ").slice(0,2).map(w=>w[0]).join("").toUpperCase()||"?"}
                  </div>
                  <div>
                    <div style={{fontWeight:600,fontSize:13}}>{m.siswa_nama||"-"}</div>
                    <div style={{fontSize:12,color:"#64748b"}}>{m.dudi_nama}</div>
                    <div style={{fontSize:11,color:"#94a3b8"}}>📅 {formatDate(m.tanggal_mulai)} - {formatDate(m.tanggal_selesai)}</div>
                  </div>
                </div>
                <Badge status={m.status} />
              </div>
            ))}
        </div>
      </div>
      <div className="card">
        <div className="card-header"><h3>📋 Jurnal Terbaru</h3></div>
        <div className="card-body">
          {(data.jurnal||[]).length === 0 ? <p style={{color:"#94a3b8",fontSize:13}}>Belum ada jurnal</p> :
            (data.jurnal||[]).slice(0,5).map(l => (
              <div className="logbook-item" key={l.id}>
                <div className="logbook-dot" />
                <div className="logbook-content">
                  <div className="logbook-text">{l.kegiatan}</div>
                  <div className="logbook-meta">📅 {formatDate(l.tanggal)} • {l.siswa_nama}</div>
                </div>
                <Badge status={l.status} />
              </div>
            ))}
        </div>
      </div>
    </div>
  );
}
