"use client";

import { useState, useEffect } from "react";
import Badge from "@/components/Badge";

const formatDate = (d) =>
  d
    ? new Date(d).toLocaleDateString("id-ID", { day: "2-digit", month: "short", year: "numeric" })
    : "-";

export default function GuruMagangPage() {
  const [list, setList] = useState([]);
  const [pendaftaran, setPendaftaran] = useState([]);
  const [search, setSearch] = useState("");
  const [modal, setModal] = useState(null);
  const [selected, setSelected] = useState(null);
  const [form, setForm] = useState({});
  const [nilaiInput, setNilaiInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [reviewForm, setReviewForm] = useState({});
  const [error, setError] = useState("");

  const load = () => {
    fetch("/api/guru/magang").then((r) => r.json()).then((d) => setList(Array.isArray(d) ? d : []));
    fetch("/api/guru/pendaftaran").then((r) => r.json()).then((d) => setPendaftaran(Array.isArray(d) ? d : []));
  };
  useEffect(() => { load(); }, []);

  const pendingPendaftaran = pendaftaran.filter((p) => p.status === "pending");

  const filtered = list.filter(
    (m) =>
      !search ||
      m.siswa_nama?.toLowerCase().includes(search.toLowerCase()) ||
      m.dudi_nama?.toLowerCase().includes(search.toLowerCase())
  );
  const filteredPendaftaran = pendingPendaftaran.filter(
    (p) =>
      !search ||
      p.siswa_nama?.toLowerCase().includes(search.toLowerCase()) ||
      p.dudi_nama?.toLowerCase().includes(search.toLowerCase())
  );

  const openStatus = (m) => {
    setSelected(m);
    setForm({
      status: m.status,
      tanggal_mulai: m.tanggal_mulai || "",
      tanggal_selesai: m.tanggal_selesai || "",
      catatan: m.catatan || "",
    });
    setError("");
    setModal("status");
  };
  const openNilai = (m) => {
    setSelected(m);
    setNilaiInput(m.nilai || "");
    setModal("nilai");
  };
  const openReview = (p) => {
    setSelected(p);
    setError("");
    setReviewForm({
      tanggal_mulai: new Date().toISOString().slice(0, 10),
      tanggal_selesai: "",
      catatan: "",
    });
    setModal("review");
  };

  const saveStatus = async () => {
    // Validasi: jika dibatalkan, wajib ada alasan
    if (form.status === "dibatalkan" && (!form.catatan || form.catatan.trim() === "")) {
      setError("Alasan pemberhentian wajib diisi ketika membatalkan magang siswa.");
      return;
    }
    setLoading(true);
    setError("");
    try {
      const res = await fetch(`/api/guru/magang/${selected.id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form),
      });
      const data = await res.json();
      if (!res.ok) {
        setError(data.message || "Gagal memperbarui status.");
        return;
      }
      setModal(null);
      load();
    } finally {
      setLoading(false);
    }
  };

  const saveNilai = async () => {
    const n = parseInt(nilaiInput);
    if (isNaN(n) || n < 0 || n > 100) return alert("Nilai harus antara 0-100");
    setLoading(true);
    await fetch(`/api/guru/magang/${selected.id}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ nilai: n }),
    });
    setLoading(false);
    setModal(null);
    load();
  };

  const reviewPendaftaran = async (status) => {
    // Perbaikan Bug #5: validasi di sisi frontend juga, supaya guru langsung
    // tahu sebelum request dikirim (backend tetap menjadi sumber kebenaran
    // utama validasi ini).
    if (status === "ditolak" && (!reviewForm.catatan || !reviewForm.catatan.trim())) {
      setError("Catatan/alasan penolakan wajib diisi agar siswa mengetahui alasan sebenarnya.");
      return;
    }
    setLoading(true);
    setError("");
    try {
      const res = await fetch(`/api/guru/pendaftaran/${selected.id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ status, ...reviewForm }),
      });
      const data = await res.json();
      if (!res.ok) {
        setError(data.message || "Gagal memproses pendaftaran");
        return;
      }
      setModal(null);
      load();
    } finally {
      setLoading(false);
    }
  };

  const isDibatalkan = form.status === "dibatalkan";

  return (
    <div className="page">
      <div className="page-header">
        <h2>Manajemen Siswa Magang</h2>
        <p>Kelola magang, tinjau pendaftaran, dan beri nilai siswa bimbingan</p>
      </div>
      <div className="stat-grid">
        {[
          { num: list.length, label: "Total Siswa" },
          { num: list.filter((m) => m.status === "aktif").length, label: "Magang Aktif" },
          { num: pendingPendaftaran.length, label: "Pending" },
          {
            num:
              list.filter((m) => m.nilai != null).length > 0
                ? Math.round(
                    list.filter((m) => m.nilai != null).reduce((a, m) => a + m.nilai, 0) /
                      list.filter((m) => m.nilai != null).length
                  )
                : 0,
            label: "Rata-rata Nilai",
          },
        ].map((s) => (
          <div className="stat-card" key={s.label}>
            <div className="stat-num">{s.num}</div>
            <div className="stat-label">{s.label}</div>
          </div>
        ))}
      </div>

      <div className="card">
        <div className="card-header">
          <h3>📋 Daftar Magang Siswa Bimbingan</h3>
        </div>
        <div className="table-controls">
          <input
            className="search-input"
            placeholder="Cari siswa atau DUDI..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>
        <table>
          <thead>
            <tr>
              <th>Siswa</th>
              <th>DUDI</th>
              <th>Periode</th>
              <th>Status</th>
              <th>Nilai</th>
              <th>Aksi</th>
            </tr>
          </thead>
          <tbody>
            {filteredPendaftaran.map((p) => (
              <tr key={`pendaftaran-${p.id}`}>
                <td>🎓 {p.siswa_nama || "-"}</td>
                <td>🏢 {p.dudi_nama || "-"}</td>
                <td style={{ fontSize: 12 }}>📅 –</td>
                <td>
                  <Badge status={p.status} />
                </td>
                <td>–</td>
                <td>
                  <div className="action-btns">
                    <button className="btn btn-warning btn-sm" onClick={() => openReview(p)}>
                      📝 Tinjau
                    </button>
                  </div>
                </td>
              </tr>
            ))}
            {filtered.map((m) => (
              <tr key={`magang-${m.id}`}>
                <td>🎓 {m.siswa_nama || "-"}</td>
                <td>🏢 {m.dudi_nama || "-"}</td>
                <td style={{ fontSize: 12 }}>
                  📅 {formatDate(m.tanggal_mulai)} – {formatDate(m.tanggal_selesai)}
                </td>
                <td>
                  <Badge status={m.status} />
                </td>
                <td>{m.nilai != null ? <strong>{m.nilai}</strong> : "–"}</td>
                <td>
                  <div className="action-btns">
                    {m.status !== "dibatalkan" && m.status !== "selesai" && (
                      <button className="btn btn-success btn-sm" onClick={() => openStatus(m)}>
                        ✅ Update
                      </button>
                    )}
                    {m.status === "dibatalkan" && (
                      <span style={{ fontSize: 12, color: "#ef4444" }}>❌ Dibatalkan</span>
                    )}
                    {m.status === "selesai" && (
                      <button className="btn btn-purple btn-sm" onClick={() => openNilai(m)}>
                        🏆 Nilai
                      </button>
                    )}
                  </div>
                </td>
              </tr>
            ))}
            {filtered.length === 0 && filteredPendaftaran.length === 0 && (
              <tr>
                <td colSpan={6} style={{ textAlign: "center", color: "#94a3b8", padding: "20px 0" }}>
                  Belum ada data siswa bimbingan
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      {/* MODAL: Tinjau Pendaftaran */}
      {modal === "review" && (
        <div className="modal-overlay" onClick={(e) => e.target === e.currentTarget && setModal(null)}>
          <div className="modal">
            <div className="modal-header">
              <h3>📝 Tinjau Permintaan Magang</h3>
              <button className="close-btn" onClick={() => setModal(null)}>×</button>
            </div>
            <div className="modal-body">
              <p style={{ fontSize: 13, color: "#64748b", marginBottom: 12 }}>
                <strong>{selected?.siswa_nama}</strong> ({selected?.siswa_nis}) — {selected?.siswa_kelas}{" "}
                {selected?.siswa_jurusan}
                <br />
                ingin magang di <strong>{selected?.dudi_nama}</strong>
                <br />
                📍 {selected?.dudi_alamat}
                <br />
                📅 Tanggal daftar: {formatDate(selected?.tanggal_daftar)}
              </p>
              <div className="form-grid">
                <div className="form-group">
                  <label>Tanggal Mulai</label>
                  <input
                    className="form-control"
                    type="date"
                    value={reviewForm.tanggal_mulai || ""}
                    onChange={(e) => setReviewForm({ ...reviewForm, tanggal_mulai: e.target.value })}
                  />
                </div>
                <div className="form-group">
                  <label>Tanggal Selesai</label>
                  <input
                    className="form-control"
                    type="date"
                    value={reviewForm.tanggal_selesai || ""}
                    onChange={(e) => setReviewForm({ ...reviewForm, tanggal_selesai: e.target.value })}
                  />
                </div>
                <div className="form-group full">
                  <label>
                    Catatan <span style={{ color: "#94a3b8", fontWeight: 400 }}>(wajib diisi jika menolak)</span>
                  </label>
                  <textarea
                    className={`form-control ${error && !reviewForm.catatan?.trim() ? "input-error" : ""}`}
                    placeholder="Jika menerima: catatan tambahan (opsional). Jika menolak: jelaskan alasan penolakan (wajib)."
                    value={reviewForm.catatan || ""}
                    onChange={(e) => {
                      setReviewForm({ ...reviewForm, catatan: e.target.value });
                      if (e.target.value.trim()) setError("");
                    }}
                  />
                  <small style={{ color: "#94a3b8", fontSize: 11, marginTop: 4, display: "block" }}>
                    ⚠️ Jika Anda menolak pendaftaran, catatan ini akan ditampilkan ke siswa sebagai alasan penolakan.
                  </small>
                </div>
              </div>
              <p style={{ fontSize: 12, color: "#94a3b8", marginTop: 8 }}>
                Jika diterima, data magang aktif akan otomatis dibuat dan pendaftaran ke tempat lain akan otomatis
                dibatalkan.
              </p>
              {error && <div className="form-error">⚠️ {error}</div>}
            </div>
            <div className="modal-footer">
              <button className="btn btn-danger" disabled={loading} onClick={() => reviewPendaftaran("ditolak")}>
                ⛔ Tolak
              </button>
              <button className="btn btn-primary" disabled={loading} onClick={() => reviewPendaftaran("diterima")}>
                {loading ? "Memproses..." : "✅ Terima"}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL: Update Status Magang */}
      {modal === "status" && (
        <div className="modal-overlay" onClick={(e) => e.target === e.currentTarget && setModal(null)}>
          <div className="modal">
            <div className="modal-header">
              <h3>📊 Update Status Magang</h3>
              <button className="close-btn" onClick={() => setModal(null)}>×</button>
            </div>
            <div className="modal-body">
              <p style={{ fontSize: 13, color: "#64748b", marginBottom: 12 }}>
                Siswa: <strong>{selected?.siswa_nama}</strong> — {selected?.dudi_nama}
              </p>
              <div className="form-grid">
                <div className="form-group full">
                  <label>Status</label>
                  <select
                    className="form-control"
                    value={form.status || ""}
                    onChange={(e) => {
                      setForm({ ...form, status: e.target.value });
                      setError("");
                    }}
                  >
                    <option value="aktif">Aktif</option>
                    <option value="selesai">Selesai</option>
                    <option value="dibatalkan">Dibatalkan / Diberhentikan</option>
                  </select>
                </div>
                <div className="form-group">
                  <label>Tanggal Mulai</label>
                  <input
                    className="form-control"
                    type="date"
                    value={form.tanggal_mulai || ""}
                    onChange={(e) => setForm({ ...form, tanggal_mulai: e.target.value })}
                  />
                </div>
                <div className="form-group">
                  <label>Tanggal Selesai</label>
                  <input
                    className="form-control"
                    type="date"
                    value={form.tanggal_selesai || ""}
                    onChange={(e) => setForm({ ...form, tanggal_selesai: e.target.value })}
                  />
                </div>
                <div className="form-group full">
                  <label>
                    {isDibatalkan ? (
                      <span>
                        Alasan Pemberhentian <span style={{ color: "#ef4444" }}>*</span>
                      </span>
                    ) : (
                      "Catatan"
                    )}
                  </label>
                  <textarea
                    className={`form-control ${isDibatalkan && error ? "input-error" : ""}`}
                    placeholder={
                      isDibatalkan
                        ? "Wajib diisi: jelaskan alasan siswa diberhentikan dari tempat magang ini..."
                        : "Catatan tambahan (opsional)"
                    }
                    value={form.catatan || ""}
                    onChange={(e) => {
                      setForm({ ...form, catatan: e.target.value });
                      if (e.target.value.trim()) setError("");
                    }}
                    rows={isDibatalkan ? 3 : 2}
                  />
                  {isDibatalkan && (
                    <small style={{ color: "#94a3b8", fontSize: 11, marginTop: 4, display: "block" }}>
                      ⚠️ Alasan ini akan ditampilkan kepada siswa sebagai pemberitahuan pemberhentian.
                    </small>
                  )}
                </div>
              </div>
              {error && <div className="form-error">⚠️ {error}</div>}
              {isDibatalkan && (
                <div className="notice notice-warning" style={{ marginTop: 12 }}>
                  <strong>⚠️ Perhatian:</strong> Siswa akan mendapat notifikasi pemberhentian dan dapat mendaftar
                  magang kembali ke tempat lain.
                </div>
              )}
            </div>
            <div className="modal-footer">
              <button className="btn btn-secondary" onClick={() => setModal(null)}>
                Batal
              </button>
              <button
                className={`btn ${isDibatalkan ? "btn-danger" : "btn-primary"}`}
                onClick={saveStatus}
                disabled={loading}
              >
                {loading ? "Menyimpan..." : isDibatalkan ? "❌ Konfirmasi Pemberhentian" : "Simpan"}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL: Input Nilai */}
      {modal === "nilai" && (
        <div className="modal-overlay" onClick={(e) => e.target === e.currentTarget && setModal(null)}>
          <div className="modal">
            <div className="modal-header">
              <h3>🏆 Input Nilai Akhir</h3>
              <button className="close-btn" onClick={() => setModal(null)}>×</button>
            </div>
            <div className="modal-body">
              <p style={{ fontSize: 13, color: "#64748b", marginBottom: 16 }}>
                Berikan nilai akhir untuk <strong>{selected?.siswa_nama}</strong>
              </p>
              <div className="form-group">
                <label>Nilai (0-100)</label>
                <input
                  className="form-control"
                  type="number"
                  min="0"
                  max="100"
                  value={nilaiInput}
                  onChange={(e) => setNilaiInput(e.target.value)}
                />
              </div>
            </div>
            <div className="modal-footer">
              <button className="btn btn-secondary" onClick={() => setModal(null)}>
                Batal
              </button>
              <button className="btn btn-primary" onClick={saveNilai} disabled={loading}>
                {loading ? "Menyimpan..." : "Simpan Nilai"}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
