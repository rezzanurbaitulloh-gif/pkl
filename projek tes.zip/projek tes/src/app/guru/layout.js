import { redirect } from "next/navigation";
import { getCurrentGuru } from "@/lib/auth";
import { getPublicSchoolInfo } from "@/lib/publicSchoolInfo";
import GuruLayoutClient from "./GuruLayoutClient";

export default async function GuruLayout({ children }) {
  const guru = await getCurrentGuru();
  if (!guru) redirect("/login");

  // Perbaikan Bug #12: ambil nama sekolah asli dari database, bukan
  // hardcode, supaya render pertama (sebelum useSchoolInfo() selesai fetch
  // di client) sudah menampilkan nama yang benar.
  const school = await getPublicSchoolInfo();

  return (
    <GuruLayoutClient schoolName={school.nama} user={{ nama: guru.user_nama || guru.nama }}>
      {children}
    </GuruLayoutClient>
  );
}
