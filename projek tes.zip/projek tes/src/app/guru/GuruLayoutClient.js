"use client";

import { useState } from "react";
import GuruSidebar from "@/components/GuruSidebar";
import GuruTopbar from "@/components/GuruTopbar";

export default function GuruLayoutClient({ schoolName, user, children }) {
  const [sidebarOpen, setSidebarOpen] = useState(false);

  return (
    <div className="app">
      <GuruSidebar
        schoolName={schoolName}
        isOpen={sidebarOpen}
        onClose={() => setSidebarOpen(false)}
      />
      <div className="main-content">
        <GuruTopbar
          schoolName={schoolName}
          user={user}
          onMenuToggle={() => setSidebarOpen((prev) => !prev)}
        />
        {children}
      </div>
    </div>
  );
}
