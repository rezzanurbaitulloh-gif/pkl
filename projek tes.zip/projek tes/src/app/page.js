import Link from "next/link";
import { getPublicSchoolInfo } from "@/lib/publicSchoolInfo";

export const metadata = {
  title: "SIMMAS - Sistem Manajemen Magang Siswa",
  description: "Platform terpadu untuk mengelola program magang siswa SMK secara digital, efisien, dan transparan.",
};

export default async function LandingPage() {
  // Perbaikan Bug #12: ambil nama sekolah dari database (bukan hardcode
  // "SMK Negeri 1 Kertosono"), supaya landing page ikut berubah saat admin
  // mengubah nama sekolah lewat menu Pengaturan.
  const school = await getPublicSchoolInfo();
  const schoolName = school?.nama || "Sekolah";
  const currentYear = new Date().getFullYear();
  const features = [
    {
      icon: "🎓",
      title: "Manajemen Data Siswa",
      desc: "Kelola profil, penempatan, dan status magang setiap siswa secara terpusat.",
    },
    {
      icon: "📡",
      title: "Monitoring Kegiatan",
      desc: "Pantau kehadiran dan progres harian siswa secara real-time dari mana saja.",
    },
    {
      icon: "📋",
      title: "Logbook Digital",
      desc: "Pencatatan jurnal kegiatan harian siswa yang terstruktur dan dapat divalidasi.",
    },
    {
      icon: "🖥️",
      title: "Dashboard Guru Pembimbing",
      desc: "Antarmuka khusus guru untuk memantau siswa bimbingan dan memberikan catatan.",
    },
    {
      icon: "🏢",
      title: "Portal Perusahaan Mitra",
      desc: "Akses mandiri bagi DUDI untuk mencatat absensi dan memberikan evaluasi performa.",
    },
    {
      icon: "📊",
      title: "Laporan & Export PDF",
      desc: "Hasilkan laporan akhir magang yang komprehensif dan siap cetak dalam hitungan detik.",
    },
  ];

  const steps = [
    {
      num: "01",
      title: "Daftar / Login",
      desc: "Siswa, guru, dan perwakilan perusahaan mendaftar dan masuk ke platform sesuai peran masing-masing.",
    },
    {
      num: "02",
      title: "Input Data Magang",
      desc: "Admin sekolah mengatur jadwal, penempatan, dan mencocokkan siswa dengan perusahaan mitra.",
    },
    {
      num: "03",
      title: "Monitoring Kegiatan",
      desc: "Siswa mencatat logbook harian, guru memvalidasi, dan perusahaan merekam kehadiran.",
    },
    {
      num: "04",
      title: "Laporan & Evaluasi",
      desc: "Semua pihak memberikan penilaian akhir dan sistem menghasilkan laporan magang otomatis.",
    },
  ];

  const benefits = [
    {
      role: "Siswa",
      icon: "🎓",
      color: "#38bdf8",
      items: [
        "Logbook digital yang mudah diisi",
        "Informasi penempatan yang transparan",
        "Akses ke catatan penilaian instruktur",
      ],
    },
    {
      role: "Guru Pembimbing",
      icon: "👨‍🏫",
      color: "#a78bfa",
      items: [
        "Dashboard pemantauan real-time",
        "Validasi logbook mudah dan cepat",
        "Rekap nilai akhir otomatis",
      ],
    },
    {
      role: "Sekolah",
      icon: "🏫",
      color: "#34d399",
      items: [
        "Data siswa dan DUDI tersentralisasi",
        "Laporan kegiatan satu pintu",
        "Mendukung kelengkapan akreditasi",
      ],
    },
    {
      role: "Perusahaan Mitra",
      icon: "🏢",
      color: "#fb923c",
      items: [
        "Absensi digital berbasis sistem",
        "Komunikasi terarah dengan guru",
        "Penilaian siswa magang yang terstandar",
      ],
    },
  ];

  return (
    <div className="landing-page">
      {/* NAVBAR */}
      <nav className="landing-nav">
        <div className="landing-nav-inner">
          <div className="landing-nav-brand">
            <div className="logo-circle" style={{ display: "flex", justifyContent: "center", alignItems: "center", background: "transparent" }}>
              <img 
                src="/logo.png.webp" 
                alt={`Logo ${schoolName}`}
                style={{ width: "30px", height: "auto", objectFit: "contain" }} 
              />
            </div>
            <span>SIMMAS</span>
          </div>
          <div className="landing-nav-links">
            <a href="#features">Fitur</a>
            <a href="#how-it-works">Cara Kerja</a>
            <a href="#benefits">Manfaat</a>
          </div>
          <Link href="/login" className="landing-nav-cta">
            Masuk →
          </Link>
        </div>
      </nav>

      {/* HERO */}
      <section className="landing-hero" id="home">
        <div className="landing-hero-badge">Platform Magang Siswa SMK</div>
        <h1 className="landing-hero-title">
          Kelola Program Magang<br />
          <span>Lebih Cerdas</span>
        </h1>
        <p className="landing-hero-desc">
          SIMMAS menghubungkan siswa, guru pembimbing, dan perusahaan mitra dalam satu
          sistem yang modern, transparan, dan mudah digunakan.
        </p>
        <div className="landing-hero-actions">
          <Link href="/login" className="landing-btn-primary">
            Mulai Sekarang →
          </Link>
          <a href="#features" className="landing-btn-outline">
            Pelajari Lebih Lanjut
          </a>
        </div>
        <div className="landing-hero-stats">
          <div className="landing-stat">
            <strong>3</strong>
            <span>Peran Pengguna</span>
          </div>
          <div className="landing-stat-divider" />
          <div className="landing-stat">
            <strong>100%</strong>
            <span>Digital</span>
          </div>
          <div className="landing-stat-divider" />
          <div className="landing-stat">
            <strong>Real-time</strong>
            <span>Monitoring</span>
          </div>
        </div>
      </section>

      {/* FEATURES */}
      <section className="landing-section" id="features">
        <div className="landing-section-inner">
          <div className="landing-section-header">
            <div className="landing-section-badge">Fitur Utama</div>
            <h2>Semua yang Anda Butuhkan</h2>
            <p>
              SIMMAS menyediakan infrastruktur digital yang solid dari tahap penempatan
              hingga pelaporan akhir magang.
            </p>
          </div>
          <div className="landing-features-grid">
            {features.map((f) => (
              <div className="landing-feature-card" key={f.title}>
                <div className="landing-feature-icon">{f.icon}</div>
                <h3>{f.title}</h3>
                <p>{f.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* HOW IT WORKS */}
      <section className="landing-section landing-section-dark" id="how-it-works">
        <div className="landing-section-inner">
          <div className="landing-section-header">
            <div className="landing-section-badge">Cara Kerja</div>
            <h2>Alur Sistem yang Jelas</h2>
          </div>
          <div className="landing-steps">
            {steps.map((s, i) => (
              <div className="landing-step" key={s.num}>
                <div className="landing-step-num">{s.num}</div>
                {i < steps.length - 1 && <div className="landing-step-line" />}
                <div className="landing-step-content">
                  <h3>{s.title}</h3>
                  <p>{s.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* BENEFITS */}
      <section className="landing-section" id="benefits">
        <div className="landing-section-inner">
          <div className="landing-section-header">
            <div className="landing-section-badge">Manfaat</div>
            <h2>Dirancang untuk Semua Pihak</h2>
            <p>
              Setiap aktor dalam ekosistem magang mendapatkan nilai nyata dari SIMMAS.
            </p>
          </div>
          <div className="landing-benefits-grid">
            {benefits.map((b) => (
              <div className="landing-benefit-card" key={b.role}>
                <div className="landing-benefit-icon" style={{ background: b.color + "22", color: b.color }}>
                  {b.icon}
                </div>
                <h3>{b.role}</h3>
                <ul>
                  {b.items.map((item) => (
                    <li key={item}>
                      <span className="landing-check" style={{ color: b.color }}>✓</span>
                      {item}
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA BANNER */}
      <section className="landing-cta-section">
        <div className="landing-cta-inner">
          <h2>Siap Digitalisasi Program Magang Anda?</h2>
          <p>
            Bergabunglah dan kelola kegiatan PKL/magang siswa secara profesional,
            transparan, dan terukur.
          </p>
          <Link href="/login" className="landing-btn-white">
            Mulai Gunakan SIMMAS →
          </Link>
        </div>
      </section>

      {/* FOOTER */}
      <footer className="landing-footer" id="contact">
        <div className="landing-footer-inner">
          <div className="landing-footer-brand">
            <div className="landing-footer-logo">
            <div className="logo-circle" style={{ display: "flex", justifyContent: "center", alignItems: "center", background: "transparent" }}>
              <img 
                src="/logo.png.webp" 
                alt={`Logo ${schoolName}`}
                style={{ width: "60px", height: "auto", objectFit: "contain" }} 
              />
            </div>
                          <span>SIMMAS</span>
            </div>
            <p>
              Sistem informasi terpadu untuk manajemen dan pelaporan program magang
              siswa SMK secara profesional.
            </p>
          </div>
          <div className="landing-footer-links">
            <div>
              <strong>Product</strong>
              <a href="#features">Fitur</a>
              <a href="#how-it-works">Cara Kerja</a>
              <a href="#benefits">Manfaat</a>
            </div>
            <div>
              <strong>Platform</strong>
              <Link href="/login">Login</Link>
              {/* Perbaikan Bug #15: sebelumnya href="#" (tidak mengarah ke
                  mana pun). Sekarang mengarah ke halaman panduan pengguna
                  yang sungguhan. */}
              <Link href="/panduan">Panduan Pengguna</Link>
            </div>
            <div>
              <strong>Proyek</strong>
              <span>UKK SMK Project</span>
              <span>SMK Pusat Keunggulan</span>
            </div>
          </div>
        </div>
        <div className="landing-footer-bottom">
          <span>© {currentYear} SIMMAS — {schoolName}. All rights reserved.</span>
        </div>
      </footer>
    </div>
  );
}
