import { redirect } from "next/navigation";
import { getCurrentAdmin } from "@/lib/auth";
import { getPublicSchoolInfo } from "@/lib/publicSchoolInfo";
import AdminLayoutClient from "./AdminLayoutClient";

export default async function AdminLayout({ children }) {
  const admin = await getCurrentAdmin();
  if (!admin) redirect("/login");

  // Perbaikan Bug #12: sebelumnya nama sekolah di sini di-hardcode
  // ("SMK Negeri 1 Surabaya"), terlihat sekilas (flash) sebelum
  // useSchoolInfo() di sisi client selesai mengambil data asli dari
  // /api/settings. Sekarang nilai awal juga diambil dari database lewat
  // server component, sehingga render pertama sudah langsung benar.
  const school = await getPublicSchoolInfo();

  return (
    <AdminLayoutClient schoolName={school.nama} user={{ nama: admin.nama }}>
      {children}
    </AdminLayoutClient>
  );
}
