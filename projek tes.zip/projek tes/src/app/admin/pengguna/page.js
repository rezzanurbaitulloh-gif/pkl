"use client";

import { useState, useEffect } from "react";
import Badge from "@/components/Badge";
import { isValidEmailForRole, emailFormatHint } from "@/lib/utils";

const getInitials = n => n?.split(" ").slice(0,2).map(w=>w[0]).join("").toUpperCase() || "?";

export default function AdminPenggunaPage() {
  const [list, setList] = useState([]);
  const [search, setSearch] = useState("");
  const [filterRole, setFilterRole] = useState("");
  const [modal, setModal] = useState(null);
  const [selected, setSelected] = useState(null);
  const [form, setForm] = useState({});
  const [confirmPassword, setConfirmPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const load = () => fetch("/api/admin/pengguna").then(r=>r.json()).then(d=>setList(Array.isArray(d)?d:[]));
  useEffect(()=>{ load(); },[]);

  const filtered = list.filter(u => {
    if (search && !u.nama?.toLowerCase().includes(search.toLowerCase()) && !u.email?.toLowerCase().includes(search.toLowerCase())) return false;
    if (filterRole && u.role !== filterRole) return false;
    return true;
  });

  const openAdd = () => { setForm({ role:"siswa", verified:true }); setConfirmPassword(""); setError(""); setModal("add"); };
  const openEdit = (u) => { setSelected(u); setForm({...u, password:""}); setConfirmPassword(""); setError(""); setModal("edit"); };
  const handleDelete = async (id) => {
    if (id===1) return alert("Admin utama tidak dapat dihapus");
    if (!confirm("Hapus user ini?")) return;
    await fetch(`/api/admin/pengguna/${id}`, { method:"DELETE" });
    load();
  };

  const handleSave = async () => {
    setError("");
    if (!form.nama || !form.email) return setError("Nama dan email wajib diisi");
    if (!isValidEmailForRole(form.email, form.role)) return setError("Format email tidak valid");

    const password = form.password || "";
    if (modal === "add") {
      if (!password) return setError("Password wajib diisi");
      if (password.length < 6) return setError("Password minimal 6 karakter");
      if (password !== confirmPassword) return setError("Konfirmasi password tidak sesuai");
    } else if (password) {
      if (password.length < 6) return setError("Password minimal 6 karakter");
      if (password !== confirmPassword) return setError("Konfirmasi password tidak sesuai");
    }

    setLoading(true);
    try {
      const payload = { ...form, confirmPassword };
      const res = modal==="add"
        ? await fetch("/api/admin/pengguna", { method:"POST", headers:{"Content-Type":"application/json"}, body:JSON.stringify(payload) })
        : await fetch(`/api/admin/pengguna/${selected.id}`, { method:"PUT", headers:{"Content-Type":"application/json"}, body:JSON.stringify(payload) });
      const data = await res.json();
      if (!res.ok) { setError(data.message || "Gagal menyimpan"); return; }
      setModal(null); load();
    } finally { setLoading(false); }
  };

  return (
    <div className="page">
      <div className="page-header"><h2>Manajemen User</h2><p>Kelola akun pengguna sistem</p></div>
      <div className="card">
        <div className="card-header"><h3>👥 Daftar User</h3><button className="btn btn-primary" onClick={openAdd}>+ Tambah User</button></div>
        <div className="table-controls">
          <input className="search-input" placeholder="Cari nama atau email..." value={search} onChange={e=>setSearch(e.target.value)} />
          <select className="filter-select" value={filterRole} onChange={e=>setFilterRole(e.target.value)}>
            <option value="">Semua Role</option><option value="admin">Admin</option><option value="guru">Guru</option><option value="siswa">Siswa</option>
          </select>
        </div>
        <table>
          <thead><tr><th>User</th><th>Email</th><th>Role</th><th>Verifikasi</th><th>Terdaftar</th><th>Aksi</th></tr></thead>
          <tbody>
            {filtered.map(u => (
              <tr key={u.id}>
                <td><div style={{display:"flex",alignItems:"center",gap:8}}>
                  <div className="user-avatar" style={{width:32,height:32,fontSize:12,background:"#38bdf8",borderRadius:"50%",display:"flex",alignItems:"center",justifyContent:"center",color:"#fff",fontWeight:700}}>{getInitials(u.nama)}</div>
                  <div><div style={{fontWeight:600,fontSize:13}}>{u.nama}</div><div style={{fontSize:11,color:"#94a3b8"}}>ID {u.id}</div></div>
                </div></td>
                <td style={{fontSize:12}}>📧 {u.email}</td>
                <td><Badge status={u.role} /></td>
                <td>{u.verified ? <span className="badge badge-disetujui">Terverifikasi</span> : <span className="badge badge-menunggu">Tidak Terverifikasi</span>}</td>
                <td style={{fontSize:12}}>{u.created_at?.split("T")[0]||"-"}</td>
                <td><div className="action-btns"><button className="btn-icon btn-edit" onClick={()=>openEdit(u)}>✏️</button><button className="btn-icon btn-del" onClick={()=>handleDelete(u.id)}>🗑️</button></div></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {modal && (
        <div className="modal-overlay" onClick={e=>e.target===e.currentTarget&&setModal(null)}>
          <div className="modal">
            <div className="modal-header"><h3>{modal==="add"?"➕ Tambah User":"✎ Edit User"}</h3><button className="close-btn" onClick={()=>setModal(null)}>×</button></div>
            <div className="modal-body">
              <div className="form-grid" style={{gridTemplateColumns:"1fr"}}>
                <div className="form-group"><label>Nama Lengkap *</label><input className="form-control" value={form.nama||""} onChange={e=>setForm({...form,nama:e.target.value})} /></div>
                <div className="form-group"><label>Role *</label>
                  <select className="form-control" value={form.role||"siswa"} onChange={e=>setForm({...form,role:e.target.value})}>
                    <option value="siswa">Siswa</option><option value="guru">Guru</option><option value="admin">Admin</option>
                  </select>
                </div>
                <div className="form-group">
                  <label>Email *</label>
                  <input className="form-control" type="email" placeholder={emailFormatHint(form.role).replace("contoh: ","")} value={form.email||""} onChange={e=>setForm({...form,email:e.target.value})} />
                  <small style={{color:"#94a3b8"}}>{emailFormatHint(form.role)}</small>
                </div>
                <div className="form-group"><label>Email Verification</label>
                  <select className="form-control" value={form.verified ? "1" : "0"} onChange={e=>setForm({...form,verified: e.target.value==="1"})}>
                    <option value="1">Terverifikasi</option>
                    <option value="0">Tidak Terverifikasi</option>
                  </select>
                </div>
                <div className="form-group"><label>Password {modal==="edit"?"(kosongkan jika tidak diubah)":"*"} — min 6 karakter</label>
                  <input className="form-control" type="password" value={form.password||""} onChange={e=>setForm({...form,password:e.target.value})} />
                </div>
                <div className="form-group"><label>Konfirmasi Password {modal==="edit"?"":"*"}</label>
                  <input className="form-control" type="password" value={confirmPassword} onChange={e=>setConfirmPassword(e.target.value)} />
                </div>
              </div>
              {error && <div className="form-error" style={{marginTop:10}}>⚠️ {error}</div>}
            </div>
            <div className="modal-footer">
              <button className="btn btn-secondary" onClick={()=>setModal(null)}>Batal</button>
              <button className="btn btn-primary" onClick={handleSave} disabled={loading}>{loading?"Menyimpan...":"Simpan"}</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
