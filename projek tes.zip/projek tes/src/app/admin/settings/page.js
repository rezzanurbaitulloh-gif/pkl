"use client";

import { useEffect, useRef, useState, useCallback } from "react";
import { broadcastSchoolUpdated } from "@/lib/useSchoolInfo";

const FIELDS = [
  { key: "nama",    label: "🏫 Nama Sekolah" },
  { key: "kepala",  label: "👤 Kepala Sekolah" },
  { key: "npsn",    label: "# NPSN" },
  { key: "telepon", label: "📱 Telepon" },
  { key: "email",   label: "📧 Email" },
  { key: "website", label: "🌐 Website" },
  { key: "alamat",  label: "📍 Alamat" },
];

// Field sertifikat sesuai format PKL
const SERTIFIKAT_FIELDS = [
  { key: "nama",       label: "Nama Siswa",          desc: "Nama lengkap siswa (bold besar)" },
  { key: "ttl",        label: "Tempat, Tgl Lahir",   desc: "Contoh: Bekasi, 07 Oktober 2005" },
  { key: "nisn",       label: "NISN",                desc: "Nomor Induk Siswa Nasional" },
  { key: "kompetensi", label: "Kompetensi Keahlian", desc: "Jurusan siswa" },
  { key: "sekolah",    label: "Satuan Pendidikan",   desc: "Nama sekolah" },
  { key: "deskripsi",  label: "Deskripsi Pelaksanaan", desc: "Kalimat narasi PKL (otomatis wrap)" },
  { key: "kepsek",     label: "Kepala Sekolah (TTD)", desc: "Nama kepala sekolah, posisi kiri" },
  { key: "pimpinan",   label: "Pimpinan DUDI (TTD)", desc: "Nama pimpinan DUDI, posisi kanan" },
  { key: "nomor",      label: "Nomor Sertifikat",    desc: "Nomor urut otomatis (opsional)" },
];

const DEFAULT_CONFIG = {
  field_nama_x: 50,       field_nama_y: 38,       field_nama_size: 26,      field_nama_color: "#1a1a1a",
  field_ttl_x: 50,        field_ttl_y: 47,        field_ttl_size: 14,       field_ttl_color: "#333333",
  field_nisn_x: 50,       field_nisn_y: 52,       field_nisn_size: 14,      field_nisn_color: "#333333",
  field_kompetensi_x: 50, field_kompetensi_y: 57, field_kompetensi_size: 14,field_kompetensi_color: "#333333",
  field_sekolah_x: 50,    field_sekolah_y: 62,    field_sekolah_size: 14,   field_sekolah_color: "#333333",
  field_deskripsi_x: 50,  field_deskripsi_y: 68,  field_deskripsi_size: 13, field_deskripsi_color: "#333333",
  field_kepsek_x: 25,     field_kepsek_y: 85,     field_kepsek_size: 13,    field_kepsek_color: "#1a1a1a",
  field_pimpinan_x: 75,   field_pimpinan_y: 85,   field_pimpinan_size: 13,  field_pimpinan_color: "#1a1a1a",
  field_nomor_x: 50,      field_nomor_y: 18,      field_nomor_size: 11,     field_nomor_color: "#666666",
};

export default function AdminSettingsPage() {
  const [school, setSchool]       = useState(null);
  const [form, setForm]           = useState(null);
  const [loading, setLoading]     = useState(true);
  const [status, setStatus]       = useState("idle");
  const [uploading, setUploading] = useState(false);
  const [errorMsg, setErrorMsg]   = useState(null);
  const fileInputRef  = useRef(null);
  const saveTimer     = useRef(null);
  const savedTimer    = useRef(null);

  const [sertifikatData, setSertifikatData]   = useState(null);
  const [sertifikatConfig, setSertifikatConfig] = useState(DEFAULT_CONFIG);
  const [formatNomor, setFormatNomor]         = useState("SKT/{urutan}/{tahun}");
  const [uploadingTpl, setUploadingTpl]       = useState(false);
  const [savingConfig, setSavingConfig]       = useState(false);
  const [sertStatus, setSertStatus]           = useState("idle");
  const [activeField, setActiveField]         = useState(null);
  const [isDragging, setIsDragging]           = useState(false);
  const templateFileRef = useRef(null);
  const previewRef      = useRef(null);
  const dragRect        = useRef(null);

  const load = async () => {
    try {
      const res = await fetch("/api/admin/settings", { cache: "no-store" });
      if (!res.ok) throw new Error("Gagal memuat pengaturan");
      const data = await res.json();
      setSchool(data); setForm({ ...data });
    } catch (err) { setErrorMsg(err.message); }
    finally { setLoading(false); }
  };

  const loadSertifikat = useCallback(async () => {
    try {
      const res = await fetch("/api/admin/settings/sertifikat");
      if (!res.ok) return;
      const data = await res.json();
      setSertifikatData(data);
      setFormatNomor(data.format_nomor || "SKT/{urutan}/{tahun}");
      if (data.config && Object.keys(data.config).length > 0)
        setSertifikatConfig(prev => ({ ...prev, ...data.config }));
    } catch { /* ignore */ }
  }, []);

  useEffect(() => { load(); loadSertifikat(); }, [loadSertifikat]);
  useEffect(() => () => {
    if (saveTimer.current) clearTimeout(saveTimer.current);
    if (savedTimer.current) clearTimeout(savedTimer.current);
  }, []);

  const saveNow = async (data) => {
    setStatus("saving"); setErrorMsg(null);
    try {
      const res = await fetch("/api/admin/settings", {
        method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify(data),
      });
      const result = await res.json();
      if (!res.ok) throw new Error(result.message || "Gagal menyimpan");
      setSchool(result.settings); broadcastSchoolUpdated(); setStatus("saved");
      if (savedTimer.current) clearTimeout(savedTimer.current);
      savedTimer.current = setTimeout(() => setStatus("idle"), 2000);
    } catch (err) { setErrorMsg(err.message); setStatus("error"); }
  };

  const handleFieldChange = (key, value) => {
    const updated = { ...form, [key]: value }; setForm(updated);
    if (!updated.nama?.trim()) return;
    if (saveTimer.current) clearTimeout(saveTimer.current);
    saveTimer.current = setTimeout(() => saveNow(updated), 600);
  };

  const handleLogoChange = async (e) => {
    const file = e.target.files?.[0]; if (!file) return;
    setUploading(true); setErrorMsg(null);
    try {
      const fd = new FormData(); fd.append("logo", file);
      const res = await fetch("/api/admin/settings/logo", { method: "POST", body: fd });
      const data = await res.json();
      if (!res.ok) throw new Error(data.message || "Gagal mengunggah logo");
      setSchool(p => ({ ...p, logo_url: data.logo_url }));
      setForm(p => ({ ...p, logo_url: data.logo_url }));
      broadcastSchoolUpdated(); setStatus("saved");
      if (savedTimer.current) clearTimeout(savedTimer.current);
      savedTimer.current = setTimeout(() => setStatus("idle"), 2000);
    } catch (err) { setErrorMsg(err.message); setStatus("error"); }
    finally { setUploading(false); if (fileInputRef.current) fileInputRef.current.value = ""; }
  };

  const handleTemplateUpload = async (e) => {
    const file = e.target.files?.[0]; if (!file) return;
    setUploadingTpl(true); setSertStatus("idle");
    try {
      const fd = new FormData(); fd.append("template", file);
      const res = await fetch("/api/admin/settings/sertifikat", { method: "POST", body: fd });
      const data = await res.json();
      if (!res.ok) throw new Error(data.message || "Gagal mengunggah template");
      setSertifikatData(p => ({ ...p, template: data.template_url }));
      setSertStatus("saved-template");
    } catch (err) { setSertStatus("error"); setErrorMsg(err.message); }
    finally { setUploadingTpl(false); if (templateFileRef.current) templateFileRef.current.value = ""; }
  };

  const handleSaveConfig = async () => {
    setSavingConfig(true); setSertStatus("idle");
    try {
      const res = await fetch("/api/admin/settings/sertifikat", {
        method: "PUT", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ format_nomor: formatNomor, config: sertifikatConfig }),
      });
      if (!res.ok) throw new Error("Gagal menyimpan konfigurasi");
      setSertStatus("saved-config");
      setTimeout(() => setSertStatus("idle"), 2500);
    } catch (err) { setSertStatus("error"); setErrorMsg(err.message); }
    finally { setSavingConfig(false); }
  };

  const updatePos = (clientX, clientY, rect) => {
    const xPct = Math.min(100, Math.max(0, ((clientX - rect.left) / rect.width) * 100));
    const yPct = Math.min(100, Math.max(0, ((clientY - rect.top)  / rect.height) * 100));
    setSertifikatConfig(prev => ({
      ...prev,
      [`field_${activeField}_x`]: Math.round(xPct * 10) / 10,
      [`field_${activeField}_y`]: Math.round(yPct * 10) / 10,
    }));
  };

  const onMouseDown = (e) => {
    if (!activeField) return;
    e.preventDefault(); setIsDragging(true);
    dragRect.current = previewRef.current.getBoundingClientRect();
    updatePos(e.clientX, e.clientY, dragRect.current);
  };
  const onMouseMove = (e) => { if (!isDragging || !activeField) return; updatePos(e.clientX, e.clientY, dragRect.current); };
  const onMouseUp   = () => setIsDragging(false);
  const onClick     = (e) => {
    if (!activeField || isDragging) return;
    updatePos(e.clientX, e.clientY, previewRef.current.getBoundingClientRect());
  };

  if (loading) return (
    <div className="page">
      <div className="page-header"><h2>Pengaturan Sekolah</h2></div>
      <div className="card"><div className="card-body">Memuat pengaturan...</div></div>
    </div>
  );

  const previewTemplate = sertifikatData?.template;
  const contohNomor = formatNomor
    .replace(/\{urutan\}/gi, "001")
    .replace(/\{tahun\}/gi, new Date().getFullYear())
    .replace(/\{bulan\}/gi, String(new Date().getMonth()+1).padStart(2,"0"));

  return (
    <div className="page">
      <div className="page-header"><h2>Pengaturan Sekolah</h2><p>Konfigurasi informasi sekolah</p></div>

      {/* ─── INFORMASI SEKOLAH ─── */}
      <div className="card">
        <div className="card-header">
          <h3>🏫 Informasi Sekolah</h3>
          <div style={{ fontSize: 12, fontWeight: 500 }}>
            {status === "saving" && <span style={{ color: "#64748b" }}>💾 Menyimpan...</span>}
            {status === "saved"  && <span style={{ color: "#047857" }}>✅ Tersimpan otomatis</span>}
            {status === "error"  && <span style={{ color: "#b91c1c" }}>⚠️ {errorMsg}</span>}
          </div>
        </div>
        <div className="card-body">
          <p style={{ fontSize: 12, color: "#94a3b8", marginBottom: 16 }}>
            Perubahan tersimpan otomatis. Nama kepala sekolah di sini juga akan muncul di sertifikat.
          </p>
          <div className="form-group" style={{ marginBottom: 16 }}>
            <label>🖼️ Logo Sekolah</label>
            <div style={{ display: "flex", alignItems: "center", gap: 12, marginTop: 6 }}>
              <div style={{ width:64,height:64,borderRadius:10,border:"1px solid #e2e8f0",background:"#f8fafc",display:"flex",alignItems:"center",justifyContent:"center",overflow:"hidden",flexShrink:0 }}>
                {school?.logo_url
                  ? <img src={school.logo_url} alt="Logo" style={{ width:"100%",height:"100%",objectFit:"cover" }} />
                  : <span style={{ fontSize:11,color:"#94a3b8" }}>Logo</span>}
              </div>
              <div>
                <input ref={fileInputRef} type="file" accept="image/*" style={{ display:"none" }} onChange={handleLogoChange} />
                <button type="button" className="btn btn-secondary btn-sm" disabled={uploading} onClick={() => fileInputRef.current?.click()}>
                  {uploading ? "Mengunggah..." : "⬆️ Upload Logo"}
                </button>
                <p style={{ fontSize:11,color:"#94a3b8",marginTop:6 }}>PNG, JPG, WEBP. Maks 2MB.</p>
              </div>
            </div>
          </div>
          {FIELDS.map(f => (
            <div className="form-group" style={{ marginBottom:12 }} key={f.key}>
              <label>{f.label}</label>
              {f.key === "alamat"
                ? <textarea className="form-control" rows={3} value={form?.[f.key]||""} onChange={e=>handleFieldChange(f.key,e.target.value)} />
                : <input className="form-control" value={form?.[f.key]||""} onChange={e=>handleFieldChange(f.key,e.target.value)} />
              }
              {f.key==="nama" && !form?.nama?.trim() && <small style={{color:"#b91c1c"}}>Nama sekolah wajib diisi</small>}
            </div>
          ))}
          {school?.updated_at && <p style={{fontSize:11,color:"#94a3b8",marginTop:4}}>Terakhir diperbarui: {new Date(school.updated_at).toLocaleString("id-ID")}</p>}
        </div>
      </div>

      {/* ─── SERTIFIKAT MAGANG ─── */}
      <div className="card" style={{ marginTop: 24 }}>
        <div className="card-header">
          <h3>🎓 Sertifikat Magang (PKL)</h3>
          <div style={{ fontSize:12,fontWeight:500 }}>
            {sertStatus==="saved-template" && <span style={{color:"#047857"}}>✅ Template berhasil diunggah</span>}
            {sertStatus==="saved-config"   && <span style={{color:"#047857"}}>✅ Konfigurasi disimpan</span>}
            {sertStatus==="error"          && <span style={{color:"#b91c1c"}}>⚠️ {errorMsg}</span>}
          </div>
        </div>
        <div className="card-body">
          <p style={{ fontSize:12,color:"#64748b",marginBottom:20 }}>
            Upload desain template sertifikat PKL (PNG/JPG), lalu atur posisi setiap teks dengan klik atau drag di atas preview.
            Field yang akan diisi otomatis: <strong>Nama, TTL, NISN, Kompetensi, Satuan Pendidikan, Deskripsi, Kepala Sekolah, Pimpinan DUDI, Nomor Sertifikat.</strong>
          </p>

          {/* Upload */}
          <div className="form-group" style={{ marginBottom:20 }}>
            <label>🖼️ Template Sertifikat</label>
            <div style={{ display:"flex",alignItems:"center",gap:12,marginTop:6 }}>
              <input ref={templateFileRef} type="file" accept="image/png,image/jpeg,image/jpg,image/webp" style={{display:"none"}} onChange={handleTemplateUpload} />
              <button type="button" className="btn btn-secondary btn-sm" disabled={uploadingTpl} onClick={()=>templateFileRef.current?.click()}>
                {uploadingTpl ? "Mengunggah..." : "⬆️ Upload Template"}
              </button>
              {previewTemplate && <span style={{fontSize:12,color:"#047857"}}>✅ Template terpasang</span>}
            </div>
            <p style={{fontSize:11,color:"#94a3b8",marginTop:6}}>Format PNG atau JPG. Maks 10MB. Buat template dengan area kosong untuk setiap field teks.</p>
          </div>

          {/* Format nomor */}
          <div className="form-group" style={{ marginBottom:20 }}>
            <label>📄 Format Nomor Sertifikat</label>
            <input className="form-control" value={formatNomor} onChange={e=>setFormatNomor(e.target.value)} placeholder="contoh: SKT/{urutan}/{tahun}" style={{marginTop:6}} />
            <p style={{fontSize:11,color:"#94a3b8",marginTop:4}}>
              Placeholder: <code style={{background:"#f1f5f9",padding:"1px 4px",borderRadius:3}}>{"{urutan}"}</code> <code style={{background:"#f1f5f9",padding:"1px 4px",borderRadius:3}}>{"{tahun}"}</code> <code style={{background:"#f1f5f9",padding:"1px 4px",borderRadius:3}}>{"{bulan}"}</code>.
              {" "}Contoh hasil: <strong>{contohNomor}</strong>
            </p>
          </div>

          {/* Konfigurasi posisi */}
          {previewTemplate && (<>
            <div style={{ marginBottom:12 }}>
              <label style={{fontWeight:600,fontSize:14}}>📍 Atur Posisi Teks di Template</label>
              <p style={{fontSize:12,color:"#64748b",marginTop:4}}>
                Pilih field di bawah → <strong>klik atau drag</strong> di atas gambar untuk menentukan posisi teks tersebut.
              </p>
            </div>

            {/* Chip pilih field */}
            <div style={{ display:"flex",flexWrap:"wrap",gap:8,marginBottom:14 }}>
              {SERTIFIKAT_FIELDS.map(f => (
                <button key={f.key} type="button"
                  onClick={() => setActiveField(activeField===f.key ? null : f.key)}
                  title={f.desc}
                  style={{
                    padding:"5px 12px", borderRadius:20, cursor:"pointer",
                    border:`2px solid ${activeField===f.key?"#6366f1":"#e2e8f0"}`,
                    background: activeField===f.key?"#eef2ff":"#fff",
                    color: activeField===f.key?"#6366f1":"#475569",
                    fontSize:12, fontWeight: activeField===f.key?600:400,
                  }}>
                  {f.label}
                </button>
              ))}
            </div>

            {activeField && (
              <p style={{fontSize:12,color:"#6366f1",marginBottom:10,fontWeight:500}}>
                ✏️ Aktif: <strong>{SERTIFIKAT_FIELDS.find(f=>f.key===activeField)?.label}</strong> — {SERTIFIKAT_FIELDS.find(f=>f.key===activeField)?.desc}
              </p>
            )}

            {/* Preview drag & drop */}
            <div
              ref={previewRef}
              onMouseDown={onMouseDown} onMouseMove={onMouseMove} onMouseUp={onMouseUp} onClick={onClick}
              style={{
                position:"relative", display:"inline-block", width:"100%",
                cursor: activeField?(isDragging?"grabbing":"crosshair"):"default",
                border: activeField?"2px dashed #6366f1":"1px solid #e2e8f0",
                borderRadius:8, overflow:"hidden", userSelect:"none",
              }}
            >
              <img src={previewTemplate} alt="Template" style={{width:"100%",display:"block",pointerEvents:"none"}} draggable={false} />
              {SERTIFIKAT_FIELDS.map(f => {
                const x = sertifikatConfig[`field_${f.key}_x`] ?? 50;
                const y = sertifikatConfig[`field_${f.key}_y`] ?? 50;
                const isActive = activeField===f.key;
                return (
                  <div key={f.key} style={{
                    position:"absolute", left:`${x}%`, top:`${y}%`,
                    transform:"translate(-50%,-50%)", pointerEvents:"none",
                    background: isActive?"#6366f1":"rgba(0,0,0,0.55)",
                    color:"#fff", fontSize:10, padding:"2px 7px", borderRadius:4,
                    whiteSpace:"nowrap", fontWeight: isActive?700:400, zIndex: isActive?10:5,
                    border: isActive?"2px solid #fff":"1px solid rgba(255,255,255,0.4)",
                    boxShadow: isActive?"0 0 0 2px #6366f1":"none",
                  }}>
                    {f.label}
                  </div>
                );
              })}
            </div>

            {/* Kontrol manual X/Y/size/color */}
            {activeField && (
              <div style={{marginTop:14,padding:14,background:"#f8fafc",borderRadius:8,border:"1px solid #e2e8f0"}}>
                <div style={{fontWeight:600,fontSize:13,marginBottom:10}}>
                  ⚙️ {SERTIFIKAT_FIELDS.find(f=>f.key===activeField)?.label}
                </div>
                <div style={{display:"grid",gridTemplateColumns:"1fr 1fr 1fr 1fr",gap:10}}>
                  {[
                    {label:"Posisi X (%)",  key:`field_${activeField}_x`,    type:"number",min:0,max:100,step:0.5},
                    {label:"Posisi Y (%)",  key:`field_${activeField}_y`,    type:"number",min:0,max:100,step:0.5},
                    {label:"Ukuran Font",   key:`field_${activeField}_size`, type:"number",min:8,max:72},
                    {label:"Warna Teks",    key:`field_${activeField}_color`,type:"color"},
                  ].map(ctrl => (
                    <div key={ctrl.key}>
                      <label style={{fontSize:11,color:"#64748b"}}>{ctrl.label}</label>
                      <input
                        type={ctrl.type}
                        min={ctrl.min} max={ctrl.max} step={ctrl.step}
                        className={ctrl.type!=="color"?"form-control":undefined}
                        style={ctrl.type==="color"?{width:"100%",height:38,border:"1px solid #e2e8f0",borderRadius:6,padding:2,cursor:"pointer"}:undefined}
                        value={sertifikatConfig[ctrl.key] ?? ""}
                        onChange={e => setSertifikatConfig(prev=>({
                          ...prev,
                          [ctrl.key]: ctrl.type==="number" ? (ctrl.step?parseFloat(e.target.value):parseInt(e.target.value)) : e.target.value
                        }))}
                      />
                    </div>
                  ))}
                </div>
              </div>
            )}
          </>)}

          {/* Tombol simpan */}
          <div style={{marginTop:20,display:"flex",gap:10,alignItems:"center"}}>
            <button type="button" className="btn btn-primary" disabled={savingConfig} onClick={handleSaveConfig}>
              {savingConfig ? "Menyimpan..." : "💾 Simpan Konfigurasi Sertifikat"}
            </button>
            {(sertifikatData?.counter??0) > 0 && (
              <span style={{fontSize:12,color:"#64748b"}}>
                📊 Sertifikat diterbitkan: <strong>{sertifikatData.counter}</strong>
              </span>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
