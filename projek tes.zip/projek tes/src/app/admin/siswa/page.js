"use client";

import { useState, useEffect } from "react";
import Badge from "@/components/Badge";

const JURUSAN = ["RPL", "TKJ", "MM", "AKL"];

export default function AdminSiswaPage() {
  const [list, setList]           = useState([]);
  const [search, setSearch]       = useState("");
  const [filterStatus, setFilterStatus] = useState("");
  const [modal, setModal]         = useState(null);
  const [selected, setSelected]   = useState(null);
  const [form, setForm]           = useState({});
  const [loading, setLoading]     = useState(false);

  const load = async () => {
    const s = await fetch("/api/admin/siswa").then(r => r.json());
    setList(Array.isArray(s) ? s : []);
  };

  useEffect(() => { load(); }, []);

  const filtered = list.filter(s => {
    if (search && !s.nama?.toLowerCase().includes(search.toLowerCase()) && !s.nis?.includes(search) && !s.nisn?.includes(search)) return false;
    if (filterStatus && s.status !== filterStatus) return false;
    return true;
  });

  const openAdd  = () => { setForm({ kelas: "XII", jurusan: "RPL", status: "aktif" }); setModal("add"); };
  const openEdit = (s) => { setSelected(s); setForm({ ...s }); setModal("edit"); };

  const handleDelete = async (id) => {
    if (!confirm("Hapus siswa ini?")) return;
    await fetch(`/api/admin/siswa/${id}`, { method: "DELETE" });
    load();
  };

  const handleSave = async () => {
    if (!form.nis || !form.nama) return alert("NIS dan nama wajib diisi");
    setLoading(true);
    try {
      if (modal === "add") {
        const r = await fetch("/api/admin/siswa", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(form) });
        const d = await r.json();
        if (!r.ok) return alert(d.message);
      } else {
        const r = await fetch(`/api/admin/siswa/${selected.id}`, { method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify(form) });
        const d = await r.json();
        if (!r.ok) return alert(d.message);
      }
      setModal(null);
      load();
    } finally { setLoading(false); }
  };

  const f = (k, v) => setForm(p => ({ ...p, [k]: v }));

  const stats = [
    { num: list.length, label: "Total Siswa" },
    { num: list.filter(s => s.status === "magang").length,  label: "Sedang Magang" },
    { num: list.filter(s => s.status === "selesai").length, label: "Selesai Magang" },
    { num: list.filter(s => s.status === "aktif").length,   label: "Aktif" },
  ];

  return (
    <div className="page">
      <div className="page-header"><h2>Manajemen Siswa</h2><p>Kelola data siswa dan penugasan magang</p></div>
      <div className="stat-grid">{stats.map(s => <div className="stat-card" key={s.label}><div className="stat-num">{s.num}</div><div className="stat-label">{s.label}</div></div>)}</div>

      <div className="card">
        <div className="card-header"><h3>👤 Data Siswa</h3><button className="btn btn-primary" onClick={openAdd}>+ Tambah Siswa</button></div>
        <div className="table-controls">
          <input className="search-input" placeholder="Cari nama, NIS, atau NISN..." value={search} onChange={e => setSearch(e.target.value)} />
          <select className="filter-select" value={filterStatus} onChange={e => setFilterStatus(e.target.value)}>
            <option value="">Semua Status</option>
            <option value="aktif">Aktif</option><option value="magang">Magang</option><option value="selesai">Selesai</option>
          </select>
        </div>
        <table>
          <thead><tr><th>NIS / NISN</th><th>Nama</th><th>Kelas/Jurusan</th><th>TTL</th><th>Kontak</th><th>Status</th><th>Aksi</th></tr></thead>
          <tbody>
            {filtered.map(s => (
              <tr key={s.id}>
                <td>
                  <strong>{s.nis}</strong>
                  {s.nisn && <div style={{ fontSize: 11, color: "#64748b" }}>NISN: {s.nisn}</div>}
                </td>
                <td>👤 {s.nama}</td>
                <td>{s.kelas} - {s.jurusan}</td>
                <td style={{ fontSize: 12 }}>
                  {s.tempat_lahir && <div>{s.tempat_lahir}</div>}
                  {s.tanggal_lahir && <div>{new Date(s.tanggal_lahir).toLocaleDateString("id-ID")}</div>}
                </td>
                <td><div style={{ fontSize: 12 }}>📧 {s.email}</div><div style={{ fontSize: 12 }}>📱 {s.telepon}</div></td>
                <td><Badge status={s.status} /></td>
                <td><div className="action-btns">
                  <button className="btn-icon btn-edit" onClick={() => openEdit(s)}>✏️</button>
                  <button className="btn-icon btn-del"  onClick={() => handleDelete(s.id)}>🗑️</button>
                </div></td>
              </tr>
            ))}
          </tbody>
        </table>
        <div className="pagination"><span style={{ fontSize: 12, color: "#64748b" }}>Menampilkan {filtered.length} data</span></div>
      </div>

      {modal && (
        <div className="modal-overlay" onClick={e => e.target === e.currentTarget && setModal(null)}>
          <div className="modal">
            <div className="modal-header">
              <h3>{modal === "add" ? "👤 Tambah Siswa" : "✎ Edit Siswa"}</h3>
              <button className="close-btn" onClick={() => setModal(null)}>×</button>
            </div>
            <div className="modal-body">
              <div className="form-grid">
                <div className="form-group"><label>NIS *</label><input className="form-control" value={form.nis||""} onChange={e=>f("nis",e.target.value)} /></div>
                <div className="form-group"><label>NISN</label><input className="form-control" value={form.nisn||""} onChange={e=>f("nisn",e.target.value)} placeholder="Nomor Induk Siswa Nasional" /></div>
                <div className="form-group full"><label>Nama Lengkap *</label><input className="form-control" value={form.nama||""} onChange={e=>f("nama",e.target.value)} /></div>
                <div className="form-group"><label>Tempat Lahir</label><input className="form-control" value={form.tempat_lahir||""} onChange={e=>f("tempat_lahir",e.target.value)} placeholder="Contoh: Bekasi" /></div>
                <div className="form-group"><label>Tanggal Lahir</label><input className="form-control" type="date" value={form.tanggal_lahir ? form.tanggal_lahir.substring(0,10) : ""} onChange={e=>f("tanggal_lahir",e.target.value)} /></div>
                <div className="form-group"><label>Kelas</label>
                  <select className="form-control" value={form.kelas||""} onChange={e=>f("kelas",e.target.value)}>
                    <option value="">Pilih</option>{["X","XI","XII"].map(k=><option key={k}>{k}</option>)}
                  </select>
                </div>
                <div className="form-group"><label>Jurusan / Kompetensi Keahlian</label>
                  <select className="form-control" value={form.jurusan||""} onChange={e=>f("jurusan",e.target.value)}>
                    <option value="">Pilih</option>{JURUSAN.map(j=><option key={j}>{j}</option>)}
                  </select>
                </div>
                <div className="form-group"><label>Email</label><input className="form-control" type="email" value={form.email||""} onChange={e=>f("email",e.target.value)} /></div>
                <div className="form-group"><label>Telepon</label><input className="form-control" value={form.telepon||""} onChange={e=>f("telepon",e.target.value)} /></div>
                <div className="form-group"><label>Status</label>
                  <select className="form-control" value={form.status||"aktif"} onChange={e=>f("status",e.target.value)}>
                    <option value="aktif">Aktif</option><option value="magang">Magang</option><option value="selesai">Selesai</option>
                  </select>
                </div>
                {modal==="add" && <div className="form-group"><label>Password</label><input className="form-control" type="password" value={form.password||""} onChange={e=>f("password",e.target.value)} placeholder="Default: 123" /></div>}
                <div className="form-group full"><label>Alamat</label><textarea className="form-control" value={form.alamat||""} onChange={e=>f("alamat",e.target.value)} /></div>
              </div>
            </div>
            <div className="modal-footer">
              <button className="btn btn-secondary" onClick={() => setModal(null)}>Batal</button>
              <button className="btn btn-primary" onClick={handleSave} disabled={loading}>{loading ? "Menyimpan..." : modal==="add"?"Tambah Siswa":"Simpan"}</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
