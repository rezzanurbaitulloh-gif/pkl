"use client";

import { useState, useEffect } from "react";
import Badge from "@/components/Badge";

export default function AdminGuruPage() {
  const [list, setList] = useState([]);
  const [search, setSearch] = useState("");
  const [modal, setModal] = useState(null);
  const [selected, setSelected] = useState(null);
  const [form, setForm] = useState({});
  const [loading, setLoading] = useState(false);

  const load = () => fetch("/api/admin/guru").then(r=>r.json()).then(d=>setList(Array.isArray(d)?d:[]));
  useEffect(()=>{ load(); },[]);

  const filtered = list.filter(g => !search || g.nama?.toLowerCase().includes(search.toLowerCase()) || g.nip?.includes(search));
  const openAdd = () => { setForm({ status:"aktif" }); setModal("add"); };
  const openEdit = (g) => { setSelected(g); setForm({...g}); setModal("edit"); };
  const handleDelete = async (id) => {
    if (!confirm("Hapus guru ini?")) return;
    await fetch(`/api/admin/guru/${id}`, { method:"DELETE" });
    load();
  };
  const handleSave = async () => {
    if (!form.nip || !form.nama) return alert("NIP dan nama wajib diisi");
    setLoading(true);
    try {
      if (modal==="add") await fetch("/api/admin/guru", { method:"POST", headers:{"Content-Type":"application/json"}, body:JSON.stringify(form) });
      else await fetch(`/api/admin/guru/${selected.id}`, { method:"PUT", headers:{"Content-Type":"application/json"}, body:JSON.stringify(form) });
      setModal(null); load();
    } finally { setLoading(false); }
  };

  return (
    <div className="page">
      <div className="page-header"><h2>Manajemen Guru</h2><p>Kelola data guru pembimbing</p></div>
      <div className="stat-grid">
        {[{num:list.length,label:"Total Guru"},{num:list.filter(g=>g.status==="aktif").length,label:"Guru Aktif"},
          {num:list.reduce((a,g)=>a+(g.jumlah_siswa||0),0),label:"Total Siswa Bimbingan"},
          {num:list.length>0?Math.round(list.reduce((a,g)=>a+(g.jumlah_siswa||0),0)/list.length):0,label:"Rata-rata Siswa"}
        ].map(s=><div className="stat-card" key={s.label}><div className="stat-num">{s.num}</div><div className="stat-label">{s.label}</div></div>)}
      </div>
      <div className="card">
        <div className="card-header"><h3>👨‍🏫 Data Guru</h3><button className="btn btn-primary" onClick={openAdd}>+ Tambah Guru</button></div>
        <div className="table-controls"><input className="search-input" placeholder="Cari nama atau NIP..." value={search} onChange={e=>setSearch(e.target.value)} /></div>
        <table>
          <thead><tr><th>NIP</th><th>Nama</th><th>Mata Pelajaran</th><th>Kontak</th><th>Siswa</th><th>Status</th><th>Aksi</th></tr></thead>
          <tbody>
            {filtered.map(g => (
              <tr key={g.id}>
                <td style={{fontSize:12}}>{g.nip}</td>
                <td>👤 {g.nama}</td>
                <td>{g.mapel}</td>
                <td><div style={{fontSize:12}}>📧 {g.email}</div><div style={{fontSize:12}}>📱 {g.telepon}</div></td>
                <td><span style={{background:"#dbeafe",color:"#2563eb",fontSize:11,fontWeight:600,padding:"3px 8px",borderRadius:10}}>{g.jumlah_siswa||0} siswa</span></td>
                <td><Badge status={g.status} /></td>
                <td><div className="action-btns"><button className="btn-icon btn-edit" onClick={()=>openEdit(g)}>✏️</button><button className="btn-icon btn-del" onClick={()=>handleDelete(g.id)}>🗑️</button></div></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {modal && (
        <div className="modal-overlay" onClick={e=>e.target===e.currentTarget&&setModal(null)}>
          <div className="modal">
            <div className="modal-header"><h3>{modal==="add"?"👨‍🏫 Tambah Guru":"✏️ Edit Guru"}</h3><button className="close-btn" onClick={()=>setModal(null)}>×</button></div>
            <div className="modal-body">
              <div className="form-grid">
                <div className="form-group"><label>NIP *</label><input className="form-control" value={form.nip||""} onChange={e=>setForm({...form,nip:e.target.value})} /></div>
                <div className="form-group"><label>Nama Lengkap *</label><input className="form-control" value={form.nama||""} onChange={e=>setForm({...form,nama:e.target.value})} /></div>
                <div className="form-group"><label>Email</label><input className="form-control" type="email" value={form.email||""} onChange={e=>setForm({...form,email:e.target.value})} /></div>
                <div className="form-group"><label>Telepon</label><input className="form-control" value={form.telepon||""} onChange={e=>setForm({...form,telepon:e.target.value})} /></div>
                <div className="form-group"><label>Mata Pelajaran</label><input className="form-control" value={form.mapel||""} onChange={e=>setForm({...form,mapel:e.target.value})} /></div>
                <div className="form-group"><label>Status</label>
                  <select className="form-control" value={form.status||"aktif"} onChange={e=>setForm({...form,status:e.target.value})}>
                    <option value="aktif">Aktif</option><option value="nonaktif">Non-aktif</option>
                  </select>
                </div>
                <div className="form-group full"><label>Alamat</label><textarea className="form-control" value={form.alamat||""} onChange={e=>setForm({...form,alamat:e.target.value})} /></div>
              </div>
            </div>
            <div className="modal-footer">
              <button className="btn btn-secondary" onClick={()=>setModal(null)}>Batal</button>
              <button className="btn btn-primary" onClick={handleSave} disabled={loading}>{loading?"Menyimpan...":modal==="add"?"Tambah Guru":"Simpan"}</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
