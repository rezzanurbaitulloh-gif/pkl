"use client";

import { useEffect, useState, useCallback } from "react";

const ACTION_ICON = {
  create: "➕", update: "✎", delete: "🗑️", approve: "✅", reject: "⛔",
  login: "🔑", logout: "🚪", upload: "⬆️",
};

const ROLE_LABEL = { admin: "Admin", guru: "Guru", siswa: "Siswa", system: "Sistem" };

const formatDateTime = (d) => d ? new Date(d).toLocaleString("id-ID", {
  day: "2-digit", month: "short", year: "numeric", hour: "2-digit", minute: "2-digit",
}) : "-";

export default function ActivityLogsPage() {
  const [logs, setLogs] = useState([]);
  const [search, setSearch] = useState("");
  const [role, setRole] = useState("");
  const [loading, setLoading] = useState(true);

  // State untuk modal konfirmasi clear
  const [showClearModal, setShowClearModal] = useState(false);
  const [clearMode, setClearMode] = useState("all"); // "all" | "old"
  const [clearing, setClearing] = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    const params = new URLSearchParams();
    if (search) params.set("search", search);
    if (role) params.set("role", role);
    const res = await fetch(`/api/admin/activity-logs?${params.toString()}`, { cache: "no-store" });
    const data = await res.json();
    setLogs(Array.isArray(data) ? data : []);
    setLoading(false);
  }, [search, role]);

  useEffect(() => {
    load();
    const interval = setInterval(load, 15000);
    return () => clearInterval(interval);
  }, [load]);

  const handleClearLogs = async () => {
    setClearing(true);
    try {
      const res = await fetch(`/api/admin/activity-logs?mode=${clearMode}`, { method: "DELETE" });
      const data = await res.json();
      if (res.ok) {
        setShowClearModal(false);
        await load();
      } else {
        alert(data.message || "Gagal menghapus log");
      }
    } catch {
      alert("Terjadi kesalahan saat menghapus log");
    } finally {
      setClearing(false);
    }
  };

  return (
    <div className="page">
      <div className="page-header">
        <h2>Riwayat Aktivitas</h2>
        <p>Semua perubahan data yang dilakukan admin, guru, dan siswa</p>
      </div>

      <div className="card">
        <div className="card-header" style={{ display: "flex", alignItems: "center", justifyContent: "space-between", flexWrap: "wrap", gap: 8 }}>
          <h3>🕘 Log Aktivitas</h3>
          <button
            onClick={() => setShowClearModal(true)}
            style={{
              display: "flex", alignItems: "center", gap: 6,
              padding: "7px 14px", borderRadius: 8, border: "1px solid #fca5a5",
              background: "#fff1f2", color: "#dc2626", fontSize: 13,
              fontWeight: 600, cursor: "pointer", transition: "background .15s",
            }}
            onMouseEnter={e => e.currentTarget.style.background = "#fee2e2"}
            onMouseLeave={e => e.currentTarget.style.background = "#fff1f2"}
          >
            🗑️ Hapus Log
          </button>
        </div>

        <div className="table-controls">
          <input
            className="search-input"
            placeholder="Cari nama atau aktivitas..."
            value={search}
            onChange={e => setSearch(e.target.value)}
          />
          <select className="filter-select" value={role} onChange={e => setRole(e.target.value)}>
            <option value="">Semua Role</option>
            <option value="admin">Admin</option>
            <option value="guru">Guru</option>
            <option value="siswa">Siswa</option>
          </select>
        </div>

        <table>
          <thead>
            <tr>
              <th>Waktu</th>
              <th>Pengguna</th>
              <th>Role</th>
              <th>Aktivitas</th>
            </tr>
          </thead>
          <tbody>
            {loading ? (
              <tr><td colSpan={4} style={{ textAlign: "center", padding: 30, color: "#94a3b8" }}>Memuat data...</td></tr>
            ) : logs.length === 0 ? (
              <tr><td colSpan={4} style={{ textAlign: "center", padding: 30, color: "#94a3b8" }}>Belum ada aktivitas tercatat</td></tr>
            ) : logs.map(l => (
              <tr key={l.id}>
                <td style={{ fontSize: 12, whiteSpace: "nowrap" }}>🕘 {formatDateTime(l.created_at)}</td>
                <td style={{ fontSize: 13, fontWeight: 600 }}>{l.user_nama}</td>
                <td><span className={`badge badge-${l.role}`}>{ROLE_LABEL[l.role] || l.role}</span></td>
                <td style={{ fontSize: 13 }}>{ACTION_ICON[l.action] || "📝"} {l.description}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Modal Konfirmasi Clear Logs */}
      {showClearModal && (
        <div style={{
          position: "fixed", inset: 0, background: "rgba(0,0,0,0.45)",
          display: "flex", alignItems: "center", justifyContent: "center",
          zIndex: 1000, padding: 16,
        }}>
          <div style={{
            background: "#fff", borderRadius: 14, padding: 28,
            maxWidth: 420, width: "100%", boxShadow: "0 10px 40px rgba(0,0,0,0.2)",
          }}>
            <div style={{ fontSize: 32, textAlign: "center", marginBottom: 8 }}>🗑️</div>
            <h3 style={{ textAlign: "center", margin: "0 0 6px", color: "#111" }}>Hapus Riwayat Aktivitas</h3>
            <p style={{ textAlign: "center", color: "#64748b", fontSize: 13, margin: "0 0 20px" }}>
              Pilih jenis penghapusan log aktivitas
            </p>

            {/* Pilihan mode */}
            <div style={{ display: "flex", flexDirection: "column", gap: 10, marginBottom: 22 }}>
              <label style={{
                display: "flex", alignItems: "flex-start", gap: 10, padding: "12px 14px",
                border: `2px solid ${clearMode === "old" ? "#3b82f6" : "#e2e8f0"}`,
                borderRadius: 10, cursor: "pointer", transition: "border-color .15s",
              }}>
                <input
                  type="radio" name="clearMode" value="old"
                  checked={clearMode === "old"}
                  onChange={() => setClearMode("old")}
                  style={{ marginTop: 2 }}
                />
                <div>
                  <div style={{ fontWeight: 600, fontSize: 13, color: "#1e293b" }}>⏳ Hapus log lama (&gt;30 hari)</div>
                  <div style={{ fontSize: 12, color: "#64748b" }}>Hanya menghapus log yang lebih dari 30 hari lalu. Log terbaru tetap ada.</div>
                </div>
              </label>

              <label style={{
                display: "flex", alignItems: "flex-start", gap: 10, padding: "12px 14px",
                border: `2px solid ${clearMode === "all" ? "#ef4444" : "#e2e8f0"}`,
                borderRadius: 10, cursor: "pointer", transition: "border-color .15s",
              }}>
                <input
                  type="radio" name="clearMode" value="all"
                  checked={clearMode === "all"}
                  onChange={() => setClearMode("all")}
                  style={{ marginTop: 2 }}
                />
                <div>
                  <div style={{ fontWeight: 600, fontSize: 13, color: "#dc2626" }}>⚠️ Hapus semua log</div>
                  <div style={{ fontSize: 12, color: "#64748b" }}>Menghapus seluruh riwayat aktivitas. Tindakan ini tidak dapat dibatalkan.</div>
                </div>
              </label>
            </div>

            <div style={{ display: "flex", gap: 10 }}>
              <button
                onClick={() => setShowClearModal(false)}
                disabled={clearing}
                style={{
                  flex: 1, padding: "10px 0", borderRadius: 8,
                  border: "1px solid #e2e8f0", background: "#f8fafc",
                  color: "#475569", fontWeight: 600, cursor: "pointer", fontSize: 13,
                }}
              >
                Batal
              </button>
              <button
                onClick={handleClearLogs}
                disabled={clearing}
                style={{
                  flex: 1, padding: "10px 0", borderRadius: 8, border: "none",
                  background: clearMode === "all" ? "#dc2626" : "#2563eb",
                  color: "#fff", fontWeight: 600, cursor: clearing ? "not-allowed" : "pointer",
                  fontSize: 13, opacity: clearing ? 0.7 : 1,
                }}
              >
                {clearing ? "Menghapus..." : "Ya, Hapus"}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
