"use client";

import { useState, useEffect } from "react";
import Badge from "@/components/Badge";

const formatDate = (d) => d ? new Date(d).toLocaleDateString("id-ID",{day:"2-digit",month:"short",year:"numeric"}) : "-";
const today = () => new Date().toISOString().split("T")[0];

export default function AdminMagangPage() {
  const [list, setList] = useState([]);
  const [siswaList, setSiswaList] = useState([]);
  const [guruList, setGuruList] = useState([]);
  const [dudiList, setDudiList] = useState([]);
  const [search, setSearch] = useState("");
  const [filterStatus, setFilterStatus] = useState("");
  const [modal, setModal] = useState(null);
  const [selected, setSelected] = useState(null);
  const [form, setForm] = useState({});
  const [loading, setLoading] = useState(false);

  const load = async () => {
    const [m, s, g, d] = await Promise.all([
      fetch("/api/admin/magang").then(r=>r.json()),
      fetch("/api/admin/siswa").then(r=>r.json()),
      fetch("/api/admin/guru").then(r=>r.json()),
      fetch("/api/admin/dudi").then(r=>r.json()),
    ]);
    setList(Array.isArray(m)?m:[]); setSiswaList(Array.isArray(s)?s:[]);
    setGuruList(Array.isArray(g)?g:[]); setDudiList(Array.isArray(d)?d:[]);
  };
  useEffect(()=>{ load(); },[]);

  const filtered = list.filter(m => {
    if (search && !m.siswa_nama?.toLowerCase().includes(search.toLowerCase()) && !m.dudi_nama?.toLowerCase().includes(search.toLowerCase())) return false;
    if (filterStatus && m.status !== filterStatus) return false;
    return true;
  });

  const openAdd = () => { setForm({ status:"aktif", tanggal_mulai: today(), tanggal_selesai:"" }); setModal("add"); };
  const openEdit = (m) => { setSelected(m); setForm({...m, siswa_id:String(m.siswa_id), dudi_id:String(m.dudi_id), guru_id:String(m.guru_id||"")}); setModal("edit"); };
  const handleDelete = async (id) => {
    if (!confirm("Hapus data magang?")) return;
    await fetch(`/api/admin/magang/${id}`, { method:"DELETE" });
    load();
  };
  const handleSave = async () => {
    if (!form.siswa_id || !form.dudi_id) return alert("Siswa dan DUDI wajib dipilih");
    setLoading(true);
    try {
      const payload = {...form, siswa_id:Number(form.siswa_id), dudi_id:Number(form.dudi_id), guru_id:form.guru_id?Number(form.guru_id):null};
      if (modal==="add") await fetch("/api/admin/magang", { method:"POST", headers:{"Content-Type":"application/json"}, body:JSON.stringify(payload) });
      else await fetch(`/api/admin/magang/${selected.id}`, { method:"PUT", headers:{"Content-Type":"application/json"}, body:JSON.stringify(payload) });
      setModal(null); load();
    } finally { setLoading(false); }
  };

  return (
    <div className="page">
      <div className="page-header"><h2>Manajemen Magang</h2><p>Kelola penempatan dan monitoring magang siswa</p></div>
      <div className="stat-grid">
        {[{num:list.length,label:"Total Magang"},{num:list.filter(m=>m.status==="aktif").length,label:"Sedang Aktif"},
          {num:list.filter(m=>m.status==="selesai").length,label:"Selesai"},{num:list.filter(m=>m.status==="dibatalkan").length,label:"Dibatalkan"}
        ].map(s=><div className="stat-card" key={s.label}><div className="stat-num">{s.num}</div><div className="stat-label">{s.label}</div></div>)}
      </div>
      <div className="card">
        <div className="card-header"><h3>🎓 Data Magang</h3><button className="btn btn-primary" onClick={openAdd}>+ Tambah Magang</button></div>
        <div className="table-controls">
          <input className="search-input" placeholder="Cari siswa atau DUDI..." value={search} onChange={e=>setSearch(e.target.value)} />
          <select className="filter-select" value={filterStatus} onChange={e=>setFilterStatus(e.target.value)}>
            <option value="">Semua Status</option><option value="aktif">Aktif</option><option value="selesai">Selesai</option><option value="dibatalkan">Dibatalkan</option>
          </select>
        </div>
        <table>
          <thead><tr><th>Siswa</th><th>DUDI</th><th>Pembimbing</th><th>Periode</th><th>Status</th><th>Aksi</th></tr></thead>
          <tbody>
            {filtered.map(m => (
              <tr key={m.id}>
                <td><strong>{m.siswa_nama||"-"}</strong></td>
                <td>{m.dudi_nama||"-"}</td>
                <td>{m.guru_nama||"-"}</td>
                <td style={{fontSize:12}}>📅 {formatDate(m.tanggal_mulai)} – {formatDate(m.tanggal_selesai)}</td>
                <td><Badge status={m.status} /></td>
                <td><div className="action-btns"><button className="btn-icon btn-edit" onClick={()=>openEdit(m)}>✏️</button><button className="btn-icon btn-del" onClick={()=>handleDelete(m.id)}>🗑️</button></div></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {modal && (
        <div className="modal-overlay" onClick={e=>e.target===e.currentTarget&&setModal(null)}>
          <div className="modal">
            <div className="modal-header"><h3>{modal==="add"?"🎓 Tambah Magang":"✏️ Edit Magang"}</h3><button className="close-btn" onClick={()=>setModal(null)}>×</button></div>
            <div className="modal-body">
              <div className="form-grid">
                <div className="form-group"><label>Siswa *</label>
                  <select className="form-control" value={form.siswa_id||""} onChange={e=>setForm({...form,siswa_id:e.target.value})}>
                    <option value="">Pilih Siswa</option>{siswaList.map(s=><option key={s.id} value={s.id}>{s.nama}</option>)}
                  </select>
                </div>
                <div className="form-group"><label>DUDI *</label>
                  <select className="form-control" value={form.dudi_id||""} onChange={e=>setForm({...form,dudi_id:e.target.value})}>
                    <option value="">Pilih DUDI</option>{dudiList.map(d=><option key={d.id} value={d.id}>{d.nama}</option>)}
                  </select>
                </div>
                <div className="form-group"><label>Guru Pembimbing</label>
                  <select className="form-control" value={form.guru_id||""} onChange={e=>setForm({...form,guru_id:e.target.value})}>
                    <option value="">Pilih Guru</option>{guruList.map(g=><option key={g.id} value={g.id}>{g.nama}</option>)}
                  </select>
                </div>
                <div className="form-group"><label>Status</label>
                  <select className="form-control" value={form.status||"aktif"} onChange={e=>setForm({...form,status:e.target.value})}>
                    <option value="aktif">Aktif</option><option value="selesai">Selesai</option><option value="dibatalkan">Dibatalkan</option>
                  </select>
                </div>
                <div className="form-group"><label>Tanggal Mulai</label><input className="form-control" type="date" value={form.tanggal_mulai||""} onChange={e=>setForm({...form,tanggal_mulai:e.target.value})} /></div>
                <div className="form-group"><label>Tanggal Selesai</label><input className="form-control" type="date" value={form.tanggal_selesai||""} onChange={e=>setForm({...form,tanggal_selesai:e.target.value})} /></div>
                <div className="form-group full"><label>Catatan</label><textarea className="form-control" value={form.catatan||""} onChange={e=>setForm({...form,catatan:e.target.value})} /></div>
              </div>
            </div>
            <div className="modal-footer">
              <button className="btn btn-secondary" onClick={()=>setModal(null)}>Batal</button>
              <button className="btn btn-primary" onClick={handleSave} disabled={loading}>{loading?"Menyimpan...":modal==="add"?"Tambah":"Simpan"}</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
