"use client";

import { useState, useEffect } from "react";
import Badge from "@/components/Badge";

export default function AdminDudiPage() {
  const [list, setList] = useState([]);
  const [search, setSearch] = useState("");
  const [modal, setModal] = useState(null); // 'add' | 'edit' | 'akun'
  const [selected, setSelected] = useState(null);
  const [form, setForm] = useState({});
  const [akunForm, setAkunForm] = useState({ login_email: "", login_password: "" });
  const [loading, setLoading] = useState(false);
  const [akunMsg, setAkunMsg] = useState("");

  const load = () =>
    fetch("/api/admin/dudi").then((r) => r.json()).then((d) => setList(Array.isArray(d) ? d : []));
  useEffect(() => { load(); }, []);

  const filtered = list.filter(
    (d) =>
      !search ||
      d.nama?.toLowerCase().includes(search.toLowerCase()) ||
      d.penanggung_jawab?.toLowerCase().includes(search.toLowerCase())
  );

  const openAdd = () => { setForm({ status: "aktif" }); setModal("add"); };
  const openEdit = (d) => { setSelected(d); setForm({ ...d }); setModal("edit"); };
  const openAkun = (d) => {
    setSelected(d);
    setAkunForm({ login_email: d.login_email || "", login_password: "" });
    setAkunMsg("");
    setModal("akun");
  };

  const handleDelete = async (id) => {
    if (!confirm("Hapus DUDI ini?")) return;
    await fetch(`/api/admin/dudi/${id}`, { method: "DELETE" });
    load();
  };

  const handleSave = async () => {
    if (!form.nama) return alert("Nama perusahaan wajib diisi");
    setLoading(true);
    try {
      if (modal === "add") {
        await fetch("/api/admin/dudi", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(form),
        });
      } else {
        await fetch(`/api/admin/dudi/${selected.id}`, {
          method: "PUT",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(form),
        });
      }
      setModal(null);
      load();
    } finally {
      setLoading(false);
    }
  };

  const handleSaveAkun = async () => {
    setAkunMsg("");
    setLoading(true);
    try {
      const res = await fetch(`/api/admin/dudi/${selected.id}/akun`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(akunForm),
      });
      const data = await res.json();
      if (!res.ok) { setAkunMsg("❌ " + (data.message || "Gagal menyimpan.")); return; }
      setAkunMsg("✅ Akun berhasil diperbarui.");
      load();
    } finally {
      setLoading(false);
    }
  };

  const handleResetAkun = async () => {
    if (!confirm("Hapus akun login DUDI ini? Perusahaan tidak akan bisa masuk portal.")) return;
    setLoading(true);
    try {
      const res = await fetch(`/api/admin/dudi/${selected.id}/akun`, {
        method: "DELETE",
      });
      const data = await res.json();
      if (!res.ok) { setAkunMsg("❌ " + (data.message || "Gagal reset.")); return; }
      setAkunMsg("✅ Akun login berhasil dihapus.");
      setAkunForm({ login_email: "", login_password: "" });
      load();
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="page">
      <div className="page-header">
        <h2>Manajemen DUDI</h2>
        <p>Data perusahaan mitra magang</p>
      </div>

      <div className="stat-grid">
        {[
          { num: list.length, label: "Total DUDI", icon: "🏢" },
          { num: list.filter((d) => d.status === "aktif").length, label: "DUDI Aktif", icon: "✅" },
          { num: list.filter((d) => d.status !== "aktif").length, label: "Tidak Aktif", icon: "❌" },
          { num: list.filter((d) => d.login_email).length, label: "Punya Akun Login", icon: "🔑" },
        ].map((s) => (
          <div className="stat-card" key={s.label}>
            <span className="stat-icon">{s.icon}</span>
            <div className="stat-num">{s.num}</div>
            <div className="stat-label">{s.label}</div>
          </div>
        ))}
      </div>

      <div className="card">
        <div className="card-header">
          <h3>🏢 Daftar DUDI</h3>
          <button className="btn btn-primary" onClick={openAdd}>+ Tambah DUDI</button>
        </div>
        <div className="table-controls">
          <input
            className="search-input"
            placeholder="Cari perusahaan atau penanggung jawab..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>
        <table>
          <thead>
            <tr>
              <th>Perusahaan</th>
              <th>Kontak</th>
              <th>Penanggung Jawab</th>
              <th>Status</th>
              <th>Siswa</th>
              <th>Akun Login</th>
              <th>Aksi</th>
            </tr>
          </thead>
          <tbody>
            {filtered.map((d) => (
              <tr key={d.id}>
                <td>
                  <div style={{ fontWeight: 600, fontSize: 13 }}>🏢 {d.nama}</div>
                  <div style={{ fontSize: 11, color: "#94a3b8" }}>📍 {d.alamat}</div>
                </td>
                <td>
                  <div style={{ fontSize: 12 }}>📧 {d.email}</div>
                  <div style={{ fontSize: 12 }}>📱 {d.telepon}</div>
                </td>
                <td>👤 {d.penanggung_jawab}</td>
                <td><Badge status={d.status} /></td>
                <td>
                  <span
                    style={{
                      background: "#dbeafe", color: "#2563eb", fontSize: 12,
                      fontWeight: 700, padding: "3px 10px", borderRadius: 20,
                    }}
                  >
                    {d.jumlah_siswa || 0}
                  </span>
                </td>
                <td>
                  {d.login_email ? (
                    <span style={{ fontSize: 12, color: "#16a34a" }}>🔑 {d.login_email}</span>
                  ) : (
                    <span style={{ fontSize: 12, color: "#94a3b8" }}>— Belum ada</span>
                  )}
                </td>
                <td>
                  <div className="action-btns">
                    <button className="btn-icon btn-edit" onClick={() => openEdit(d)} title="Edit data">✏️</button>
                    <button
                      className="btn-icon"
                      style={{ background: "#fef9c3", border: "1px solid #fbbf24" }}
                      onClick={() => openAkun(d)}
                      title="Kelola akun login"
                    >
                      🔑
                    </button>
                    <button className="btn-icon btn-del" onClick={() => handleDelete(d.id)} title="Hapus">🗑️</button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Modal Tambah/Edit DUDI */}
      {(modal === "add" || modal === "edit") && (
        <div className="modal-overlay" onClick={(e) => e.target === e.currentTarget && setModal(null)}>
          <div className="modal">
            <div className="modal-header">
              <h3>{modal === "add" ? "🏢 Tambah DUDI" : "✏️ Edit DUDI"}</h3>
              <button className="close-btn" onClick={() => setModal(null)}>×</button>
            </div>
            <div className="modal-body">
              <div className="form-grid" style={{ gridTemplateColumns: "1fr" }}>
                <div className="form-group">
                  <label>Nama Perusahaan *</label>
                  <input className="form-control" value={form.nama || ""} onChange={(e) => setForm({ ...form, nama: e.target.value })} />
                </div>
                <div className="form-group">
                  <label>Alamat</label>
                  <input className="form-control" value={form.alamat || ""} onChange={(e) => setForm({ ...form, alamat: e.target.value })} />
                </div>
                <div className="form-group">
                  <label>Telepon</label>
                  <input className="form-control" value={form.telepon || ""} onChange={(e) => setForm({ ...form, telepon: e.target.value })} />
                </div>
                <div className="form-group">
                  <label>Email</label>
                  <input className="form-control" type="email" value={form.email || ""} onChange={(e) => setForm({ ...form, email: e.target.value })} />
                </div>
                <div className="form-group">
                  <label>Penanggung Jawab</label>
                  <input className="form-control" value={form.penanggung_jawab || ""} onChange={(e) => setForm({ ...form, penanggung_jawab: e.target.value })} />
                </div>
                <div className="form-group">
                  <label>Status</label>
                  <select className="form-control" value={form.status || "aktif"} onChange={(e) => setForm({ ...form, status: e.target.value })}>
                    <option value="aktif">Aktif</option>
                    <option value="nonaktif">Non-aktif</option>
                  </select>
                </div>
              </div>
            </div>
            <div className="modal-footer">
              <button className="btn btn-secondary" onClick={() => setModal(null)}>Batal</button>
              <button className="btn btn-primary" onClick={handleSave} disabled={loading}>
                {loading ? "Menyimpan..." : "Simpan"}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Modal Kelola Akun Login DUDI */}
      {modal === "akun" && selected && (
        <div className="modal-overlay" onClick={(e) => e.target === e.currentTarget && setModal(null)}>
          <div className="modal">
            <div className="modal-header">
              <h3>🔑 Akun Login DUDI — {selected.nama}</h3>
              <button className="close-btn" onClick={() => setModal(null)}>×</button>
            </div>
            <div className="modal-body">
              <p style={{ fontSize: 13, color: "#64748b", marginBottom: 12 }}>
                Set email dan password agar perusahaan ini dapat masuk ke portal DUDI.
                Kosongkan password jika tidak ingin mengubahnya.
              </p>
              <div className="form-grid" style={{ gridTemplateColumns: "1fr" }}>
                <div className="form-group">
                  <label>Email Login</label>
                  <input
                    className="form-control"
                    type="email"
                    placeholder="email@perusahaan.com"
                    value={akunForm.login_email}
                    onChange={(e) => setAkunForm({ ...akunForm, login_email: e.target.value })}
                  />
                </div>
                <div className="form-group">
                  <label>Password Baru {selected.login_email ? "(kosongkan jika tidak diubah)" : "*"}</label>
                  <input
                    className="form-control"
                    type="password"
                    placeholder="Password baru..."
                    value={akunForm.login_password}
                    onChange={(e) => setAkunForm({ ...akunForm, login_password: e.target.value })}
                  />
                </div>
              </div>
              {akunMsg && (
                <div
                  style={{
                    marginTop: 8, padding: "8px 12px", borderRadius: 6, fontSize: 13,
                    background: akunMsg.startsWith("✅") ? "#f0fdf4" : "#fef2f2",
                    color: akunMsg.startsWith("✅") ? "#16a34a" : "#dc2626",
                  }}
                >
                  {akunMsg}
                </div>
              )}
            </div>
            <div className="modal-footer" style={{ justifyContent: "space-between" }}>
              <div>
                {selected.login_email && (
                  <button
                    className="btn"
                    style={{ background: "#fee2e2", color: "#dc2626", border: "none" }}
                    onClick={handleResetAkun}
                    disabled={loading}
                  >
                    🗑️ Hapus Akun Login
                  </button>
                )}
              </div>
              <div style={{ display: "flex", gap: 8 }}>
                <button className="btn btn-secondary" onClick={() => setModal(null)}>Tutup</button>
                <button className="btn btn-primary" onClick={handleSaveAkun} disabled={loading}>
                  {loading ? "Menyimpan..." : "Simpan Akun"}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
