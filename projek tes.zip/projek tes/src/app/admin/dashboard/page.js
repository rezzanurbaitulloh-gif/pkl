"use client";

import { useState, useEffect } from "react";
import Badge from "@/components/Badge";
import { useSchoolInfo } from "@/lib/useSchoolInfo";

const formatDate = (d) => {
  if (!d) return "-";
  return new Date(d).toLocaleDateString("id-ID", { day: "2-digit", month: "short", year: "numeric" });
};

export default function AdminDashboardPage() {
  const [data, setData] = useState(null);
  const school = useSchoolInfo();
  const today = new Date().toLocaleDateString("id-ID", { weekday: "long", day: "numeric", month: "long", year: "numeric" });

  useEffect(() => {
    fetch("/api/admin/stats").then(r => r.json()).then(setData);
  }, []);

  if (!data) return <div className="page"><p style={{color:"#94a3b8"}}>Memuat data...</p></div>;

  return (
    <div className="page">
      <div className="page-header">
        <h2>Dashboard</h2>
        {/* Perbaikan Bug #12: sebelumnya hardcode "SMK Negeri 1 Kertosono",
            sekarang memakai useSchoolInfo() yang sama dipakai sidebar/topbar
            (single source of truth dari tabel school_settings). */}
        <p>Ringkasan aktivitas sistem magang — {school?.nama || "Memuat..."}</p>
        <p className="page-date">📅 {today}</p>
      </div>
      <div className="stat-grid">
        {[
          { num: data.stats.siswa, label: "Total Siswa", sub: "Seluruh siswa terdaftar", icon: "👤" },
          { num: data.stats.dudi, label: "Perusahaan Mitra", sub: "DUDI aktif yang bermitra", icon: "🏢" },
          { num: data.stats.magang, label: "Siswa Magang", sub: "Sedang aktif menjalani magang", icon: "🎓", highlight: true },
          { num: data.stats.jurnal, label: "Jurnal Hari Ini", sub: "Laporan yang masuk hari ini", icon: "📋" },
          { num: data.stats.pendaftaranPending, label: "Pendaftaran Pending", sub: "Menunggu konfirmasi guru", icon: "📨" },
        ].map(s => (
          <div className={`stat-card ${s.highlight ? "highlight" : ""}`} key={s.label}>
            <span className="stat-icon">{s.icon}</span>
            <div className="stat-num">{s.num}</div>
            <div className="stat-label">{s.label}</div>
            <div className="stat-sub">{s.sub}</div>
          </div>
        ))}
      </div>
      <div className="dashboard-grid">
        <div>
          <div className="card">
            <div className="card-header"><h3>🎓 Magang Terbaru</h3></div>
            <table>
              <thead><tr><th>Siswa</th><th>Perusahaan</th><th>Periode</th><th>Status</th></tr></thead>
              <tbody>
                {(data.recentMagang || []).map(m => (
                  <tr key={m.id}>
                    <td><strong>{m.siswa_nama || "-"}</strong></td>
                    <td>{m.dudi_nama || "-"}</td>
                    <td style={{fontSize:11}}>{formatDate(m.tanggal_mulai)} - {formatDate(m.tanggal_selesai)}</td>
                    <td><Badge status={m.status} /></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <div className="card">
            <div className="card-header"><h3>📋 Jurnal Terbaru</h3></div>
            <div className="card-body">
              {(data.recentJurnal || []).map(l => (
                <div className="logbook-item" key={l.id}>
                  <div className="logbook-dot" />
                  <div className="logbook-content">
                    <div className="logbook-text">{l.kegiatan}</div>
                    {l.kendala && <div className="kendala-text">⚠️ Kendala: {l.kendala}</div>}
                    <div className="logbook-meta">📅 {formatDate(l.tanggal)} • {l.siswa_nama}</div>
                  </div>
                  <div className="logbook-status"><Badge status={l.status} /></div>
                </div>
              ))}
            </div>
          </div>
        </div>
        <div>
          <div className="card">
            <div className="card-header"><h3>📨 Pendaftaran Menunggu Konfirmasi</h3></div>
            <div className="card-body">
              {(data.pendaftaranPending || []).length === 0 ? (
                <div className="empty-state"><div className="empty-sub">Tidak ada pendaftaran pending</div></div>
              ) : (
                (data.pendaftaranPending || []).map(p => (
                  <div className="dudi-item" key={p.id}>
                    <div>
                      <div style={{fontSize:13,fontWeight:600,color:"#0f172a"}}>{p.siswa_nama} ({p.siswa_nis})</div>
                      <div style={{fontSize:11,color:"#94a3b8"}}>{p.dudi_nama} • Pembimbing: {p.guru_nama}</div>
                      <div style={{fontSize:11,color:"#94a3b8"}}>📅 Daftar: {formatDate(p.tanggal_daftar)}</div>
                    </div>
                    <Badge status={p.status} />
                  </div>
                ))
              )}
            </div>
          </div>
          <div className="card">
            <div className="card-header"><h3>🏢 DUDI Aktif</h3></div>
            <div className="card-body">
              {(data.dudiAktif || []).map(d => (
                <div className="dudi-item" key={d.id}>
                  <div>
                    <div style={{fontSize:13,fontWeight:600,color:"#0f172a"}}>{d.nama}</div>
                    <div style={{fontSize:11,color:"#94a3b8"}}>{d.alamat}</div>
                  </div>
                  <span className="dudi-count">👤 {d.jumlah_siswa}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
