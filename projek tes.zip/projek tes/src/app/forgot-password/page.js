import ForgotPasswordClient from "./ForgotPasswordClient";
import { getPublicSchoolInfo } from "@/lib/publicSchoolInfo";

export const dynamic = "force-dynamic";

// Perbaikan Bug #12: ambil nama sekolah dari database (bukan hardcode),
// supaya halaman publik ini ikut berubah saat admin mengubah nama sekolah
// lewat menu Pengaturan — sama seperti yang sudah dilakukan di sidebar
// admin/guru/siswa/dudi lewat useSchoolInfo().
export default async function ForgotPasswordPage() {
  const school = await getPublicSchoolInfo();
  return <ForgotPasswordClient school={school} />;
}
