"use client";

import { useState } from "react";
import Link from "next/link";

export default function ForgotPasswordClient({ school }) {
  const schoolName = school?.nama || "Sekolah";
  const [email, setEmail] = useState("");
  const [error, setError] = useState("");
  const [pesan, setPesan] = useState("");
  const [resetUrl, setResetUrl] = useState("");
  const [loading, setLoading] = useState(false);

  const handleSubmit = async () => {
    setError("");
    setPesan("");
    setResetUrl("");

    if (!email.trim()) {
      setError("Email wajib diisi.");
      return;
    }

    setLoading(true);
    try {
      const res = await fetch("/api/auth/forgot-password", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email }),
      });
      const data = await res.json();
      if (!res.ok) {
        setError(data.message || "Gagal memproses permintaan.");
        return;
      }
      setPesan(data.message);
      if (data.resetUrl) setResetUrl(data.resetUrl);
    } catch (err) {
      setError("Tidak dapat terhubung ke server.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="login-page">
      <div className="login-left">
        <h1>
          Sistem Manajemen
          <br />
          <span>Magang Siswa</span>
        </h1>
        <p>
          Masukkan alamat email akun Anda. Kami akan membuatkan link untuk
          mengatur ulang password Anda.
        </p>
      </div>
      <div className="login-right">
        <div className="login-box">
          <div className="login-logo">
            <div
              className="logo-circle"
              style={{ display: "flex", justifyContent: "center", alignItems: "center", background: "transparent" }}
            >
              <img
                src="/logo.png.webp"
                alt={`Logo ${schoolName}`}
                style={{ width: "60px", height: "auto", objectFit: "contain" }}
              />
            </div>
            <h2>Lupa Password</h2>
            <p>Masukkan email yang terdaftar</p>
          </div>

          <div className="form-group">
            <label>📧 Alamat Email</label>
            <input
              className="form-control"
              type="email"
              placeholder="nama@gmail.com"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && handleSubmit()}
            />
          </div>

          {error && <div className="login-error">{error}</div>}
          {pesan && <div className="login-success">{pesan}</div>}
          {resetUrl && (
            <div className="login-success" style={{ marginTop: 8, wordBreak: "break-all" }}>
              Link reset sementara (belum ada pengiriman email otomatis):
              <br />
              <a href={resetUrl}>{resetUrl}</a>
            </div>
          )}

          <button className="login-btn" onClick={handleSubmit} disabled={loading}>
            {loading ? "Memproses..." : "Kirim Link Reset →"}
          </button>

          <p style={{ fontSize: 12, color: "#64748b", textAlign: "center", marginTop: 16 }}>
            <Link href="/login">← Kembali ke halaman login</Link>
          </p>
        </div>
      </div>
    </div>
  );
}
