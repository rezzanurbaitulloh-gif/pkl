import { NextResponse } from "next/server";
import { query } from "@/lib/db";
import { withErrorHandler } from "@/lib/apiHandler";

async function __GET() {
  try {
    const rows = await query("SELECT COUNT(*) as total FROM users");
    return NextResponse.json({
      ok: true,
      message: "Koneksi database berhasil.",
      totalUsers: Number(rows[0]?.total) || 0,
    });
  } catch (err) {
    return NextResponse.json(
      { ok: false, message: err.message || "Koneksi database gagal." },
      { status: 500 }
    );
  }
}
export const GET = withErrorHandler(__GET);

