import { NextResponse } from "next/server";
import { getCurrentSiswa, getCurrentAdmin, getCurrentGuru } from "@/lib/auth";
import { query } from "@/lib/db";
import { PDFDocument, rgb, StandardFonts } from "pdf-lib";
import { readFile } from "fs/promises";
import path from "path";
import { withErrorHandler } from "@/lib/apiHandler";
import { embedTemplateImage } from "@/lib/sertifikatTemplate";

function hexToRgb(hex) {
  const r = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
  if (!r) return { r: 0, g: 0, b: 0 };
  return { r: parseInt(r[1],16)/255, g: parseInt(r[2],16)/255, b: parseInt(r[3],16)/255 };
}

function formatTanggalIndo(dateStr) {
  if (!dateStr) return "-";
  const bulan = ["Januari","Februari","Maret","April","Mei","Juni","Juli","Agustus","September","Oktober","November","Desember"];
  const d = new Date(dateStr);
  return `${d.getDate()} ${bulan[d.getMonth()]} ${d.getFullYear()}`;
}

// Hitung durasi dalam bulan (dibulatkan)
function hitungDurasi(mulai, selesai) {
  if (!mulai || !selesai) return "";
  const m = new Date(mulai);
  const s = new Date(selesai);
  const diffMs = s - m;
  const diffBulan = Math.round(diffMs / (1000 * 60 * 60 * 24 * 30));
  if (diffBulan <= 0) {
    const diffHari = Math.round(diffMs / (1000 * 60 * 60 * 24));
    return `${diffHari} hari`;
  }
  return `${diffBulan} bulan`;
}

async function __GET(req, { params }) {
  let user = await getCurrentSiswa();
  let role = "siswa";
  if (!user) { user = await getCurrentGuru(); role = "guru"; }
  if (!user) { user = await getCurrentAdmin(); role = "admin"; }
  if (!user) return NextResponse.json({ message: "Unauthorized" }, { status: 401 });

  const magangId = params.id;

  const rows = await query(
    `SELECT m.*,
            s.nama        AS siswa_nama,
            s.nis         AS siswa_nis,
            s.nisn        AS siswa_nisn,
            s.kelas       AS siswa_kelas,
            s.jurusan     AS siswa_jurusan,
            s.tempat_lahir AS siswa_tempat_lahir,
            s.tanggal_lahir AS siswa_tanggal_lahir,
            s.id          AS siswa_id,
            d.nama        AS dudi_nama,
            d.penanggung_jawab AS dudi_pimpinan,
            ss.nama       AS sekolah_nama,
            ss.kepala     AS sekolah_kepala
     FROM magang m
     LEFT JOIN siswa s        ON s.id   = m.siswa_id
     LEFT JOIN dudi d         ON d.id   = m.dudi_id
     LEFT JOIN school_settings ss ON ss.id = 1
     WHERE m.id = ?`,
    [magangId]
  );

  const magang = rows[0];
  if (!magang) return NextResponse.json({ message: "Data magang tidak ditemukan" }, { status: 404 });
  if (role === "siswa" && magang.siswa_id !== user.id)
    return NextResponse.json({ message: "Akses ditolak" }, { status: 403 });
  if (magang.status !== "selesai")
    return NextResponse.json({ message: "Sertifikat hanya tersedia untuk magang yang telah selesai" }, { status: 400 });

  const settingsRows = await query("SELECT sertifikat_template FROM school_settings WHERE id = 1");
  const configRows  = await query("SELECT * FROM sertifikat_config WHERE id = 1");
  const cfg = configRows[0] || {};
  const templatePath = path.join(process.cwd(), "public", settingsRows[0]?.sertifikat_template || "");

  let templateBuffer;
  try { templateBuffer = await readFile(templatePath); }
  catch { return NextResponse.json({ message: "File template sertifikat tidak ditemukan" }, { status: 500 }); }

  // ─── Bangun teks untuk tiap field ───
  const ttlText = (() => {
    const tl = magang.siswa_tempat_lahir || "";
    const tgl = magang.siswa_tanggal_lahir ? formatTanggalIndo(magang.siswa_tanggal_lahir) : "";
    if (tl && tgl) return `${tl}, ${tgl}`;
    return tl || tgl || "-";
  })();

  const durasi = hitungDurasi(magang.tanggal_mulai, magang.tanggal_selesai);
  const deskripsiText =
    `Telah melaksanakan kegiatan Praktik Kerja Lapangan (PKL) selama ${durasi}, di ${magang.dudi_nama || "-"}.`;

  // ─── Generate PDF ───
  const pdfDoc = await PDFDocument.create();
  const ext = path.extname(settingsRows[0]?.sertifikat_template || "").toLowerCase();
  const templateImg = await embedTemplateImage(pdfDoc, templateBuffer, ext);

  const { width: W, height: H } = templateImg.scale(1);
  const page = pdfDoc.addPage([W, H]);
  page.drawImage(templateImg, { x: 0, y: 0, width: W, height: H });

  const fontBold    = await pdfDoc.embedFont(StandardFonts.HelveticaBold);
  const fontRegular = await pdfDoc.embedFont(StandardFonts.Helvetica);

  // Gambar teks center-aligned
  function drawText(text, xPct, yPct, size, colorHex, bold = false) {
    if (!text) return;
    const font = bold ? fontBold : fontRegular;
    const c = hexToRgb(colorHex || "#1a1a1a");
    const x = (xPct / 100) * W;
    const y = H - (yPct / 100) * H;
    const tw = font.widthOfTextAtSize(text, size);
    page.drawText(text, { x: x - tw / 2, y, size, font, color: rgb(c.r, c.g, c.b) });
  }

  // Gambar teks multiline (wrap otomatis, max lebar dalam persen)
  function drawTextWrap(text, xPct, yPct, size, colorHex, maxWidthPct = 70) {
    if (!text) return;
    const font = fontRegular;
    const c = hexToRgb(colorHex || "#333333");
    const maxWidth = (maxWidthPct / 100) * W;
    const lineHeight = size * 1.5;

    // Pecah teks jadi baris yang muat
    const words = text.split(" ");
    const lines = [];
    let current = "";
    for (const word of words) {
      const test = current ? `${current} ${word}` : word;
      if (font.widthOfTextAtSize(test, size) > maxWidth && current) {
        lines.push(current);
        current = word;
      } else {
        current = test;
      }
    }
    if (current) lines.push(current);

    const totalHeight = (lines.length - 1) * lineHeight;
    const startY = H - (yPct / 100) * H + totalHeight / 2;

    lines.forEach((line, i) => {
      const tw = font.widthOfTextAtSize(line, size);
      const x = (xPct / 100) * W - tw / 2;
      const y = startY - i * lineHeight;
      page.drawText(line, { x, y, size, font, color: rgb(c.r, c.g, c.b) });
    });
  }

  // ─── Tulis semua field ───
  drawText(magang.siswa_nama,        cfg.field_nama_x        ?? 50, cfg.field_nama_y        ?? 38, cfg.field_nama_size        ?? 26, cfg.field_nama_color        ?? "#1a1a1a", true);
  drawText(ttlText,                  cfg.field_ttl_x         ?? 50, cfg.field_ttl_y         ?? 47, cfg.field_ttl_size         ?? 14, cfg.field_ttl_color         ?? "#333333");
  drawText(magang.siswa_nisn || "-", cfg.field_nisn_x        ?? 50, cfg.field_nisn_y        ?? 52, cfg.field_nisn_size        ?? 14, cfg.field_nisn_color        ?? "#333333");
  drawText(magang.siswa_jurusan,     cfg.field_kompetensi_x  ?? 50, cfg.field_kompetensi_y  ?? 57, cfg.field_kompetensi_size  ?? 14, cfg.field_kompetensi_color  ?? "#333333");
  drawText(magang.sekolah_nama,      cfg.field_sekolah_x     ?? 50, cfg.field_sekolah_y     ?? 62, cfg.field_sekolah_size     ?? 14, cfg.field_sekolah_color     ?? "#333333");
  drawTextWrap(deskripsiText,        cfg.field_deskripsi_x   ?? 50, cfg.field_deskripsi_y   ?? 68, cfg.field_deskripsi_size   ?? 13, cfg.field_deskripsi_color   ?? "#333333");
  drawText(magang.sekolah_kepala,    cfg.field_kepsek_x      ?? 25, cfg.field_kepsek_y      ?? 85, cfg.field_kepsek_size      ?? 13, cfg.field_kepsek_color      ?? "#1a1a1a", true);
  drawText(magang.dudi_pimpinan,     cfg.field_pimpinan_x    ?? 75, cfg.field_pimpinan_y    ?? 85, cfg.field_pimpinan_size    ?? 13, cfg.field_pimpinan_color    ?? "#1a1a1a", true);
  drawText(magang.nomor_sertifikat || "", cfg.field_nomor_x  ?? 50, cfg.field_nomor_y       ?? 18, cfg.field_nomor_size       ?? 11, cfg.field_nomor_color       ?? "#666666");

  const pdfBytes = await pdfDoc.save();
  const slug = (magang.siswa_nama || "siswa").replace(/\s+/g, "_");

  return new NextResponse(pdfBytes, {
    status: 200,
    headers: {
      "Content-Type": "application/pdf",
      "Content-Disposition": `attachment; filename="Sertifikat_PKL_${slug}.pdf"`,
      "Cache-Control": "no-store",
    },
  });
}
export const GET = withErrorHandler(__GET);

