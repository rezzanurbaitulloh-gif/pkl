import { NextResponse } from "next/server";
import { query } from "@/lib/db";
import { createToken, SESSION_COOKIE } from "@/lib/auth";
import { verifyPassword, isBcryptHash } from "@/lib/password";
import {
  checkRateLimit,
  recordFailedAttempt,
  resetAttempts,
  getClientIp,
} from "@/lib/rateLimiter";
import { withErrorHandler } from "@/lib/apiHandler";

/** Format pesan error 429 dalam Bahasa Indonesia, sertakan estimasi waktu coba lagi */
function pesanRateLimit(retryAfterMs) {
  const menit = Math.max(Math.ceil(retryAfterMs / 60000), 1);
  const waktuUlang = new Date(Date.now() + retryAfterMs);
  const jamUlang = waktuUlang.toLocaleTimeString("id-ID", {
    hour: "2-digit",
    minute: "2-digit",
  });
  return `Terlalu banyak percobaan login gagal. Silakan coba lagi dalam ${menit} menit (sekitar pukul ${jamUlang}).`;
}

async function __POST(request) {
  try {
    const { email, password } = await request.json();

    if (!email || !password) {
      return NextResponse.json(
        { message: "Email dan password wajib diisi." },
        { status: 400 }
      );
    }

    // -- Rate limiting: cek berdasarkan email dan IP sebelum memproses login
    const emailKey = `email:${email.trim().toLowerCase()}`;
    const ip = getClientIp(request);
    const ipKey = `ip:${ip}`;

    const limitEmail = checkRateLimit(emailKey);
    const limitIp = checkRateLimit(ipKey);

    if (limitEmail.blocked || limitIp.blocked) {
      const retryAfterMs = Math.max(limitEmail.retryAfterMs, limitIp.retryAfterMs);
      return NextResponse.json(
        { message: pesanRateLimit(retryAfterMs) },
        { status: 429 }
      );
    }

    // -- Cek login DUDI terlebih dahulu (tabel dudi, kolom login_email & login_password)
    // Password DUDI disimpan sebagai bcrypt hash (lihat src/app/api/admin/dudi/[id]/akun/route.js),
    // jadi dicocokkan dengan verifyPassword, bukan dibandingkan langsung di query SQL.
    const dudiCandidates = await query(
      "SELECT * FROM dudi WHERE login_email = ? AND status = 'aktif'",
      [email]
    );
    const dudi = dudiCandidates[0];
    const dudiPasswordValid = dudi
      ? isBcryptHash(dudi.login_password)
        ? await verifyPassword(password, dudi.login_password)
        : dudi.login_password === password // fallback untuk data lama yang belum ter-hash
      : false;

    if (dudi && dudiPasswordValid) {
      resetAttempts(emailKey);

      // Token DUDI: userId diisi dudiId, role = 'dudi', dudiId disertakan
      const token = createToken({
        id: dudi.id,
        role: "dudi",
        email: dudi.login_email,
        dudiId: dudi.id,
      });

      const res = NextResponse.json({
        message: "Login berhasil",
        user: { id: dudi.id, nama: dudi.nama, email: dudi.login_email, role: "dudi" },
        redirectTo: "/dudi/dashboard",
      });

      res.cookies.set(SESSION_COOKIE, token, {
        httpOnly: true,
        sameSite: "lax",
        path: "/",
        maxAge: 60 * 60 * 24 * 7,
      });

      return res;
    }

    // -- Login normal (admin / guru / siswa dari tabel users), password di-hash bcrypt
    const users = await query("SELECT * FROM users WHERE email = ?", [email]);
    const user = users[0];
    const passwordValid = user ? await verifyPassword(password, user.password) : false;

    if (!user || !passwordValid) {
      recordFailedAttempt(emailKey);
      recordFailedAttempt(ipKey);
      return NextResponse.json(
        { message: "Email atau password salah." },
        { status: 401 }
      );
    }

    resetAttempts(emailKey);

    const token = createToken(user);
    let redirectTo = "/siswa/dashboard";
    if (user.role === "admin") redirectTo = "/admin/dashboard";
    else if (user.role === "guru") redirectTo = "/guru/dashboard";

    const res = NextResponse.json({
      message: "Login berhasil",
      user: { id: user.id, nama: user.nama, email: user.email, role: user.role },
      redirectTo,
    });

    res.cookies.set(SESSION_COOKIE, token, {
      httpOnly: true,
      sameSite: "lax",
      path: "/",
      maxAge: 60 * 60 * 24 * 7, // 7 hari
    });

    return res;
  } catch (err) {
    console.error(err);
    return NextResponse.json(
      { message: err.message || "Terjadi kesalahan pada server." },
      { status: 500 }
    );
  }
}
export const POST = withErrorHandler(__POST);

