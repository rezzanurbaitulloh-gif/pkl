import { NextResponse } from "next/server";
import { SESSION_COOKIE } from "@/lib/auth";
import { withErrorHandler } from "@/lib/apiHandler";

async function __POST() {
  const res = NextResponse.json({ message: "Logout berhasil" });
  res.cookies.set(SESSION_COOKIE, "", { path: "/", maxAge: 0 });
  return res;
}
export const POST = withErrorHandler(__POST);

