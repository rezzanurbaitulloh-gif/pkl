import { NextResponse } from "next/server";
import crypto from "crypto";
import { query } from "@/lib/db";
import { withErrorHandler } from "@/lib/apiHandler";

const TOKEN_EXPIRY_MS = 60 * 60 * 1000; // link reset berlaku 1 jam

async function __POST(request) {
  try {
    const { email } = await request.json();

    if (!email || !email.trim()) {
      return NextResponse.json({ message: "Email wajib diisi." }, { status: 400 });
    }
    const trimmedEmail = email.trim();

    // Pesan ditampilkan sama baik email ditemukan atau tidak, agar tidak
    // membocorkan daftar email yang terdaftar di sistem (mencegah enumerasi akun).
    const pesan =
      "Jika email terdaftar di sistem, link reset password telah dibuat.";

    const users = await query("SELECT id, nama, email FROM users WHERE email = ?", [trimmedEmail]);
    const user = users[0];

    if (user) {
      const token = crypto.randomBytes(32).toString("hex");
      const expiresAt = new Date(Date.now() + TOKEN_EXPIRY_MS);

      await query(
        "INSERT INTO password_reset_tokens (user_id, token, expires_at) VALUES (?, ?, ?)",
        [user.id, token, expiresAt]
      );

      const origin = new URL(request.url).origin;
      const resetUrl = `${origin}/reset-password?token=${token}`;

      // TODO: integrasikan dengan layanan email asli. Untuk saat ini link
      // reset hanya ditampilkan di log server & response API sebagai
      // pengganti sementara (lihat catatan keamanan di README).
      console.log(`[Lupa Password] Link reset untuk ${user.email}: ${resetUrl}`);

      return NextResponse.json({ message: pesan, resetUrl });
    }

    // Perbaikan Bug #10: akun DUDI login lewat dudi.login_email, terpisah
    // dari tabel users, sehingga sebelumnya pencarian di atas saja tidak
    // pernah menemukan akun DUDI manapun dan perwakilan perusahaan mitra
    // tidak punya cara mandiri untuk reset password. Sekarang dicek juga di
    // tabel dudi sebagai langkah kedua.
    const dudiRows = await query(
      "SELECT id, nama, login_email FROM dudi WHERE login_email = ?",
      [trimmedEmail]
    );
    const dudi = dudiRows[0];

    if (dudi) {
      const token = crypto.randomBytes(32).toString("hex");
      const expiresAt = new Date(Date.now() + TOKEN_EXPIRY_MS);

      await query(
        "INSERT INTO password_reset_tokens (dudi_id, token, expires_at) VALUES (?, ?, ?)",
        [dudi.id, token, expiresAt]
      );

      const origin = new URL(request.url).origin;
      const resetUrl = `${origin}/reset-password?token=${token}`;

      console.log(`[Lupa Password - DUDI] Link reset untuk ${dudi.login_email}: ${resetUrl}`);

      return NextResponse.json({ message: pesan, resetUrl });
    }

    return NextResponse.json({ message: pesan, resetUrl: null });
  } catch (err) {
    console.error(err);
    return NextResponse.json(
      { message: err.message || "Terjadi kesalahan pada server." },
      { status: 500 }
    );
  }
}
export const POST = withErrorHandler(__POST);

