import { NextResponse } from "next/server";
import { query } from "@/lib/db";
import { hashPassword } from "@/lib/password";
import { logActivity } from "@/lib/activityLog";
import { withErrorHandler } from "@/lib/apiHandler";

async function __POST(request) {
  try {
    const { token, password, confirmPassword } = await request.json();

    if (!token || !password) {
      return NextResponse.json(
        { message: "Token dan password baru wajib diisi." },
        { status: 400 }
      );
    }
    if (password.length < 6) {
      return NextResponse.json(
        { message: "Password minimal 6 karakter." },
        { status: 400 }
      );
    }
    if (confirmPassword !== undefined && password !== confirmPassword) {
      return NextResponse.json(
        { message: "Konfirmasi password tidak sesuai." },
        { status: 400 }
      );
    }

    // Perbaikan Bug #10: token reset sekarang bisa merujuk ke user_id (admin/
    // guru/siswa) ATAU dudi_id (akun DUDI), jadi kedua kemungkinan dicek di
    // sini lewat LEFT JOIN ke kedua tabel sekaligus.
    const rows = await query(
      `SELECT prt.id as token_id, prt.user_id, prt.dudi_id, prt.expires_at, prt.used_at,
              u.nama as user_nama, u.email as user_email, u.role as user_role,
              d.nama as dudi_nama, d.login_email as dudi_login_email
       FROM password_reset_tokens prt
       LEFT JOIN users u ON u.id = prt.user_id
       LEFT JOIN dudi d ON d.id = prt.dudi_id
       WHERE prt.token = ?`,
      [token]
    );
    const resetToken = rows[0];

    if (!resetToken || (!resetToken.user_id && !resetToken.dudi_id)) {
      return NextResponse.json(
        { message: "Token reset password tidak valid." },
        { status: 400 }
      );
    }
    if (resetToken.used_at) {
      return NextResponse.json(
        { message: "Link reset password ini sudah pernah digunakan." },
        { status: 400 }
      );
    }
    if (new Date(resetToken.expires_at) < new Date()) {
      return NextResponse.json(
        { message: "Link reset password sudah kedaluwarsa. Silakan minta link baru." },
        { status: 400 }
      );
    }

    const hashedPassword = await hashPassword(password);

    if (resetToken.user_id) {
      await query("UPDATE users SET password = ? WHERE id = ?", [hashedPassword, resetToken.user_id]);
      await query(
        "UPDATE password_reset_tokens SET used_at = NOW() WHERE user_id = ? AND used_at IS NULL",
        [resetToken.user_id]
      );
      await logActivity(
        { id: resetToken.user_id, nama: resetToken.user_nama, role: resetToken.user_role },
        "reset_password",
        `${resetToken.user_nama} mereset password melalui fitur lupa password`
      );
    } else {
      await query("UPDATE dudi SET login_password = ? WHERE id = ?", [hashedPassword, resetToken.dudi_id]);
      await query(
        "UPDATE password_reset_tokens SET used_at = NOW() WHERE dudi_id = ? AND used_at IS NULL",
        [resetToken.dudi_id]
      );
      await logActivity(
        { id: resetToken.dudi_id, nama: resetToken.dudi_nama, role: "dudi" },
        "reset_password",
        `${resetToken.dudi_nama} (DUDI) mereset password melalui fitur lupa password`
      );
    }

    return NextResponse.json({
      message: "Password berhasil diubah. Silakan login dengan password baru.",
    });
  } catch (err) {
    console.error(err);
    return NextResponse.json(
      { message: err.message || "Terjadi kesalahan pada server." },
      { status: 500 }
    );
  }
}
export const POST = withErrorHandler(__POST);

