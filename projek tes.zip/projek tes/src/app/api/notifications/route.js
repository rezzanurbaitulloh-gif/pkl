import { NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/auth";
import { query } from "@/lib/db";
import { withErrorHandler } from "@/lib/apiHandler";

/**
 * GET /api/notifications
 * Ambil daftar notifikasi terbaru untuk user yang sedang login.
 * Query param:
 *   - limit  (default 20)
 *   - unread_only = "true" untuk filter belum dibaca saja
 */
async function __GET(request) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ message: "Unauthorized" }, { status: 401 });

  const { searchParams } = new URL(request.url);
  const limit = Math.min(parseInt(searchParams.get("limit") || "20", 10), 50);
  const unreadOnly = searchParams.get("unread_only") === "true";

  let where = "WHERE user_id = ?";
  const params = [user.id];
  if (unreadOnly) {
    where += " AND dibaca = FALSE";
  }

  const rows = await query(
    `SELECT id, judul, pesan, dibaca, link, created_at
     FROM notifications
     ${where}
     ORDER BY created_at DESC
     LIMIT ?`,
    [...params, limit]
  );

  const countRows = await query(
    "SELECT COUNT(*) as total FROM notifications WHERE user_id = ? AND dibaca = FALSE",
    [user.id]
  );

  return NextResponse.json({
    data: rows,
    unread_count: Number(countRows[0]?.total) || 0,
  });
}
export const GET = withErrorHandler(__GET);

/**
 * PATCH /api/notifications
 * Tandai notifikasi sebagai sudah dibaca.
 * Body JSON:
 *   - { id: number }       → tandai satu notifikasi
 *   - { all: true }        → tandai semua milik user ini
 */
async function __PATCH(request) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ message: "Unauthorized" }, { status: 401 });

  const body = await request.json();

  if (body.all === true) {
    await query(
      "UPDATE notifications SET dibaca = TRUE WHERE user_id = ? AND dibaca = FALSE",
      [user.id]
    );
    return NextResponse.json({ message: "Semua notifikasi ditandai sudah dibaca." });
  }

  const notifId = parseInt(body.id, 10);
  if (!notifId) {
    return NextResponse.json({ message: "id notifikasi tidak valid" }, { status: 400 });
  }

  // Pastikan notifikasi memang milik user ini (mencegah IDOR)
  const rows = await query(
    "SELECT id FROM notifications WHERE id = ? AND user_id = ?",
    [notifId, user.id]
  );
  if (!rows[0]) {
    return NextResponse.json({ message: "Notifikasi tidak ditemukan" }, { status: 404 });
  }

  await query("UPDATE notifications SET dibaca = TRUE WHERE id = ?", [notifId]);
  return NextResponse.json({ message: "Notifikasi ditandai sudah dibaca." });
}
export const PATCH = withErrorHandler(__PATCH);
