import { NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/auth";
import { query } from "@/lib/db";
import { withErrorHandler } from "@/lib/apiHandler";

// Endpoint ini bisa diakses semua role yang sudah login.
// Digunakan oleh sidebar/topbar untuk menampilkan nama sekolah & logo terbaru.
async function __GET() {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ message: "Unauthorized" }, { status: 401 });

  const rows = await query("SELECT * FROM school_settings WHERE id = 1");
  const settings = rows[0] || {};
  return NextResponse.json(settings, {
    headers: { "Cache-Control": "no-store" },
  });
}
export const GET = withErrorHandler(__GET);

