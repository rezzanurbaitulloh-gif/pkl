import { NextResponse } from "next/server";
import { getCurrentSiswa } from "@/lib/auth";
import { query } from "@/lib/db";
import { logActivity } from "@/lib/activityLog";
import { withErrorHandler } from "@/lib/apiHandler";

const MAX_PENDING = 3;

async function __POST(request) {
  const siswa = await getCurrentSiswa();
  if (!siswa) {
    return NextResponse.json({ message: "Unauthorized" }, { status: 401 });
  }

  const { dudiId, guruId } = await request.json();

  if (!dudiId || !guruId) {
    return NextResponse.json(
      { message: "Pilih tempat magang dan guru pembimbing terlebih dahulu." },
      { status: 400 }
    );
  }

  // Siswa yang sedang aktif magang tidak bisa mendaftar lagi
  // Tapi jika magang terakhir berstatus 'dibatalkan', siswa boleh daftar ulang
  const activeMagang = await query(
    `SELECT id, status FROM magang WHERE siswa_id = ? AND status IN ('aktif','selesai') ORDER BY id DESC LIMIT 1`,
    [siswa.id]
  );
  if (activeMagang.length > 0) {
    return NextResponse.json(
      { message: "Anda sudah diterima magang dan tidak dapat mendaftar ke tempat magang lain." },
      { status: 409 }
    );
  }

  // Pastikan belum pernah mendaftar ke DUDI yang sama
  const existing = await query(
    `SELECT id FROM pendaftaran WHERE siswa_id = ? AND dudi_id = ? AND status != 'ditolak'`,
    [siswa.id, dudiId]
  );
  if (existing.length > 0) {
    return NextResponse.json(
      { message: "Anda sudah mendaftar ke tempat magang ini." },
      { status: 409 }
    );
  }

  // Cek maksimal pendaftaran pending
  const pendingRows = await query(
    `SELECT COUNT(*) as total FROM pendaftaran WHERE siswa_id = ? AND status = 'pending'`,
    [siswa.id]
  );
  const pendingCount = Number(pendingRows[0]?.total) || 0;
  if (pendingCount >= MAX_PENDING) {
    return NextResponse.json(
      { message: `Anda sudah mencapai batas maksimal ${MAX_PENDING} pendaftaran dengan status pending.` },
      { status: 400 }
    );
  }

  const result = await query(
    `INSERT INTO pendaftaran (siswa_id, dudi_id, guru_id, status, tanggal_daftar)
     VALUES (?, ?, ?, 'pending', CURDATE())`,
    [siswa.id, dudiId, guruId]
  );

  const inserted = await query(
    `SELECT p.*, d.nama as dudi_nama, d.alamat as dudi_alamat, g.nama as guru_nama
     FROM pendaftaran p
     LEFT JOIN dudi d ON d.id = p.dudi_id
     LEFT JOIN guru g ON g.id = p.guru_id
     WHERE p.id = ?`,
    [result.insertId]
  );

  await logActivity(
    { id: siswa.id, nama: siswa.nama, role: "siswa" },
    "create",
    `${siswa.nama} mendaftar magang ke ${inserted[0]?.dudi_nama || "DUDI"} dengan pembimbing ${inserted[0]?.guru_nama || "-"}`
  );

  return NextResponse.json(
    { message: "Pendaftaran berhasil dikirim. Menunggu konfirmasi.", data: inserted[0] },
    { status: 201 }
  );
}
export const POST = withErrorHandler(__POST);

