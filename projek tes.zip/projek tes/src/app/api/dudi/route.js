import { NextResponse } from "next/server";
import { getCurrentSiswa } from "@/lib/auth";
import { query } from "@/lib/db";
import { withErrorHandler } from "@/lib/apiHandler";

async function __GET(request) {
  const siswa = await getCurrentSiswa();
  if (!siswa) {
    return NextResponse.json({ message: "Unauthorized" }, { status: 401 });
  }

  const { searchParams } = new URL(request.url);
  const search = searchParams.get("search") || "";

  let where = "WHERE d.status = 'aktif'";
  const params = [];
  if (search) {
    where += " AND (d.nama LIKE ? OR d.alamat LIKE ?)";
    params.push(`%${search}%`, `%${search}%`);
  }

  const dudiRows = await query(
    `SELECT d.* FROM dudi d ${where} ORDER BY d.nama ASC`,
    params
  );

  // Status pendaftaran siswa ini untuk masing-masing DUDI
  const pendaftaranRows = await query(
    `SELECT dudi_id, status FROM pendaftaran WHERE siswa_id = ?`,
    [siswa.id]
  );
  const pendaftaranMap = {};
  pendaftaranRows.forEach((p) => {
    pendaftaranMap[p.dudi_id] = p.status;
  });

  const data = dudiRows.map((d) => ({
    ...d,
    pendaftaranStatus: pendaftaranMap[d.id] || null,
  }));

  return NextResponse.json({ data });
}
export const GET = withErrorHandler(__GET);

