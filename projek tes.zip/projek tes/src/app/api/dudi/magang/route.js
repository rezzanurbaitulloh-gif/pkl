import { NextResponse } from "next/server";
import { getCurrentDudi } from "@/lib/auth";
import { query } from "@/lib/db";
import { withErrorHandler } from "@/lib/apiHandler";

/** GET /api/dudi/magang — daftar siswa yang magang di DUDI ini */
async function __GET() {
  const dudi = await getCurrentDudi();
  if (!dudi) return NextResponse.json({ message: "Unauthorized" }, { status: 401 });

  const rows = await query(
    `SELECT
       m.id, m.status, m.tanggal_mulai, m.tanggal_selesai,
       m.catatan_dudi, m.nilai_dudi,
       s.id AS siswa_id, s.nama AS siswa_nama, s.nis, s.kelas, s.jurusan,
       s.email AS siswa_email, s.telepon AS siswa_telepon
     FROM magang m
     JOIN siswa s ON s.id = m.siswa_id
     WHERE m.dudi_id = ?
     ORDER BY m.tanggal_mulai DESC`,
    [dudi.id]
  );

  return NextResponse.json(rows);
}
export const GET = withErrorHandler(__GET);

