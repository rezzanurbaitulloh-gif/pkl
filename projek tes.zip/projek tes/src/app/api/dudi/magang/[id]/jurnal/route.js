import { NextResponse } from "next/server";
import { getCurrentDudi } from "@/lib/auth";
import { query } from "@/lib/db";
import { withErrorHandler } from "@/lib/apiHandler";

/** GET /api/dudi/magang/[id]/jurnal — jurnal harian siswa untuk magang tertentu */
async function __GET(request, { params }) {
  const dudi = await getCurrentDudi();
  if (!dudi) return NextResponse.json({ message: "Unauthorized" }, { status: 401 });

  // Pastikan magang ini memang di DUDI yang sedang login
  const magangRows = await query(
    "SELECT id, siswa_id FROM magang WHERE id = ? AND dudi_id = ?",
    [params.id, dudi.id]
  );
  if (!magangRows[0]) {
    return NextResponse.json({ message: "Data magang tidak ditemukan." }, { status: 404 });
  }

  const siswaId = magangRows[0].siswa_id;

  const jurnal = await query(
    `SELECT j.id, j.tanggal, j.kegiatan, j.kendala, j.status, j.catatan_guru, j.file_path, j.file_name
     FROM jurnal j
     WHERE j.siswa_id = ?
     ORDER BY j.tanggal DESC`,
    [siswaId]
  );

  return NextResponse.json(jurnal);
}
export const GET = withErrorHandler(__GET);

