import { NextResponse } from "next/server";
import { getCurrentDudi } from "@/lib/auth";
import { query } from "@/lib/db";
import { logActivity } from "@/lib/activityLog";
import { withErrorHandler } from "@/lib/apiHandler";

/** Verifikasi bahwa magang [id] memang milik DUDI yang sedang login */
async function getMagangForDudi(id, dudiId) {
  const rows = await query(
    `SELECT m.*, s.nama AS siswa_nama
     FROM magang m JOIN siswa s ON s.id = m.siswa_id
     WHERE m.id = ? AND m.dudi_id = ?`,
    [id, dudiId]
  );
  return rows[0] || null;
}

/** PUT /api/dudi/magang/[id] — simpan evaluasi (catatan_dudi & nilai_dudi) */
async function __PUT(request, { params }) {
  const dudi = await getCurrentDudi();
  if (!dudi) return NextResponse.json({ message: "Unauthorized" }, { status: 401 });

  const magang = await getMagangForDudi(params.id, dudi.id);
  if (!magang) {
    return NextResponse.json({ message: "Data magang tidak ditemukan." }, { status: 404 });
  }

  const body = await request.json();
  const { catatan_dudi, nilai_dudi } = body;

  // Validasi nilai
  if (nilai_dudi !== null && nilai_dudi !== undefined) {
    const n = Number(nilai_dudi);
    if (isNaN(n) || n < 0 || n > 100) {
      return NextResponse.json({ message: "Nilai harus berupa angka antara 0 dan 100." }, { status: 400 });
    }
  }

  await query(
    "UPDATE magang SET catatan_dudi = ?, nilai_dudi = ? WHERE id = ?",
    [catatan_dudi || null, nilai_dudi ?? null, params.id]
  );

  await logActivity(
    { id: dudi.id, nama: dudi.nama, role: "dudi" },
    "evaluate",
    `DUDI "${dudi.nama}" memberikan evaluasi untuk siswa "${magang.siswa_nama}"` +
      (nilai_dudi != null ? ` dengan nilai ${nilai_dudi}` : "")
  );

  return NextResponse.json({ message: "Evaluasi berhasil disimpan." });
}
export const PUT = withErrorHandler(__PUT);

