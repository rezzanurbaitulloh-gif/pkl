import { NextResponse } from "next/server";
import { getCurrentAdmin } from "@/lib/auth";
import { query } from "@/lib/db";
import { logActivity } from "@/lib/activityLog";
import { withErrorHandler } from "@/lib/apiHandler";

async function __GET() {
  const admin = await getCurrentAdmin();
  if (!admin) return NextResponse.json({ message: "Unauthorized" }, { status: 401 });
  const rows = await query(
    `SELECT d.*, COUNT(m.id) as jumlah_siswa
     FROM dudi d LEFT JOIN magang m ON m.dudi_id = d.id AND m.status = 'aktif'
     GROUP BY d.id`
  );
  return NextResponse.json(rows);
}
export const GET = withErrorHandler(__GET);


async function __POST(req) {
  const admin = await getCurrentAdmin();
  if (!admin) return NextResponse.json({ message: "Unauthorized" }, { status: 401 });
  const body = await req.json();
  const { nama, alamat, telepon, email, penanggung_jawab, status } = body;
  if (!nama) return NextResponse.json({ message: "Nama wajib diisi" }, { status: 400 });
  const result = await query(
    "INSERT INTO dudi (nama, alamat, telepon, email, penanggung_jawab, status) VALUES (?,?,?,?,?,?)",
    [nama, alamat || "", telepon || "", email || "", penanggung_jawab || "", status || "aktif"]
  );
  await logActivity(
    { id: admin.id, nama: admin.nama, role: "admin" },
    "create",
    `${admin.nama} menambahkan data DUDI "${nama}"`
  );
  return NextResponse.json({ id: result.insertId, message: "DUDI berhasil ditambahkan" });
}
export const POST = withErrorHandler(__POST);

