import { NextResponse } from "next/server";
import { getCurrentAdmin } from "@/lib/auth";
import { query } from "@/lib/db";
import { logActivity } from "@/lib/activityLog";
import { withErrorHandler } from "@/lib/apiHandler";

async function __PUT(req, { params }) {
  const admin = await getCurrentAdmin();
  if (!admin) return NextResponse.json({ message: "Unauthorized" }, { status: 401 });
  const body = await req.json();
  const { nama, alamat, telepon, email, penanggung_jawab, status } = body;
  if (!nama) return NextResponse.json({ message: "Nama wajib diisi" }, { status: 400 });
  await query(
    "UPDATE dudi SET nama=?, alamat=?, telepon=?, email=?, penanggung_jawab=?, status=? WHERE id=?",
    [nama, alamat || "", telepon || "", email || "", penanggung_jawab || "", status || "aktif", params.id]
  );
  await logActivity(
    { id: admin.id, nama: admin.nama, role: "admin" },
    "update",
    `${admin.nama} memperbarui data DUDI "${nama}"`
  );
  return NextResponse.json({ message: "DUDI berhasil diperbarui" });
}
export const PUT = withErrorHandler(__PUT);


async function __DELETE(req, { params }) {
  const admin = await getCurrentAdmin();
  if (!admin) return NextResponse.json({ message: "Unauthorized" }, { status: 401 });
  const rows = await query("SELECT nama FROM dudi WHERE id=?", [params.id]);
  const nama = rows[0]?.nama || params.id;
  await query("DELETE FROM dudi WHERE id=?", [params.id]);
  await logActivity(
    { id: admin.id, nama: admin.nama, role: "admin" },
    "delete",
    `${admin.nama} menghapus data DUDI "${nama}"`
  );
  return NextResponse.json({ message: "DUDI berhasil dihapus" });
}
export const DELETE = withErrorHandler(__DELETE);

