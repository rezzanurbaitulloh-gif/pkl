import { NextResponse } from "next/server";
import { getCurrentAdmin } from "@/lib/auth";
import { query } from "@/lib/db";
import { logActivity } from "@/lib/activityLog";
import { hashPassword } from "@/lib/password";
import { withErrorHandler } from "@/lib/apiHandler";

/** PUT /api/admin/dudi/[id]/akun — set atau update akun login DUDI */
async function __PUT(req, { params }) {
  const admin = await getCurrentAdmin();
  if (!admin) return NextResponse.json({ message: "Unauthorized" }, { status: 401 });

  const { login_email, login_password } = await req.json();

  if (!login_email) {
    return NextResponse.json({ message: "Email login wajib diisi." }, { status: 400 });
  }

  // Ambil data DUDI saat ini untuk cek apakah sudah punya akun
  const dudiRows = await query("SELECT * FROM dudi WHERE id = ?", [params.id]);
  if (!dudiRows[0]) {
    return NextResponse.json({ message: "DUDI tidak ditemukan." }, { status: 404 });
  }
  const dudi = dudiRows[0];

  // Cek duplikasi email (email lain yang sudah dipakai DUDI lain)
  const dupRows = await query(
    "SELECT id FROM dudi WHERE login_email = ? AND id != ?",
    [login_email, params.id]
  );
  if (dupRows.length > 0) {
    return NextResponse.json({ message: "Email login sudah digunakan oleh DUDI lain." }, { status: 409 });
  }

  if (login_password) {
    // Ubah email + password — password di-hash bcrypt sebelum disimpan,
    // konsisten dengan cara users.password disimpan (lihat src/lib/password.js)
    const hashedPassword = await hashPassword(login_password);
    await query(
      "UPDATE dudi SET login_email = ?, login_password = ? WHERE id = ?",
      [login_email, hashedPassword, params.id]
    );
  } else {
    // Hanya ubah email, biarkan password lama
    await query(
      "UPDATE dudi SET login_email = ? WHERE id = ?",
      [login_email, params.id]
    );
  }

  await logActivity(
    { id: admin.id, nama: admin.nama, role: "admin" },
    "update",
    `${admin.nama} ${dudi.login_email ? "memperbarui" : "membuat"} akun login DUDI "${dudi.nama}" (${login_email})`
  );

  return NextResponse.json({ message: "Akun login DUDI berhasil diperbarui." });
}
export const PUT = withErrorHandler(__PUT);


/** DELETE /api/admin/dudi/[id]/akun — hapus akun login DUDI */
async function __DELETE(req, { params }) {
  const admin = await getCurrentAdmin();
  if (!admin) return NextResponse.json({ message: "Unauthorized" }, { status: 401 });

  const dudiRows = await query("SELECT nama FROM dudi WHERE id = ?", [params.id]);
  if (!dudiRows[0]) {
    return NextResponse.json({ message: "DUDI tidak ditemukan." }, { status: 404 });
  }
  const nama = dudiRows[0].nama;

  await query(
    "UPDATE dudi SET login_email = NULL, login_password = NULL WHERE id = ?",
    [params.id]
  );

  await logActivity(
    { id: admin.id, nama: admin.nama, role: "admin" },
    "delete",
    `${admin.nama} menghapus akun login DUDI "${nama}"`
  );

  return NextResponse.json({ message: "Akun login DUDI berhasil dihapus." });
}
export const DELETE = withErrorHandler(__DELETE);

