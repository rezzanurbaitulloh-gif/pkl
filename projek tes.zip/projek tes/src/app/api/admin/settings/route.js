import { NextResponse } from "next/server";
import { getCurrentAdmin } from "@/lib/auth";
import { query } from "@/lib/db";
import { logActivity } from "@/lib/activityLog";
import { withErrorHandler } from "@/lib/apiHandler";

async function __GET() {
  const admin = await getCurrentAdmin();
  if (!admin) return NextResponse.json({ message: "Unauthorized" }, { status: 401 });

  const rows = await query("SELECT * FROM school_settings WHERE id = 1");
  return NextResponse.json(rows[0] || {}, {
    headers: { "Cache-Control": "no-store" },
  });
}
export const GET = withErrorHandler(__GET);


async function __PUT(req) {
  const admin = await getCurrentAdmin();
  if (!admin) return NextResponse.json({ message: "Unauthorized" }, { status: 401 });

  const body = await req.json();
  const { nama, alamat, telepon, email, website, kepala, npsn } = body;

  if (!nama) {
    return NextResponse.json({ message: "Nama sekolah wajib diisi" }, { status: 400 });
  }

  await query(
    `UPDATE school_settings SET nama=?, alamat=?, telepon=?, email=?, website=?, kepala=?, npsn=? WHERE id = 1`,
    [nama, alamat || "", telepon || "", email || "", website || "", kepala || "", npsn || ""]
  );

  const rows = await query("SELECT * FROM school_settings WHERE id = 1");
  await logActivity({ id: admin.id, nama: admin.nama, role: "admin" }, "update", `${admin.nama} memperbarui informasi sekolah`);
  return NextResponse.json({ message: "Pengaturan berhasil disimpan", settings: rows[0] });
}
export const PUT = withErrorHandler(__PUT);

