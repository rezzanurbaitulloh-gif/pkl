import { NextResponse } from "next/server";
import { getCurrentAdmin } from "@/lib/auth";
import { query } from "@/lib/db";
import { writeFile, mkdir, unlink } from "fs/promises";
import path from "path";
import { logActivity } from "@/lib/activityLog";
import { withErrorHandler } from "@/lib/apiHandler";
import { ALLOWED_TEMPLATE_TYPES, ALLOWED_TEMPLATE_TYPES_LABEL } from "@/lib/sertifikatTemplate";

const UPLOAD_DIR = path.join(process.cwd(), "public", "uploads");
const ALLOWED_TYPES = ALLOWED_TEMPLATE_TYPES;
const MAX_SIZE = 10 * 1024 * 1024;

async function __GET() {
  const admin = await getCurrentAdmin();
  if (!admin) return NextResponse.json({ message: "Unauthorized" }, { status: 401 });

  const settingsRows = await query(
    "SELECT sertifikat_template, sertifikat_format_nomor, sertifikat_counter FROM school_settings WHERE id = 1"
  );
  const configRows = await query("SELECT * FROM sertifikat_config WHERE id = 1");

  return NextResponse.json({
    template: settingsRows[0]?.sertifikat_template || "",
    format_nomor: settingsRows[0]?.sertifikat_format_nomor || "SKT/{urutan}/{tahun}",
    counter: settingsRows[0]?.sertifikat_counter || 0,
    config: configRows[0] || {},
  });
}
export const GET = withErrorHandler(__GET);


async function __POST(req) {
  const admin = await getCurrentAdmin();
  if (!admin) return NextResponse.json({ message: "Unauthorized" }, { status: 401 });

  const formData = await req.formData();
  const file = formData.get("template");

  if (!file || typeof file === "string")
    return NextResponse.json({ message: "File template tidak ditemukan" }, { status: 400 });
  if (!ALLOWED_TYPES.includes(file.type))
    return NextResponse.json({ message: `Format file tidak didukung. Gunakan ${ALLOWED_TEMPLATE_TYPES_LABEL}.` }, { status: 400 });
  if (file.size > MAX_SIZE)
    return NextResponse.json({ message: "Ukuran file maksimal 10MB" }, { status: 400 });

  await mkdir(UPLOAD_DIR, { recursive: true });
  const ext = path.extname(file.name) || ".png";
  const fileName = `sertifikat-template-${Date.now()}${ext}`;
  const filePath = path.join(UPLOAD_DIR, fileName);
  await writeFile(filePath, Buffer.from(await file.arrayBuffer()));
  const templateUrl = `/uploads/${fileName}`;

  const rows = await query("SELECT sertifikat_template FROM school_settings WHERE id = 1");
  const old = rows[0]?.sertifikat_template;
  if (old && old.startsWith("/uploads/"))
    unlink(path.join(process.cwd(), "public", old)).catch(() => {});

  await query("UPDATE school_settings SET sertifikat_template = ? WHERE id = 1", [templateUrl]);
  await logActivity(
    { id: admin.id, nama: admin.nama, role: "admin" },
    "upload",
    `${admin.nama} mengunggah template sertifikat magang`
  );

  return NextResponse.json({ message: "Template berhasil diunggah", template_url: templateUrl });
}
export const POST = withErrorHandler(__POST);


async function __PUT(req) {
  const admin = await getCurrentAdmin();
  if (!admin) return NextResponse.json({ message: "Unauthorized" }, { status: 401 });

  const body = await req.json();
  const { format_nomor, config } = body;

  if (format_nomor !== undefined)
    await query("UPDATE school_settings SET sertifikat_format_nomor = ? WHERE id = 1", [format_nomor || "SKT/{urutan}/{tahun}"]);

  if (config) {
    const fields = [
      "field_nama_x","field_nama_y","field_nama_size","field_nama_color",
      "field_ttl_x","field_ttl_y","field_ttl_size","field_ttl_color",
      "field_nisn_x","field_nisn_y","field_nisn_size","field_nisn_color",
      "field_kompetensi_x","field_kompetensi_y","field_kompetensi_size","field_kompetensi_color",
      "field_sekolah_x","field_sekolah_y","field_sekolah_size","field_sekolah_color",
      "field_deskripsi_x","field_deskripsi_y","field_deskripsi_size","field_deskripsi_color",
      "field_kepsek_x","field_kepsek_y","field_kepsek_size","field_kepsek_color",
      "field_pimpinan_x","field_pimpinan_y","field_pimpinan_size","field_pimpinan_color",
      "field_nomor_x","field_nomor_y","field_nomor_size","field_nomor_color",
    ];
    const setClauses = fields.map(f => `${f} = ?`).join(", ");
    const values = fields.map(f => config[f] !== undefined ? config[f] : null);
    await query(`UPDATE sertifikat_config SET ${setClauses} WHERE id = 1`, values);
  }

  await logActivity(
    { id: admin.id, nama: admin.nama, role: "admin" },
    "update",
    `${admin.nama} memperbarui konfigurasi sertifikat magang`
  );

  return NextResponse.json({ message: "Konfigurasi sertifikat berhasil disimpan" });
}
export const PUT = withErrorHandler(__PUT);

