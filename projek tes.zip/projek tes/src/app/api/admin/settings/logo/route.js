import { NextResponse } from "next/server";
import { getCurrentAdmin } from "@/lib/auth";
import { query } from "@/lib/db";
import { writeFile, mkdir, unlink } from "fs/promises";
import path from "path";
import { logActivity } from "@/lib/activityLog";
import { withErrorHandler } from "@/lib/apiHandler";

const UPLOAD_DIR = path.join(process.cwd(), "public", "uploads");
const ALLOWED_TYPES = ["image/png", "image/jpeg", "image/jpg", "image/webp", "image/svg+xml", "image/gif"];
const MAX_SIZE = 2 * 1024 * 1024; // 2MB

async function __POST(req) {
  const admin = await getCurrentAdmin();
  if (!admin) return NextResponse.json({ message: "Unauthorized" }, { status: 401 });

  const formData = await req.formData();
  const file = formData.get("logo");

  if (!file || typeof file === "string") {
    return NextResponse.json({ message: "File logo tidak ditemukan" }, { status: 400 });
  }

  if (!ALLOWED_TYPES.includes(file.type)) {
    return NextResponse.json({ message: "Format file tidak didukung. Gunakan PNG, JPG, WEBP, GIF, atau SVG." }, { status: 400 });
  }

  if (file.size > MAX_SIZE) {
    return NextResponse.json({ message: "Ukuran file maksimal 2MB" }, { status: 400 });
  }

  await mkdir(UPLOAD_DIR, { recursive: true });

  const ext = path.extname(file.name) || ".png";
  const fileName = `logo-${Date.now()}${ext}`;
  const filePath = path.join(UPLOAD_DIR, fileName);

  const buffer = Buffer.from(await file.arrayBuffer());
  await writeFile(filePath, buffer);

  const logoUrl = `/uploads/${fileName}`;

  // Hapus logo lama jika ada, supaya tidak menumpuk file
  const rows = await query("SELECT logo_url FROM school_settings WHERE id = 1");
  const oldLogo = rows[0]?.logo_url;

  await query("UPDATE school_settings SET logo_url = ? WHERE id = 1", [logoUrl]);

  if (oldLogo && oldLogo.startsWith("/uploads/")) {
    const oldPath = path.join(process.cwd(), "public", oldLogo);
    unlink(oldPath).catch(() => {});
  }

  await logActivity({ id: admin.id, nama: admin.nama, role: "admin" }, "upload", `${admin.nama} mengganti logo sekolah`);

  return NextResponse.json({ message: "Logo berhasil diperbarui", logo_url: logoUrl });
}
export const POST = withErrorHandler(__POST);

