import { NextResponse } from "next/server";
import { getCurrentAdmin } from "@/lib/auth";
import { query } from "@/lib/db";
import { withErrorHandler } from "@/lib/apiHandler";

async function __GET(request) {
  const admin = await getCurrentAdmin();
  if (!admin) return NextResponse.json({ message: "Unauthorized" }, { status: 401 });

  const { searchParams } = new URL(request.url);
  const role = searchParams.get("role") || "";
  const search = searchParams.get("search") || "";
  const limit = Math.min(parseInt(searchParams.get("limit") || "50", 10), 200);

  let where = "WHERE 1=1";
  const params = [];
  if (role) {
    where += " AND role = ?";
    params.push(role);
  }
  if (search) {
    where += " AND (user_nama LIKE ? OR description LIKE ?)";
    params.push(`%${search}%`, `%${search}%`);
  }

  const rows = await query(
    `SELECT * FROM activity_logs ${where} ORDER BY id DESC LIMIT ?`,
    [...params, limit]
  );

  return NextResponse.json(rows, { headers: { "Cache-Control": "no-store" } });
}
export const GET = withErrorHandler(__GET);


async function __DELETE(request) {
  const admin = await getCurrentAdmin();
  if (!admin) return NextResponse.json({ message: "Unauthorized" }, { status: 401 });

  const { searchParams } = new URL(request.url);
  const mode = searchParams.get("mode") || "all"; // "all" | "old" (older than 30 days)

  let sql;
  if (mode === "old") {
    sql = "DELETE FROM activity_logs WHERE created_at < DATE_SUB(NOW(), INTERVAL 30 DAY)";
  } else {
    sql = "DELETE FROM activity_logs";
  }

  const result = await query(sql);

  // Catat aksi clear log ke activity_logs agar ada jejak
  const desc =
    mode === "old"
      ? "Menghapus log aktivitas lebih dari 30 hari yang lalu"
      : "Menghapus semua riwayat aktivitas";
  await query(
    "INSERT INTO activity_logs (user_id, user_nama, role, action, description) VALUES (?, ?, 'admin', 'delete', ?)",
    [admin.id, admin.nama || admin.username, desc]
  );

  return NextResponse.json({ message: "Log berhasil dihapus", affected: result.affectedRows });
}
export const DELETE = withErrorHandler(__DELETE);

