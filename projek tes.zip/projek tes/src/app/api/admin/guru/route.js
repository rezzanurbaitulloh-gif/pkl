import { NextResponse } from "next/server";
import { getCurrentAdmin } from "@/lib/auth";
import { query } from "@/lib/db";
import { logActivity } from "@/lib/activityLog";
import { withErrorHandler } from "@/lib/apiHandler";
import { ensureUserForRole } from "@/lib/userSync";

async function __GET() {
  const admin = await getCurrentAdmin();
  if (!admin) return NextResponse.json({ message: "Unauthorized" }, { status: 401 });
  const rows = await query(
    `SELECT g.*, COUNT(m.id) as jumlah_siswa
     FROM guru g LEFT JOIN magang m ON m.guru_id = g.id AND m.status='aktif'
     GROUP BY g.id`
  );
  return NextResponse.json(rows);
}
export const GET = withErrorHandler(__GET);


async function __POST(req) {
  const admin = await getCurrentAdmin();
  if (!admin) return NextResponse.json({ message: "Unauthorized" }, { status: 401 });
  const body = await req.json();
  const { nip, nama, mapel, email, telepon, alamat, status, password } = body;
  if (!nip || !nama) return NextResponse.json({ message: "NIP dan nama wajib diisi" }, { status: 400 });

  // Perbaikan Bug #4 & #11: setiap guru baru sekarang SELALU punya akun
  // users yang terhubung lewat user_id (sebelumnya hanya dibuat jika email
  // diisi DAN belum terdaftar, sehingga guru.user_id tidak pernah terisi
  // sama sekali — akar masalah Bug #4). ensureUserForRole() juga menolak
  // (409) jika email yang dimasukkan sudah dipakai role lain (Bug #11).
  const userId = await ensureUserForRole({
    role: "guru",
    email,
    nama,
    password,
    fallbackEmail: `${nip}@teacher.sch.id`,
  });

  const result = await query(
    "INSERT INTO guru (user_id, nip, nama, mapel, email, telepon, alamat, status) VALUES (?,?,?,?,?,?,?,?)",
    [userId, nip, nama, mapel || "", email || "", telepon || "", alamat || "", status || "aktif"]
  );
  await logActivity({ id: admin.id, nama: admin.nama, role: "admin" }, "create", `${admin.nama} menambahkan data guru "${nama}" (NIP ${nip})`);
  return NextResponse.json({ id: result.insertId, message: "Guru berhasil ditambahkan" });
}
export const POST = withErrorHandler(__POST);

