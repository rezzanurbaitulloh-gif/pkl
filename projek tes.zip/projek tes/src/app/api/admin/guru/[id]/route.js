import { NextResponse } from "next/server";
import { getCurrentAdmin } from "@/lib/auth";
import { query } from "@/lib/db";
import { logActivity } from "@/lib/activityLog";
import { withErrorHandler } from "@/lib/apiHandler";
import { syncUserEmail, deleteLinkedUser } from "@/lib/userSync";

async function __PUT(req, { params }) {
  const admin = await getCurrentAdmin();
  if (!admin) return NextResponse.json({ message: "Unauthorized" }, { status: 401 });
  const body = await req.json();
  const { nip, nama, mapel, email, telepon, alamat, status } = body;

  const existingRows = await query("SELECT user_id FROM guru WHERE id=?", [params.id]);
  const userId = existingRows[0]?.user_id;

  // Perbaikan Bug #4: sinkronkan users.email/users.nama ketika email/nama
  // guru diubah lewat menu ini (sebelumnya users.email tidak pernah ikut
  // berubah, sehingga guru tetap login dengan email lama).
  await syncUserEmail({ userId, newEmail: email, newNama: nama, expectedRole: "guru" });

  await query(
    "UPDATE guru SET nip=?, nama=?, mapel=?, email=?, telepon=?, alamat=?, status=? WHERE id=?",
    [nip, nama, mapel, email, telepon, alamat, status, params.id]
  );
  await logActivity({ id: admin.id, nama: admin.nama, role: "admin" }, "update", `${admin.nama} memperbarui data guru "${nama}" (NIP ${nip})`);
  return NextResponse.json({ message: "Berhasil diperbarui" });
}
export const PUT = withErrorHandler(__PUT);


async function __DELETE(req, { params }) {
  const admin = await getCurrentAdmin();
  if (!admin) return NextResponse.json({ message: "Unauthorized" }, { status: 401 });
  const rows = await query("SELECT nama, nip, user_id FROM guru WHERE id=?", [params.id]);
  const target = rows[0];
  await query("DELETE FROM guru WHERE id=?", [params.id]);

  // Perbaikan Bug #4: hapus juga akun login terkait supaya tidak tertinggal
  // sebagai akun "yatim" (sebelumnya tidak pernah dihapus sama sekali).
  await deleteLinkedUser(target?.user_id);

  await logActivity({ id: admin.id, nama: admin.nama, role: "admin" }, "delete", `${admin.nama} menghapus data guru "${target?.nama || params.id}" (NIP ${target?.nip || "-"})`);
  return NextResponse.json({ message: "Berhasil dihapus" });
}
export const DELETE = withErrorHandler(__DELETE);

