import { NextResponse } from "next/server";
import { getCurrentAdmin } from "@/lib/auth";
import { query } from "@/lib/db";
import { logActivity } from "@/lib/activityLog";
import { withErrorHandler } from "@/lib/apiHandler";
import { syncUserEmail, deleteLinkedUser } from "@/lib/userSync";

async function __PUT(req, { params }) {
  const admin = await getCurrentAdmin();
  if (!admin) return NextResponse.json({ message: "Unauthorized" }, { status: 401 });

  const body = await req.json();
  const { nis, nisn, nama, kelas, jurusan, email, telepon, alamat, status, tempat_lahir, tanggal_lahir } = body;

  const existingRows = await query("SELECT user_id FROM siswa WHERE id=?", [params.id]);
  const userId = existingRows[0]?.user_id;

  // Perbaikan Bug #4: sinkronkan users.email/users.nama ketika email/nama
  // siswa diubah lewat menu ini, supaya akun login siswa tidak "tertinggal"
  // memakai email lama (sebelumnya users.email tidak pernah ikut berubah).
  await syncUserEmail({ userId, newEmail: email, newNama: nama, expectedRole: "siswa" });

  await query(
    "UPDATE siswa SET nis=?, nisn=?, nama=?, kelas=?, jurusan=?, email=?, telepon=?, alamat=?, status=?, tempat_lahir=?, tanggal_lahir=? WHERE id=?",
    [nis, nisn||null, nama, kelas, jurusan, email, telepon, alamat, status, tempat_lahir||null, tanggal_lahir||null, params.id]
  );
  await logActivity({ id: admin.id, nama: admin.nama, role: "admin" }, "update", `${admin.nama} memperbarui data siswa "${nama}" (NIS ${nis})`);
  return NextResponse.json({ message: "Berhasil diperbarui" });
}
export const PUT = withErrorHandler(__PUT);


async function __DELETE(req, { params }) {
  const admin = await getCurrentAdmin();
  if (!admin) return NextResponse.json({ message: "Unauthorized" }, { status: 401 });
  const rows = await query("SELECT nama, nis, user_id FROM siswa WHERE id=?", [params.id]);
  const target = rows[0];
  await query("DELETE FROM siswa WHERE id=?", [params.id]);

  // Perbaikan Bug #4: sebelumnya menghapus siswa TIDAK menghapus baris users
  // terkait, sehingga akun login "yatim" tetap ada di sistem walau datanya
  // sudah tidak ada lagi.
  await deleteLinkedUser(target?.user_id);

  await logActivity({ id: admin.id, nama: admin.nama, role: "admin" }, "delete", `${admin.nama} menghapus data siswa "${target?.nama||params.id}" (NIS ${target?.nis||"-"})`);
  return NextResponse.json({ message: "Berhasil dihapus" });
}
export const DELETE = withErrorHandler(__DELETE);

