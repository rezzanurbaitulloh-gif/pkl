import { NextResponse } from "next/server";
import { getCurrentAdmin } from "@/lib/auth";
import { query } from "@/lib/db";
import { logActivity } from "@/lib/activityLog";
import { withErrorHandler } from "@/lib/apiHandler";
import { ensureUserForRole } from "@/lib/userSync";

// Fungsi untuk mengambil/menampilkan daftar siswa
async function __GET() {
  const admin = await getCurrentAdmin();
  if (!admin) return NextResponse.json({ message: "Unauthorized" }, { status: 401 });

  const rows = await query(
    `SELECT s.*, g.nama as guru_nama, d.nama as dudi_nama
     FROM siswa s
     LEFT JOIN guru g ON g.id = (SELECT guru_id FROM magang WHERE siswa_id=s.id ORDER BY id DESC LIMIT 1)
     LEFT JOIN dudi d ON d.id = (SELECT dudi_id FROM magang WHERE siswa_id=s.id ORDER BY id DESC LIMIT 1)`
  );
  return NextResponse.json(rows);
}
export const GET = withErrorHandler(__GET);


// Fungsi untuk menambah data siswa baru
async function __POST(req) {
  const admin = await getCurrentAdmin();
  if (!admin) return NextResponse.json({ message: "Unauthorized" }, { status: 401 });

  const body = await req.json();
  const { nis, nisn, nama, kelas, jurusan, email, telepon, alamat, status, password, tempat_lahir, tanggal_lahir } = body;
  if (!nis || !nama) return NextResponse.json({ message: "NIS dan nama wajib diisi" }, { status: 400 });

  // Perbaikan Bug #11: sebelumnya jika email sudah ada di tabel users untuk
  // role LAIN (misal sudah dipakai akun guru), sistem langsung "menumpang"
  // user_id tersebut tanpa mengecek kecocokan role. ensureUserForRole()
  // sekarang menolak (ApiError 409) jika terjadi bentrok role, dengan pesan
  // yang jelas untuk admin.
  const userId = await ensureUserForRole({
    role: "siswa",
    email,
    nama,
    password,
    fallbackEmail: `${nis}@student.sch.id`,
  });

  // Proses input data ke tabel siswa (Urutan sudah disamakan persis dengan phpMyAdmin)
  const result = await query(
    "INSERT INTO siswa (user_id, nis, nisn, tempat_lahir, tanggal_lahir, nama, kelas, jurusan, email, telepon, alamat, status) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)",
    [
      userId, 
      nis, 
      nisn || null, 
      tempat_lahir || null, 
      tanggal_lahir || null, 
      nama, 
      kelas || "", 
      jurusan || "", 
      email || "", 
      telepon || "", 
      alamat || "", 
      status || "aktif"
    ]
  );

  // Catat aktivitas admin ke log
  await logActivity(
    { id: admin.id, nama: admin.nama, role: "admin" }, 
    "create", 
    `${admin.nama} menambahkan data siswa "${nama}" (NIS ${nis})`
  );

  return NextResponse.json({ id: result.insertId, message: "Siswa berhasil ditambahkan" });
}
export const POST = withErrorHandler(__POST);
