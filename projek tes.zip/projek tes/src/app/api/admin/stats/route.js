import { NextResponse } from "next/server";
import { getCurrentAdmin } from "@/lib/auth";
import { query } from "@/lib/db";
import { withErrorHandler } from "@/lib/apiHandler";

async function __GET() {
  const admin = await getCurrentAdmin();
  if (!admin) return NextResponse.json({ message: "Unauthorized" }, { status: 401 });

  const siswaRows = await query("SELECT COUNT(*) as total FROM siswa");
  const dudiRows = await query("SELECT COUNT(*) as total FROM dudi WHERE status='aktif'");
  const magangRows = await query("SELECT COUNT(*) as total FROM magang WHERE status='aktif'");
  const today = new Date().toISOString().split("T")[0];
  const jurnalRows = await query("SELECT COUNT(*) as total FROM jurnal WHERE tanggal=?", [today]);
  const pendaftaranPendingRows = await query("SELECT COUNT(*) as total FROM pendaftaran WHERE status='pending'");

  const pendaftaranPending = await query(
    `SELECT p.*, s.nama as siswa_nama, s.nis as siswa_nis, d.nama as dudi_nama, g.nama as guru_nama
     FROM pendaftaran p
     LEFT JOIN siswa s ON s.id = p.siswa_id
     LEFT JOIN dudi d ON d.id = p.dudi_id
     LEFT JOIN guru g ON g.id = p.guru_id
     WHERE p.status='pending'
     ORDER BY p.id DESC LIMIT 5`
  );

  const recentMagang = await query(
    `SELECT m.*, s.nama as siswa_nama, d.nama as dudi_nama, g.nama as guru_nama,
            m.tanggal_mulai, m.tanggal_selesai
     FROM magang m
     LEFT JOIN siswa s ON s.id = m.siswa_id
     LEFT JOIN dudi d ON d.id = m.dudi_id
     LEFT JOIN guru g ON g.id = m.guru_id
     ORDER BY m.id DESC LIMIT 5`
  );

  const recentJurnal = await query(
    `SELECT j.*, s.nama as siswa_nama
     FROM jurnal j LEFT JOIN siswa s ON s.id = j.siswa_id
     ORDER BY j.tanggal DESC, j.id DESC LIMIT 5`
  );

  const dudiAktif = await query(
    `SELECT d.*, COUNT(m.id) as jumlah_siswa
     FROM dudi d LEFT JOIN magang m ON m.dudi_id = d.id AND m.status='aktif'
     WHERE d.status='aktif' GROUP BY d.id LIMIT 5`
  );

  return NextResponse.json({
    stats: {
      siswa: Number(siswaRows[0]?.total) || 0,
      dudi: Number(dudiRows[0]?.total) || 0,
      magang: Number(magangRows[0]?.total) || 0,
      jurnal: Number(jurnalRows[0]?.total) || 0,
      pendaftaranPending: Number(pendaftaranPendingRows[0]?.total) || 0,
    },
    recentMagang,
    recentJurnal,
    dudiAktif,
    pendaftaranPending,
  });
}
export const GET = withErrorHandler(__GET);

