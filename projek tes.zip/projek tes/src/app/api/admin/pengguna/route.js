import { NextResponse } from "next/server";
import { getCurrentAdmin } from "@/lib/auth";
import { query } from "@/lib/db";
import { logActivity } from "@/lib/activityLog";
import { isValidEmailForRole } from "@/lib/utils";
import { hashPassword } from "@/lib/password";
import { withErrorHandler } from "@/lib/apiHandler";

async function __GET() {
  const admin = await getCurrentAdmin();
  if (!admin) return NextResponse.json({ message: "Unauthorized" }, { status: 401 });
  const rows = await query("SELECT id, nama, email, role, verified, created_at FROM users ORDER BY id");
  return NextResponse.json(rows);
}
export const GET = withErrorHandler(__GET);


async function __POST(req) {
  const admin = await getCurrentAdmin();
  if (!admin) return NextResponse.json({ message: "Unauthorized" }, { status: 401 });
  const body = await req.json();
  const { nama, email, password, confirmPassword, role, verified } = body;

  if (!nama || !email || !password) return NextResponse.json({ message: "Nama, email, dan password wajib diisi" }, { status: 400 });
  if (!isValidEmailForRole(email, role || "siswa")) return NextResponse.json({ message: "Format email tidak valid" }, { status: 400 });
  if (password.length < 6) return NextResponse.json({ message: "Password minimal 6 karakter" }, { status: 400 });
  if (confirmPassword !== undefined && password !== confirmPassword) {
    return NextResponse.json({ message: "Konfirmasi password tidak sesuai" }, { status: 400 });
  }

  const existing = await query("SELECT id FROM users WHERE email=?", [email]);
  if (existing.length > 0) return NextResponse.json({ message: "Email sudah digunakan" }, { status: 409 });

  const result = await query(
    "INSERT INTO users (nama, email, password, role, verified) VALUES (?,?,?,?,?)",
    [nama, email, await hashPassword(password), role || "siswa", verified !== undefined ? !!verified : true]
  );

  await logActivity(
    { id: admin.id, nama: admin.nama, role: "admin" },
    "create",
    `${admin.nama} menambahkan pengguna baru "${nama}" (${email}) dengan role ${role || "siswa"}`
  );

  return NextResponse.json({ id: result.insertId, message: "User berhasil ditambahkan" });
}
export const POST = withErrorHandler(__POST);

