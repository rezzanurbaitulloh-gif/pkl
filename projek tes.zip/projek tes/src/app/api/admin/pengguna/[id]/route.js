import { NextResponse } from "next/server";
import { getCurrentAdmin } from "@/lib/auth";
import { query } from "@/lib/db";
import { logActivity } from "@/lib/activityLog";
import { isValidEmailForRole } from "@/lib/utils";
import { hashPassword } from "@/lib/password";
import { withErrorHandler } from "@/lib/apiHandler";

// Perbaikan Bug #4 (arah sebaliknya): jika email/nama diubah lewat menu
// "Manajemen Pengguna", sinkronkan juga ke tabel siswa/guru yang terhubung
// lewat user_id, supaya data profil tidak "tertinggal" memakai email/nama
// lama (sebelumnya perubahan di sini sama sekali tidak menjalar ke tabel
// siswa/guru).
async function syncProfileTable(userId, role, nama, email) {
  if (role === "siswa") {
    await query("UPDATE siswa SET nama=?, email=? WHERE user_id=?", [nama, email, userId]);
  } else if (role === "guru") {
    await query("UPDATE guru SET nama=?, email=? WHERE user_id=?", [nama, email, userId]);
  }
}

async function __PUT(req, { params }) {
  const admin = await getCurrentAdmin();
  if (!admin) return NextResponse.json({ message: "Unauthorized" }, { status: 401 });
  const body = await req.json();
  const { nama, email, role, password, confirmPassword, verified } = body;

  if (!nama || !email) return NextResponse.json({ message: "Nama dan email wajib diisi" }, { status: 400 });
  if (!isValidEmailForRole(email, role)) return NextResponse.json({ message: "Format email tidak valid" }, { status: 400 });

  if (password) {
    if (password.length < 6) return NextResponse.json({ message: "Password minimal 6 karakter" }, { status: 400 });
    if (confirmPassword !== undefined && password !== confirmPassword) {
      return NextResponse.json({ message: "Konfirmasi password tidak sesuai" }, { status: 400 });
    }
    await query("UPDATE users SET nama=?, email=?, role=?, password=?, verified=? WHERE id=?",
      [nama, email, role, await hashPassword(password), verified !== undefined ? !!verified : true, params.id]);
  } else {
    await query("UPDATE users SET nama=?, email=?, role=?, verified=? WHERE id=?",
      [nama, email, role, verified !== undefined ? !!verified : true, params.id]);
  }

  await syncProfileTable(params.id, role, nama, email);

  await logActivity(
    { id: admin.id, nama: admin.nama, role: "admin" },
    "update",
    `${admin.nama} memperbarui data pengguna "${nama}" (${email})`
  );

  return NextResponse.json({ message: "Berhasil diperbarui" });
}
export const PUT = withErrorHandler(__PUT);


async function __DELETE(req, { params }) {
  const admin = await getCurrentAdmin();
  if (!admin) return NextResponse.json({ message: "Unauthorized" }, { status: 401 });
  if (Number(params.id) === 1) return NextResponse.json({ message: "Admin utama tidak dapat dihapus" }, { status: 403 });

  const rows = await query("SELECT nama, email FROM users WHERE id=?", [params.id]);
  const target = rows[0];

  await query("DELETE FROM users WHERE id=?", [params.id]);

  await logActivity(
    { id: admin.id, nama: admin.nama, role: "admin" },
    "delete",
    `${admin.nama} menghapus pengguna "${target?.nama || params.id}" (${target?.email || "-"})`
  );

  return NextResponse.json({ message: "Berhasil dihapus" });
}
export const DELETE = withErrorHandler(__DELETE);

