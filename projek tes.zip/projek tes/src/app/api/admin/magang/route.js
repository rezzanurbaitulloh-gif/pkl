import { NextResponse } from "next/server";
import { getCurrentAdmin } from "@/lib/auth";
import { query } from "@/lib/db";
import { logActivity } from "@/lib/activityLog";
import { withErrorHandler } from "@/lib/apiHandler";

async function __GET() {
  const admin = await getCurrentAdmin();
  if (!admin) return NextResponse.json({ message: "Unauthorized" }, { status: 401 });
  const rows = await query(
    `SELECT m.*, s.nama as siswa_nama, d.nama as dudi_nama, g.nama as guru_nama
     FROM magang m
     LEFT JOIN siswa s ON s.id=m.siswa_id
     LEFT JOIN dudi d ON d.id=m.dudi_id
     LEFT JOIN guru g ON g.id=m.guru_id
     ORDER BY m.id DESC`
  );
  return NextResponse.json(rows);
}
export const GET = withErrorHandler(__GET);


async function __POST(req) {
  const admin = await getCurrentAdmin();
  if (!admin) return NextResponse.json({ message: "Unauthorized" }, { status: 401 });
  const body = await req.json();
  const { siswa_id, dudi_id, guru_id, status, tanggal_mulai, tanggal_selesai, catatan } = body;
  if (!siswa_id || !dudi_id) return NextResponse.json({ message: "Siswa dan DUDI wajib dipilih" }, { status: 400 });
  const result = await query(
    "INSERT INTO magang (siswa_id, dudi_id, guru_id, status, tanggal_mulai, tanggal_selesai, catatan) VALUES (?,?,?,?,?,?,?)",
    [siswa_id, dudi_id, guru_id || null, status || "aktif", tanggal_mulai || null, tanggal_selesai || null, catatan || ""]
  );
  const sRows = await query("SELECT nama FROM siswa WHERE id=?", [siswa_id]);
  await logActivity({ id: admin.id, nama: admin.nama, role: "admin" }, "create", `${admin.nama} menambahkan data magang untuk "${sRows[0]?.nama || siswa_id}"`);
  return NextResponse.json({ id: result.insertId, message: "Data magang berhasil ditambahkan" });
}
export const POST = withErrorHandler(__POST);

