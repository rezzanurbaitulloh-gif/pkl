import { NextResponse } from "next/server";
import { getCurrentAdmin } from "@/lib/auth";
import { query } from "@/lib/db";
import { logActivity } from "@/lib/activityLog";
import { withErrorHandler } from "@/lib/apiHandler";

async function __PUT(req, { params }) {
  const admin = await getCurrentAdmin();
  if (!admin) return NextResponse.json({ message: "Unauthorized" }, { status: 401 });
  const body = await req.json();
  const { siswa_id, dudi_id, guru_id, status, tanggal_mulai, tanggal_selesai, catatan } = body;
  await query(
    "UPDATE magang SET siswa_id=?, dudi_id=?, guru_id=?, status=?, tanggal_mulai=?, tanggal_selesai=?, catatan=? WHERE id=?",
    [siswa_id, dudi_id, guru_id || null, status, tanggal_mulai || null, tanggal_selesai || null, catatan, params.id]
  );
  const sRows = await query("SELECT nama FROM siswa WHERE id=?", [siswa_id]);
  await logActivity({ id: admin.id, nama: admin.nama, role: "admin" }, "update", `${admin.nama} memperbarui data magang "${sRows[0]?.nama || siswa_id}"`);
  return NextResponse.json({ message: "Berhasil diperbarui" });
}
export const PUT = withErrorHandler(__PUT);


async function __DELETE(req, { params }) {
  const admin = await getCurrentAdmin();
  if (!admin) return NextResponse.json({ message: "Unauthorized" }, { status: 401 });
  const rows = await query("SELECT s.nama FROM magang m LEFT JOIN siswa s ON s.id=m.siswa_id WHERE m.id=?", [params.id]);
  const target = rows[0];
  await query("DELETE FROM magang WHERE id=?", [params.id]);
  await logActivity({ id: admin.id, nama: admin.nama, role: "admin" }, "delete", `${admin.nama} menghapus data magang "${target?.nama || params.id}"`);
  return NextResponse.json({ message: "Berhasil dihapus" });
}
export const DELETE = withErrorHandler(__DELETE);

