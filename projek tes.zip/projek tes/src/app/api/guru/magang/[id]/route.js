import { NextResponse } from "next/server";
import { getCurrentGuru, resolveGuruId } from "@/lib/auth";
import { query } from "@/lib/db";
import { logActivity } from "@/lib/activityLog";
import { withErrorHandler } from "@/lib/apiHandler";
import { stopMagang } from "@/lib/magang";
import { validateNilai } from "@/lib/utils";

// Fungsi generate nomor sertifikat dari format yang ditentukan admin
async function generateNomorSertifikat() {
  // Ambil format dan counter saat ini, lalu increment (atomic)
  const rows = await query(
    "SELECT sertifikat_format_nomor, sertifikat_counter FROM school_settings WHERE id = 1"
  );
  const settings = rows[0] || {};
  const format = settings.sertifikat_format_nomor || "SKT/{urutan}/{tahun}";
  const newCounter = (settings.sertifikat_counter || 0) + 1;

  // Update counter di DB
  await query("UPDATE school_settings SET sertifikat_counter = ? WHERE id = 1", [newCounter]);

  const tahun = new Date().getFullYear();
  const bulan = String(new Date().getMonth() + 1).padStart(2, "0");
  const urutan = String(newCounter).padStart(3, "0");

  // Ganti placeholder di format
  const nomor = format
    .replace(/\{urutan\}/gi, urutan)
    .replace(/\{tahun\}/gi, tahun)
    .replace(/\{bulan\}/gi, bulan);

  return nomor;
}

async function __PUT(req, { params }) {
  const guru = await getCurrentGuru();
  if (!guru) return NextResponse.json({ message: "Unauthorized" }, { status: 401 });

  // Perbaikan Bug #3 (IDOR): sebelumnya query di bawah ini TIDAK membatasi
  // kepemilikan (tidak ada "AND guru_id = ?"), sehingga guru manapun bisa
  // mengubah/menyelesaikan/membatalkan magang siswa bimbingan guru lain,
  // termasuk menerbitkan nomor sertifikat untuk siswa yang bukan
  // bimbingannya. Pola yang benar ini disamakan dengan
  // `src/app/api/dudi/magang/[id]/route.js` dan
  // `src/app/api/guru/pendaftaran/[id]/route.js`.
  const guruId = await resolveGuruId(guru);
  if (!guruId) return NextResponse.json({ message: "Data guru tidak ditemukan" }, { status: 404 });

  const body = await req.json();
  const { status, tanggal_mulai, tanggal_selesai, catatan, nilai } = body;

  const rows = await query(
    `SELECT m.*, s.nama as siswa_nama FROM magang m LEFT JOIN siswa s ON s.id=m.siswa_id WHERE m.id=? AND m.guru_id=?`,
    [params.id, guruId]
  );
  const magang = rows[0];
  if (!magang) return NextResponse.json({ message: "Data magang tidak ditemukan" }, { status: 404 });

  const siswaNama = magang.siswa_nama || "siswa";

  if (nilai !== undefined) {
    // Perbaikan Bug #7: validasi nilai 0-100 di backend (sebelumnya hanya
    // divalidasi di frontend, sehingga lewat DevTools/Postman nilai negatif,
    // di atas 100, atau teks non-angka bisa tersimpan). Memakai helper
    // validateNilai() yang sama dipakai endpoint DUDI agar konsisten.
    const { valid, value, error } = validateNilai(nilai);
    if (!valid) {
      return NextResponse.json({ message: error }, { status: 400 });
    }
    await query("UPDATE magang SET nilai=? WHERE id=?", [value, params.id]);
    await logActivity(
      { id: guru.id, nama: guru.nama, role: "guru" },
      "update",
      `${guru.nama} memberikan nilai ${value} untuk magang ${siswaNama}`
    );
  } else {
    // Validasi: jika status dibatalkan, wajib ada alasan (catatan)
    if (status === "dibatalkan") {
      if (!catatan || catatan.trim() === "") {
        return NextResponse.json(
          { message: "Alasan pemberhentian wajib diisi ketika membatalkan magang siswa." },
          { status: 400 }
        );
      }
    }

    await query(
      "UPDATE magang SET status=?, tanggal_mulai=?, tanggal_selesai=?, catatan=? WHERE id=?",
      [status, tanggal_mulai || null, tanggal_selesai || null, catatan || "", params.id]
    );

    // Jika dibatalkan: kembalikan status siswa ke 'aktif'. Memakai helper
    // stopMagang() yang sama dipakai jalur admin (Bug #6) supaya kolom
    // diberhentikan/tanggal_berhenti/alasan_berhenti juga ikut terisi —
    // sebelumnya hanya status & catatan yang terisi dari jalur guru ini,
    // membuat data tidak konsisten dengan jalur admin.
    if (status === "dibatalkan") {
      await stopMagang(params.id, catatan);
      await query("UPDATE siswa SET status='aktif' WHERE id=?", [magang.siswa_id]);
    }

    // Jika selesai: update status siswa + generate nomor sertifikat
    if (status === "selesai") {
      await query("UPDATE siswa SET status='selesai' WHERE id=?", [magang.siswa_id]);

      // Generate nomor sertifikat hanya jika belum punya
      if (!magang.nomor_sertifikat) {
        const nomor = await generateNomorSertifikat();
        await query(
          "UPDATE magang SET nomor_sertifikat=?, sertifikat_generated_at=NOW() WHERE id=?",
          [nomor, params.id]
        );
      }
    }

    await logActivity(
      { id: guru.id, nama: guru.nama, role: "guru" },
      "update",
      status === "dibatalkan"
        ? `${guru.nama} memberhentikan ${siswaNama} dari magang. Alasan: ${catatan}`
        : `${guru.nama} memperbarui status magang ${siswaNama} menjadi ${status}`
    );
  }

  return NextResponse.json({ message: "Berhasil diperbarui" });
}
export const PUT = withErrorHandler(__PUT);

