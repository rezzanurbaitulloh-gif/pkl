import { NextResponse } from "next/server";
import { getCurrentGuru, resolveGuruId } from "@/lib/auth";
import { query } from "@/lib/db";
import { withErrorHandler } from "@/lib/apiHandler";

async function __GET() {
  const guru = await getCurrentGuru();
  if (!guru) return NextResponse.json({ message: "Unauthorized" }, { status: 401 });
  const guruId = await resolveGuruId(guru);
  if (!guruId) return NextResponse.json([]);
  const rows = await query(
    `SELECT m.*, s.nama as siswa_nama, d.nama as dudi_nama
     FROM magang m LEFT JOIN siswa s ON s.id=m.siswa_id LEFT JOIN dudi d ON d.id=m.dudi_id
     WHERE m.guru_id=? ORDER BY m.id DESC`,
    [guruId]
  );
  return NextResponse.json(rows);
}
export const GET = withErrorHandler(__GET);

