import { NextResponse } from "next/server";
import { getCurrentSiswa } from "@/lib/auth";
import { query } from "@/lib/db";
import { withErrorHandler } from "@/lib/apiHandler";

async function __GET() {
  const siswa = await getCurrentSiswa();
  if (!siswa) {
    return NextResponse.json({ message: "Unauthorized" }, { status: 401 });
  }

  const rows = await query(
    `SELECT id, nip, nama, mapel, email FROM guru WHERE status = 'aktif' ORDER BY nama ASC`
  );

  return NextResponse.json({ data: rows });
}
export const GET = withErrorHandler(__GET);

