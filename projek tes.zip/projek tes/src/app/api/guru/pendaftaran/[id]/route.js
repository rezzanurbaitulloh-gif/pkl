import { NextResponse } from "next/server";
import { getCurrentGuru, resolveGuruId } from "@/lib/auth";
import { query } from "@/lib/db";
import { logActivity } from "@/lib/activityLog";
import { withErrorHandler } from "@/lib/apiHandler";
import { createNotification } from "@/lib/notification";

async function __PUT(req, { params }) {
  const guru = await getCurrentGuru();
  if (!guru) return NextResponse.json({ message: "Unauthorized" }, { status: 401 });

  const guruId = await resolveGuruId(guru);
  if (!guruId) return NextResponse.json({ message: "Data guru tidak ditemukan" }, { status: 404 });

  const body = await req.json();
  const { status, tanggal_mulai, tanggal_selesai, catatan } = body;

  if (!["diterima", "ditolak"].includes(status)) {
    return NextResponse.json({ message: "Status tidak valid" }, { status: 400 });
  }

  // Perbaikan Bug #5: catatan WAJIB diisi saat menolak
  if (status === "ditolak" && (!catatan || !catatan.trim())) {
    return NextResponse.json(
      { message: "Catatan/alasan penolakan wajib diisi agar siswa mengetahui alasan sebenarnya." },
      { status: 400 }
    );
  }

  const rows = await query(
    "SELECT * FROM pendaftaran WHERE id = ? AND guru_id = ?",
    [params.id, guruId]
  );
  const pendaftaran = rows[0];
  if (!pendaftaran) {
    return NextResponse.json({ message: "Pendaftaran tidak ditemukan" }, { status: 404 });
  }
  if (pendaftaran.status !== "pending") {
    return NextResponse.json({ message: "Pendaftaran ini sudah ditinjau sebelumnya" }, { status: 400 });
  }

  if (status === "ditolak") {
    await query("UPDATE pendaftaran SET status = ?, catatan = ? WHERE id = ?", [status, catatan.trim(), params.id]);
  } else {
    await query("UPDATE pendaftaran SET status = ? WHERE id = ?", [status, params.id]);
  }

  if (status === "diterima") {
    await query(
      `INSERT INTO magang (siswa_id, dudi_id, guru_id, status, tanggal_mulai, tanggal_selesai, catatan)
       VALUES (?, ?, ?, 'aktif', ?, ?, ?)`,
      [
        pendaftaran.siswa_id,
        pendaftaran.dudi_id,
        guruId,
        tanggal_mulai || null,
        tanggal_selesai || null,
        catatan || "",
      ]
    );
    await query("UPDATE siswa SET status='magang' WHERE id = ?", [pendaftaran.siswa_id]);
    await query(
      `UPDATE pendaftaran
       SET status='ditolak',
           catatan='Otomatis dibatalkan karena siswa telah diterima di tempat magang lain.'
       WHERE siswa_id = ? AND id != ? AND status='pending'`,
      [pendaftaran.siswa_id, params.id]
    );
  }

  // Ambil nama siswa, DUDI, dan user_id siswa untuk log & notifikasi
  const detail = await query(
    `SELECT s.nama as siswa_nama, s.user_id as siswa_user_id, d.nama as dudi_nama
     FROM pendaftaran p
     LEFT JOIN siswa s ON s.id = p.siswa_id
     LEFT JOIN dudi d ON d.id = p.dudi_id
     WHERE p.id = ?`,
    [params.id]
  );
  const siswaNama = detail[0]?.siswa_nama || "siswa";
  const dudiNama = detail[0]?.dudi_nama || "DUDI";
  const siswaUserId = detail[0]?.siswa_user_id;

  await logActivity(
    { id: guru.id, nama: guru.nama, role: "guru" },
    status === "diterima" ? "approve" : "reject",
    status === "diterima"
      ? `${guru.nama} menerima pendaftaran magang ${siswaNama} ke ${dudiNama}`
      : `${guru.nama} menolak pendaftaran magang ${siswaNama} ke ${dudiNama}`
  );

  // Kirim notifikasi ke siswa
  if (siswaUserId) {
    if (status === "diterima") {
      await createNotification(
        siswaUserId,
        "Pendaftaran Magang Diterima 🎉",
        `Selamat! Pendaftaran magang kamu ke ${dudiNama} telah diterima oleh guru pembimbing. Kamu kini resmi terdaftar sebagai peserta magang.`,
        "/siswa/magang"
      );
    } else {
      await createNotification(
        siswaUserId,
        "Pendaftaran Magang Ditolak",
        `Pendaftaran magang kamu ke ${dudiNama} ditolak oleh guru pembimbing. Alasan: ${catatan.trim()}`,
        "/siswa/magang"
      );
    }
  }

  return NextResponse.json({
    message:
      status === "diterima"
        ? "Pendaftaran diterima dan magang berhasil dibuat. Pendaftaran ke tempat lain otomatis dibatalkan."
        : "Pendaftaran ditolak",
  });
}
export const PUT = withErrorHandler(__PUT);
