import { NextResponse } from "next/server";
import { getCurrentGuru, resolveGuruId } from "@/lib/auth";
import { query } from "@/lib/db";
import { withErrorHandler } from "@/lib/apiHandler";

async function __GET() {
  const guru = await getCurrentGuru();
  if (!guru) return NextResponse.json({ message: "Unauthorized" }, { status: 401 });

  const guruId = await resolveGuruId(guru);
  if (!guruId) return NextResponse.json([]);

  const rows = await query(
    `SELECT p.*, s.nama as siswa_nama, s.nis as siswa_nis, s.kelas as siswa_kelas, s.jurusan as siswa_jurusan,
            d.nama as dudi_nama, d.alamat as dudi_alamat, d.telepon as dudi_telepon
     FROM pendaftaran p
     LEFT JOIN siswa s ON s.id = p.siswa_id
     LEFT JOIN dudi d ON d.id = p.dudi_id
     WHERE p.guru_id = ?
     ORDER BY p.status='pending' DESC, p.id DESC`,
    [guruId]
  );

  return NextResponse.json(rows, { headers: { "Cache-Control": "no-store" } });
}
export const GET = withErrorHandler(__GET);

