import { NextResponse } from "next/server";
import { getCurrentGuru, resolveGuruId } from "@/lib/auth";
import { query } from "@/lib/db";
import { withErrorHandler } from "@/lib/apiHandler";

async function __GET() {
  const guru = await getCurrentGuru();
  if (!guru) return NextResponse.json({ message: "Unauthorized" }, { status: 401 });

  const guruId = await resolveGuruId(guru);
  if (!guruId) return NextResponse.json({ magang:[], jurnal:[], stats:{} });

  const magang = await query(
    `SELECT m.*, s.nama as siswa_nama, d.nama as dudi_nama
     FROM magang m LEFT JOIN siswa s ON s.id=m.siswa_id LEFT JOIN dudi d ON d.id=m.dudi_id
     WHERE m.guru_id=? ORDER BY m.id DESC`,
    [guruId]
  );

  // Konsisten dengan perbaikan Bug #3 di GET /api/guru/jurnal: jurnal yang
  // ditampilkan di ringkasan/statistik hanya milik siswa yang SEDANG aktif
  // dibimbing guru ini, bukan seluruh riwayat siswa yang pernah ditangani.
  const siswaIdsAktif = magang.filter(m => m.status === "aktif").map(m => m.siswa_id);
  let jurnal = [];
  if (siswaIdsAktif.length > 0) {
    jurnal = await query(
      `SELECT j.*, s.nama as siswa_nama, s.nis as siswa_nis FROM jurnal j
       LEFT JOIN siswa s ON s.id=j.siswa_id
       WHERE j.siswa_id IN (${siswaIdsAktif.map(()=>"?").join(",")})
       ORDER BY j.tanggal DESC, j.id DESC LIMIT 10`,
      siswaIdsAktif
    );
  }

  return NextResponse.json({ magang, jurnal, guruId,
    stats: {
      total: magang.length,
      aktif: magang.filter(m=>m.status==="aktif").length,
      jurnal_hari_ini: jurnal.filter(j=>j.tanggal===new Date().toISOString().split("T")[0]).length,
    }
  });
}
export const GET = withErrorHandler(__GET);

