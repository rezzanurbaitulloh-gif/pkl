import { NextResponse } from "next/server";
import { getCurrentGuru, resolveGuruId } from "@/lib/auth";
import { query } from "@/lib/db";
import { logActivity } from "@/lib/activityLog";
import { withErrorHandler } from "@/lib/apiHandler";
import { createNotification } from "@/lib/notification";

async function __PUT(req, { params }) {
  const guru = await getCurrentGuru();
  if (!guru) return NextResponse.json({ message: "Unauthorized" }, { status: 401 });

  // Perbaikan Bug #3 (IDOR): hanya bisa ubah jurnal siswa bimbingan sendiri
  const guruId = await resolveGuruId(guru);
  if (!guruId) return NextResponse.json({ message: "Data guru tidak ditemukan" }, { status: 404 });

  const body = await req.json();
  const { status, catatan_guru } = body;

  const jurnalRows = await query(
    `SELECT j.id, j.siswa_id, j.tanggal, s.nama as siswa_nama, s.user_id as siswa_user_id
     FROM jurnal j
     LEFT JOIN siswa s ON s.id = j.siswa_id
     WHERE j.id = ?
       AND j.siswa_id IN (
         SELECT siswa_id FROM magang WHERE guru_id = ? AND status = 'aktif'
       )`,
    [params.id, guruId]
  );
  const jurnal = jurnalRows[0];
  if (!jurnal) {
    return NextResponse.json(
      { message: "Jurnal tidak ditemukan atau bukan milik siswa bimbingan Anda." },
      { status: 404 }
    );
  }

  await query("UPDATE jurnal SET status=?, catatan_guru=? WHERE id=?", [status, catatan_guru || "", params.id]);

  await logActivity(
    { id: guru.id, nama: guru.nama, role: "guru" },
    status === "disetujui" ? "approve" : status === "ditolak" ? "reject" : "update",
    `${guru.nama} ${status === "disetujui" ? "menyetujui" : status === "ditolak" ? "menolak" : "memperbarui"} jurnal ${jurnal.siswa_nama || "siswa"} tanggal ${jurnal.tanggal || "-"}`
  );

  // Kirim notifikasi ke siswa
  if (jurnal.siswa_user_id && (status === "disetujui" || status === "ditolak")) {
    const tglFormatted = jurnal.tanggal
      ? new Date(jurnal.tanggal).toLocaleDateString("id-ID", { day: "numeric", month: "long", year: "numeric" })
      : "-";

    if (status === "disetujui") {
      await createNotification(
        jurnal.siswa_user_id,
        "Jurnal Harian Disetujui ✅",
        `Jurnal harian kamu tanggal ${tglFormatted} telah disetujui oleh guru pembimbing.${catatan_guru ? " Catatan: " + catatan_guru : ""}`,
        "/siswa/jurnal"
      );
    } else {
      await createNotification(
        jurnal.siswa_user_id,
        "Jurnal Harian Ditolak",
        `Jurnal harian kamu tanggal ${tglFormatted} ditolak oleh guru pembimbing. Silakan perbaiki dan kirim ulang.${catatan_guru ? " Catatan: " + catatan_guru : ""}`,
        "/siswa/jurnal"
      );
    }
  }

  return NextResponse.json({ message: "Berhasil diperbarui" });
}
export const PUT = withErrorHandler(__PUT);
