import { NextResponse } from "next/server";
import { getCurrentGuru, resolveGuruId } from "@/lib/auth";
import { query } from "@/lib/db";
import { withErrorHandler } from "@/lib/apiHandler";

async function __GET() {
  const guru = await getCurrentGuru();
  if (!guru) return NextResponse.json({ message: "Unauthorized" }, { status: 401 });

  const guruId = await resolveGuruId(guru);
  if (!guruId) return NextResponse.json([]);

  // Perbaikan Bug #3 (tambahan): sebelumnya daftar siswa diambil dari
  // SELURUH riwayat tabel magang milik guru ini tanpa filter status, jadi
  // kalau siswa pernah dibimbing guru A lalu pindah ke guru B (mis. magang
  // lama 'dibatalkan'/'selesai' dan ada magang baru 'aktif' dengan guru
  // lain), guru A tetap bisa melihat jurnal terbaru siswa itu walau sudah
  // dibimbing guru lain. Sekarang hanya magang berstatus 'aktif' yang
  // dipakai sebagai dasar kepemilikan siswa bimbingan.
  const magang = await query("SELECT siswa_id FROM magang WHERE guru_id=? AND status='aktif'", [guruId]);
  const siswaIds = magang.map(m=>m.siswa_id);
  if (!siswaIds.length) return NextResponse.json([]);
  const rows = await query(
    `SELECT j.*, s.nama as siswa_nama, s.nis as siswa_nis
     FROM jurnal j LEFT JOIN siswa s ON s.id=j.siswa_id
     WHERE j.siswa_id IN (${siswaIds.map(()=>"?").join(",")})
     ORDER BY j.tanggal DESC, j.id DESC`,
    siswaIds
  );
  return NextResponse.json(rows);
}
export const GET = withErrorHandler(__GET);

