import { NextResponse } from "next/server";
import { getCurrentSiswa } from "@/lib/auth";
import { query } from "@/lib/db";
import { withErrorHandler } from "@/lib/apiHandler";

async function __GET() {
  const siswa = await getCurrentSiswa();
  if (!siswa) {
    return NextResponse.json({ message: "Unauthorized" }, { status: 401 });
  }

  // Ambil semua data magang siswa ini, order by id DESC
  const magangRows = await query(
    `SELECT m.*, d.nama as dudi_nama, d.alamat as dudi_alamat, g.nama as guru_nama, g.mapel as guru_mapel
     FROM magang m
     LEFT JOIN dudi d ON d.id = m.dudi_id
     LEFT JOIN guru g ON g.id = m.guru_id
     WHERE m.siswa_id = ? ORDER BY m.id DESC`,
    [siswa.id]
  );

  // Magang aktif — yang paling baru
  const magang =
    magangRows.find((m) => m.status === "aktif") ||
    magangRows.find((m) => m.status === "selesai") ||
    null;

  // Magang yang pernah dibatalkan sebelum selesai (untuk banner daftar ulang)
  const hasActiveMagang = magangRows.some((m) => m.status === "aktif");
  const dismissedMagang = !hasActiveMagang
    ? magangRows.find((m) => m.status === "dibatalkan") || null
    : null;

  // Cek apakah template sertifikat sudah diatur admin
  const settingsRows = await query(
    "SELECT sertifikat_template FROM school_settings WHERE id = 1"
  );
  const hasSertifikatTemplate = !!(settingsRows[0]?.sertifikat_template);

  // Semua riwayat magang (termasuk yang dibatalkan) untuk ditampilkan di riwayat
  const riwayatMagang = magangRows;

  const pendaftaranRows = await query(
    `SELECT p.*, d.nama as dudi_nama, d.alamat as dudi_alamat, d.telepon as dudi_telepon, g.nama as guru_nama
     FROM pendaftaran p
     LEFT JOIN dudi d ON d.id = p.dudi_id
     LEFT JOIN guru g ON g.id = p.guru_id
     WHERE p.siswa_id = ?
     ORDER BY p.id DESC`,
    [siswa.id]
  );

  // Perbaikan Bug #5 (lanjutan): sebelumnya logic ini MENEBAK bahwa setiap
  // pendaftaran berstatus "ditolak" tanpa catatan pasti karena auto-reject
  // (siswa diterima di tempat lain) — padahal sejak perbaikan di atas,
  // guru WAJIB mengisi catatan saat menolak manual. Untuk data lama yang
  // memang masih kosong, pesan generik di bawah ini hanya dipakai sebagai
  // fallback (bukan diklaim sebagai kepastian alasan), supaya tidak ada
  // pendaftaran yang tampil tanpa keterangan sama sekali.
  const AUTO_REJECT_NOTE = "Otomatis dibatalkan karena siswa telah diterima di tempat magang lain.";
  const pendaftaranWithNote = pendaftaranRows.map((p) => {
    if (p.status === "ditolak" && !p.catatan) {
      return {
        ...p,
        alasan_pembatalan:
          "Pendaftaran ini ditolak. Hubungi guru pembimbing untuk informasi lebih lanjut mengenai alasannya.",
      };
    }
    if (p.status === "ditolak" && p.catatan === AUTO_REJECT_NOTE) {
      return { ...p, alasan_pembatalan: AUTO_REJECT_NOTE };
    }
    return p;
  });

  const pendingCount = pendaftaranRows.filter((p) => p.status === "pending").length;

  return NextResponse.json({
    siswa: { nis: siswa.nis, nama: siswa.nama, kelas: siswa.kelas, jurusan: siswa.jurusan },
    magang,
    dismissedMagang,
    riwayatMagang,
    pendaftaran: pendaftaranWithNote,
    pendingCount,
    maxPending: 3,
    hasSertifikatTemplate,
  });
}
export const GET = withErrorHandler(__GET);

