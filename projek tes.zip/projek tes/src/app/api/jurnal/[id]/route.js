import { NextResponse } from "next/server";
import { getCurrentSiswa } from "@/lib/auth";
import { query } from "@/lib/db";
import { withErrorHandler } from "@/lib/apiHandler";

async function __GET(request, { params }) {
  const siswa = await getCurrentSiswa();
  if (!siswa) {
    return NextResponse.json({ message: "Unauthorized" }, { status: 401 });
  }

  const rows = await query(
    "SELECT * FROM jurnal WHERE id = ? AND siswa_id = ?",
    [params.id, siswa.id]
  );

  if (!rows[0]) {
    return NextResponse.json({ message: "Jurnal tidak ditemukan." }, { status: 404 });
  }

  return NextResponse.json({ data: rows[0] });
}
export const GET = withErrorHandler(__GET);

