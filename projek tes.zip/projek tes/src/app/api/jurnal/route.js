import { NextResponse } from "next/server";
import { writeFile, mkdir } from "fs/promises";
import path from "path";
import { getCurrentSiswa } from "@/lib/auth";
import { query } from "@/lib/db";
import { logActivity } from "@/lib/activityLog";
import { withErrorHandler } from "@/lib/apiHandler";
import { createNotification } from "@/lib/notification";

const UPLOAD_DIR = path.join(process.cwd(), "public", "uploads");
const ALLOWED_TYPES = ["application/pdf", "application/msword",
  "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
  "image/jpeg", "image/png", "image/jpg"];
const MAX_SIZE = 5 * 1024 * 1024; // 5MB

async function __GET(request) {
  const siswa = await getCurrentSiswa();
  if (!siswa) {
    return NextResponse.json({ message: "Unauthorized" }, { status: 401 });
  }

  const { searchParams } = new URL(request.url);
  const search = searchParams.get("search") || "";
  const status = searchParams.get("status") || "";
  const limit = parseInt(searchParams.get("limit") || "10", 10);
  const page = parseInt(searchParams.get("page") || "1", 10);
  const offset = (page - 1) * limit;

  let where = "WHERE siswa_id = ?";
  const params = [siswa.id];

  if (search) {
    where += " AND (kegiatan LIKE ? OR kendala LIKE ?)";
    params.push(`%${search}%`, `%${search}%`);
  }
  if (status) {
    where += " AND status = ?";
    params.push(status);
  }

  const rows = await query(
    `SELECT * FROM jurnal ${where} ORDER BY tanggal DESC, id DESC LIMIT ? OFFSET ?`,
    [...params, limit, offset]
  );

  const countRows = await query(
    `SELECT COUNT(*) as total FROM jurnal ${where}`,
    params
  );

  const statRows = await query(
    `SELECT
      COUNT(*) as total,
      SUM(status = 'disetujui') as disetujui,
      SUM(status = 'menunggu') as menunggu,
      SUM(status = 'ditolak') as ditolak
     FROM jurnal WHERE siswa_id = ?`,
    [siswa.id]
  );

  return NextResponse.json({
    data: rows,
    total: countRows[0]?.total || 0,
    page,
    limit,
    stats: {
      total: Number(statRows[0]?.total) || 0,
      disetujui: Number(statRows[0]?.disetujui) || 0,
      menunggu: Number(statRows[0]?.menunggu) || 0,
      ditolak: Number(statRows[0]?.ditolak) || 0,
    },
  });
}
export const GET = withErrorHandler(__GET);


async function __POST(request) {
  const siswa = await getCurrentSiswa();
  if (!siswa) {
    return NextResponse.json({ message: "Unauthorized" }, { status: 401 });
  }

  const formData = await request.formData();
  const tanggal = formData.get("tanggal");
  const kegiatan = (formData.get("kegiatan") || "").toString().trim();
  const kendala = (formData.get("kendala") || "").toString().trim();
  const file = formData.get("file");

  if (!tanggal) {
    return NextResponse.json({ message: "Tanggal wajib diisi." }, { status: 400 });
  }
  if (kegiatan.length < 50) {
    return NextResponse.json(
      { message: "Deskripsi kegiatan minimal 50 karakter." },
      { status: 400 }
    );
  }

  // Ambil guru pembimbing dari data magang aktif siswa
  const magangRows = await query(
    `SELECT guru_id, status FROM magang WHERE siswa_id = ? AND status='aktif' ORDER BY id DESC LIMIT 1`,
    [siswa.id]
  );
  if (magangRows.length === 0) {
    return NextResponse.json(
      { message: "Anda belum terdaftar pada tempat magang yang disetujui. Silakan daftarkan diri ke DUDI dan tunggu persetujuan guru pembimbing sebelum mengisi jurnal." },
      { status: 403 }
    );
  }
  const guruId = magangRows[0]?.guru_id || null;

  let filePath = null;
  let fileName = null;

  if (file && typeof file === "object" && file.size > 0) {
    if (!ALLOWED_TYPES.includes(file.type)) {
      return NextResponse.json(
        { message: "Tipe file tidak didukung. Gunakan PDF, DOC, DOCX, JPG, atau PNG." },
        { status: 400 }
      );
    }
    if (file.size > MAX_SIZE) {
      return NextResponse.json(
        { message: "Ukuran file maksimal 5MB." },
        { status: 400 }
      );
    }

    await mkdir(UPLOAD_DIR, { recursive: true });
    const ext = path.extname(file.name);
    const uniqueName = `${Date.now()}-${Math.round(Math.random() * 1e9)}${ext}`;
    const buffer = Buffer.from(await file.arrayBuffer());
    await writeFile(path.join(UPLOAD_DIR, uniqueName), buffer);

    filePath = `/uploads/${uniqueName}`;
    fileName = file.name;
  }

  const result = await query(
    `INSERT INTO jurnal (siswa_id, guru_id, tanggal, kegiatan, kendala, file_path, file_name, status)
     VALUES (?, ?, ?, ?, ?, ?, ?, 'menunggu')`,
    [siswa.id, guruId, tanggal, kegiatan, kendala || null, filePath, fileName]
  );

  const inserted = await query("SELECT * FROM jurnal WHERE id = ?", [result.insertId]);

  await logActivity(
    { id: siswa.id, nama: siswa.nama, role: "siswa" },
    "create",
    `${siswa.nama} menambahkan jurnal harian tanggal ${tanggal}`
  );

  // Kirim notifikasi ke guru pembimbing jika ada
  if (guruId) {
    const guruUserRows = await query(
      "SELECT user_id FROM guru WHERE id = ?",
      [guruId]
    );
    const guruUserId = guruUserRows[0]?.user_id;
    if (guruUserId) {
      const tglFormatted = tanggal
        ? new Date(tanggal).toLocaleDateString("id-ID", { day: "numeric", month: "long", year: "numeric" })
        : tanggal;
      await createNotification(
        guruUserId,
        "Jurnal Baru dari Siswa 📋",
        `${siswa.nama} telah mengisi jurnal harian tanggal ${tglFormatted}. Silakan tinjau dan berikan penilaian.`,
        "/guru/jurnal"
      );
    }
  }

  return NextResponse.json({ message: "Jurnal berhasil disimpan.", data: inserted[0] }, { status: 201 });
}
export const POST = withErrorHandler(__POST);

