export default function Badge({ status }) {
  const map = {
    aktif: "badge-aktif", magang: "badge-magang", selesai: "badge-selesai",
    menunggu: "badge-menunggu", disetujui: "badge-disetujui", ditolak: "badge-ditolak",
    dibatalkan: "badge-dibatalkan", admin: "badge-admin", guru: "badge-guru", siswa: "badge-siswa",
    pending: "badge-menunggu", diterima: "badge-disetujui",
  };
  const labels = {
    aktif: "Aktif", magang: "Magang", selesai: "Selesai", menunggu: "Menunggu",
    disetujui: "Disetujui", ditolak: "Ditolak", dibatalkan: "Dibatalkan",
    admin: "Admin", guru: "Guru", siswa: "Siswa", pending: "Menunggu Konfirmasi",
    diterima: "Diterima",
  };
  return <span className={`badge ${map[status] || "badge-aktif"}`}>{labels[status] || status}</span>;
}
