"use client";

import { useState, useEffect, useRef, useCallback } from "react";
import { Bell } from "lucide-react";

const POLL_INTERVAL = 30_000; // polling tiap 30 detik

/**
 * Ikon lonceng dengan badge unread count + dropdown daftar notifikasi.
 * Dipakai oleh Topbar, GuruTopbar, dan AdminTopbar.
 */
export default function NotificationBell() {
  const [unreadCount, setUnreadCount] = useState(0);
  const [notifs, setNotifs] = useState([]);
  const [open, setOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  const dropdownRef = useRef(null);

  // ── Fetch badge count (ringan, tidak buka dropdown) ────────────────────
  const fetchUnreadCount = useCallback(async () => {
    try {
      const res = await fetch("/api/notifications?limit=1&unread_only=true");
      if (!res.ok) return;
      const data = await res.json();
      setUnreadCount(data.unread_count || 0);
    } catch {
      // abaikan error jaringan
    }
  }, []);

  // ── Fetch daftar notifikasi (saat dropdown dibuka) ─────────────────────
  const fetchNotifs = useCallback(async () => {
    setLoading(true);
    try {
      const res = await fetch("/api/notifications?limit=20");
      if (!res.ok) return;
      const data = await res.json();
      setNotifs(data.data || []);
      setUnreadCount(data.unread_count || 0);
    } catch {
      // abaikan
    } finally {
      setLoading(false);
    }
  }, []);

  // ── Polling badge saat komponen mount ──────────────────────────────────
  useEffect(() => {
    fetchUnreadCount();
    const timer = setInterval(fetchUnreadCount, POLL_INTERVAL);
    return () => clearInterval(timer);
  }, [fetchUnreadCount]);

  // ── Tutup dropdown klik di luar ────────────────────────────────────────
  useEffect(() => {
    if (!open) return;
    function handleClick(e) {
      if (dropdownRef.current && !dropdownRef.current.contains(e.target)) {
        setOpen(false);
      }
    }
    document.addEventListener("mousedown", handleClick);
    return () => document.removeEventListener("mousedown", handleClick);
  }, [open]);

  // ── Toggle dropdown ────────────────────────────────────────────────────
  function toggleOpen() {
    if (!open) fetchNotifs();
    setOpen((v) => !v);
  }

  // ── Tandai satu notifikasi dibaca ──────────────────────────────────────
  async function markRead(id) {
    setNotifs((prev) =>
      prev.map((n) => (n.id === id ? { ...n, dibaca: true } : n))
    );
    setUnreadCount((c) => Math.max(0, c - 1));
    await fetch("/api/notifications", {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ id }),
    });
  }

  // ── Tandai semua dibaca ────────────────────────────────────────────────
  async function markAllRead() {
    setNotifs((prev) => prev.map((n) => ({ ...n, dibaca: true })));
    setUnreadCount(0);
    await fetch("/api/notifications", {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ all: true }),
    });
  }

  // ── Klik notifikasi: tandai dibaca lalu navigasi ───────────────────────
  function handleNotifClick(notif) {
    if (!notif.dibaca) markRead(notif.id);
    if (notif.link) window.location.href = notif.link;
    setOpen(false);
  }

  // ── Format tanggal relative ────────────────────────────────────────────
  function relativeTime(dateStr) {
    const diff = Date.now() - new Date(dateStr).getTime();
    const mins = Math.floor(diff / 60000);
    if (mins < 1) return "Baru saja";
    if (mins < 60) return `${mins} menit lalu`;
    const hours = Math.floor(mins / 60);
    if (hours < 24) return `${hours} jam lalu`;
    const days = Math.floor(hours / 24);
    if (days < 7) return `${days} hari lalu`;
    return new Date(dateStr).toLocaleDateString("id-ID", { day: "numeric", month: "short" });
  }

  return (
    <div className="notif-wrapper" ref={dropdownRef} style={{ position: "relative" }}>
      {/* ── Tombol lonceng ── */}
      <button
        className="notif-btn"
        onClick={toggleOpen}
        title="Notifikasi"
        aria-label={`Notifikasi${unreadCount > 0 ? `, ${unreadCount} belum dibaca` : ""}`}
        style={{ position: "relative" }}
      >
        <Bell size={20} />
        {unreadCount > 0 && (
          <span className="notif-badge">
            {unreadCount > 99 ? "99+" : unreadCount}
          </span>
        )}
      </button>

      {/* ── Dropdown ── */}
      {open && (
        <div className="notif-dropdown">
          <div className="notif-dropdown-header">
            <span className="notif-dropdown-title">Notifikasi</span>
            {unreadCount > 0 && (
              <button className="notif-markall-btn" onClick={markAllRead}>
                Tandai semua dibaca
              </button>
            )}
          </div>

          <div className="notif-list">
            {loading ? (
              <div className="notif-empty">Memuat…</div>
            ) : notifs.length === 0 ? (
              <div className="notif-empty">Tidak ada notifikasi</div>
            ) : (
              notifs.map((n) => (
                <button
                  key={n.id}
                  className={`notif-item${n.dibaca ? "" : " notif-item--unread"}`}
                  onClick={() => handleNotifClick(n)}
                >
                  {!n.dibaca && <span className="notif-dot" />}
                  <div className="notif-item-body">
                    <div className="notif-item-judul">{n.judul}</div>
                    <div className="notif-item-pesan">{n.pesan}</div>
                    <div className="notif-item-time">{relativeTime(n.created_at)}</div>
                  </div>
                </button>
              ))
            )}
          </div>
        </div>
      )}
    </div>
  );
}
