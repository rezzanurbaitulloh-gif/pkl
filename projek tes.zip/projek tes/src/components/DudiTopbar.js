"use client";

import { useRouter } from "next/navigation";
import { getInitials } from "@/lib/utils";
import { useSchoolInfo } from "@/lib/useSchoolInfo";

export default function DudiTopbar({ schoolName, user, onMenuToggle }) {
  const router = useRouter();
  // schoolName sudah berasal dari database (dikirim dari layout.js server
  // component), dipakai sebagai initial agar tidak ada flash nama yang
  // salah sebelum useSchoolInfo() selesai fetch ulang dari /api/settings.
  const school = useSchoolInfo(schoolName ? { nama: schoolName } : null);
  const displayName = school?.nama || schoolName;
  const logoUrl = school?.logo_url;

  const handleLogout = async () => {
    await fetch("/api/auth/logout", { method: "POST" });
    router.push("/login");
    router.refresh();
  };

  return (
    <div className="topbar">
      <div className="topbar-left">
        <button className="hamburger-btn" onClick={onMenuToggle} aria-label="Buka menu">
          <span></span>
          <span></span>
          <span></span>
        </button>
        {logoUrl && <img src={logoUrl} alt="Logo Sekolah" className="topbar-left-img" />}
        <div className="topbar-left-text">
          <span className="school-name">{displayName}</span>
          <span className="school-sub">Sistem Manajemen Magang Siswa</span>
        </div>
      </div>
      <div className="topbar-right">
        <div className="user-info">
          <div className="user-avatar">{getInitials(user.nama)}</div>
          <div className="user-details">
            <span>{user.nama}</span>
            <small>Mitra DUDI</small>
          </div>
        </div>
        <button className="logout-btn" onClick={handleLogout}>Keluar</button>
      </div>
    </div>
  );
}
