"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useSchoolInfo } from "@/lib/useSchoolInfo";
import { LayoutDashboard, Briefcase, ClipboardList } from "lucide-react";

const navItems = [
  { href: "/guru/dashboard", icon: LayoutDashboard, label: "Dashboard", sub: "Ringkasan aktivitas" },
  { href: "/guru/magang", icon: Briefcase, label: "Magang", sub: "Kelola magang siswa" },
  { href: "/guru/jurnal", icon: ClipboardList, label: "Approval Jurnal", sub: "Review jurnal harian" },
];

export default function GuruSidebar({ schoolName, isOpen, onClose }) {
  const pathname = usePathname();
  const school = useSchoolInfo(schoolName ? { nama: schoolName } : null);
  const displayName = school?.nama || schoolName;
  const logoUrl = school?.logo_url;

  return (
    <>
      {isOpen && (
        <div className="sidebar-overlay" onClick={onClose} />
      )}
      <div className={`sidebar ${isOpen ? "sidebar-open" : ""}`}>
        <div className="sidebar-logo">
          <h1>SIMMAS</h1>
          <p>Portal Guru</p>
        </div>
        <div className="sidebar-school">
          {logoUrl && <img src={logoUrl} alt="Logo Sekolah" className="sidebar-school-img" />}
          <div className="sidebar-school-text">
            <strong>{displayName}</strong>
            <p>Sistem Manajemen Magang Siswa</p>
          </div>
        </div>
        <nav className="sidebar-nav">
          {navItems.map((item) => {
            const Icon = item.icon;
            return (
              <Link
                key={item.href}
                href={item.href}
                onClick={onClose}
                className={`nav-item ${pathname?.startsWith(item.href) ? "active" : ""}`}
              >
                <span className="nav-icon"><Icon size={18} /></span>
                <div className="nav-label">
                  <span>{item.label}</span>
                  <small>{item.sub}</small>
                </div>
              </Link>
            );
          })}
        </nav>
        <div className="sidebar-footer">
          UKK SMK Project
          <br />
          Powered by REJAKK
        </div>
      </div>
    </>
  );
}
