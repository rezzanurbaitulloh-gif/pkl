const fs = require("fs");
const path = require("path");
const mysql = require("mysql2/promise");

const envLocal = path.join(__dirname, "..", ".env.local");
const envDefault = path.join(__dirname, "..", ".env");
if (fs.existsSync(envLocal)) {
  require("dotenv").config({ path: envLocal });
} else if (fs.existsSync(envDefault)) {
  require("dotenv").config({ path: envDefault });
} else {
  console.warn("⚠️  File .env.local tidak ditemukan. Menggunakan konfigurasi default.\n");
}

const config = {
  host: process.env.DB_HOST || "localhost",
  port: Number(process.env.DB_PORT) || 3306,
  user: process.env.DB_USER || "root",
  password: process.env.DB_PASSWORD || "",
  multipleStatements: true,
};

async function main() {
  const sqlPath = path.join(__dirname, "schema.sql");
  const sql = fs.readFileSync(sqlPath, "utf8");

  console.log(`Menghubungkan ke MySQL di ${config.host}:${config.port} sebagai "${config.user}" ...`);

  let connection;
  try {
    connection = await mysql.createConnection(config);
  } catch (err) {
    console.error("\n❌ Gagal terhubung ke MySQL server.");
    console.error(`   Pesan error: ${err.message}`);
    process.exit(1);
  }

  try {
    console.log("Menjalankan schema.sql ...");
    await connection.query(sql);
    console.log("✅ Database, tabel, dan data awal berhasil dibuat.\n");
    console.log("Akun demo (semua password: 123):");
    console.log("  Admin  : admin@gmail.com");
    console.log("  Guru   : suryanto@teacher.com | kartika@teacher.com");
    console.log("  Siswa  : ahmad.rizki@student.sch.id | siti.nur@student.sch.id | fajar@student.sch.id");
  } catch (err) {
    console.error("\n❌ Gagal menjalankan schema.sql:");
    console.error(`   ${err.message}`);
    process.exit(1);
  } finally {
    await connection.end();
  }
}

main().catch((err) => {
  console.error("Terjadi kesalahan tidak terduga:", err);
  process.exit(1);
});
