/**
 * Migration: hash ulang semua password di tabel users yang masih berupa
 * teks polos menjadi bcrypt hash. Aman dijalankan berulang kali (idempotent)
 * — password yang sudah berupa bcrypt hash otomatis dilewati.
 *
 * Jalankan dengan:
 *   npm run db:hash-passwords
 */
const fs = require("fs");
const path = require("path");
const mysql = require("mysql2/promise");
const bcrypt = require("bcryptjs");

const envLocal = path.join(__dirname, "..", ".env.local");
const envDefault = path.join(__dirname, "..", ".env");
if (fs.existsSync(envLocal)) {
  require("dotenv").config({ path: envLocal });
} else if (fs.existsSync(envDefault)) {
  require("dotenv").config({ path: envDefault });
} else {
  console.warn("⚠️  File .env.local tidak ditemukan. Menggunakan konfigurasi default.\n");
}

const SALT_ROUNDS = 10;
const BCRYPT_HASH_REGEX = /^\$2[aby]\$\d{2}\$/;

const config = {
  host: process.env.DB_HOST || "localhost",
  port: Number(process.env.DB_PORT) || 3306,
  user: process.env.DB_USER || "root",
  password: process.env.DB_PASSWORD || "",
  database: process.env.DB_NAME || "simmas_db",
};

async function main() {
  console.log(`Menghubungkan ke MySQL di ${config.host}:${config.port}/${config.database} sebagai "${config.user}" ...`);

  let connection;
  try {
    connection = await mysql.createConnection(config);
  } catch (err) {
    console.error("\n❌ Gagal terhubung ke MySQL server.");
    console.error(`   Pesan error: ${err.message}`);
    process.exit(1);
  }

  try {
    const [users] = await connection.query("SELECT id, email, password FROM users");

    let jumlahDihash = 0;
    let jumlahDilewati = 0;

    console.log(`\nMemeriksa ${users.length} pengguna ...`);

    for (const user of users) {
      if (BCRYPT_HASH_REGEX.test(user.password || "")) {
        jumlahDilewati++;
        continue;
      }

      const hashed = await bcrypt.hash(user.password, SALT_ROUNDS);
      await connection.query("UPDATE users SET password = ? WHERE id = ?", [hashed, user.id]);
      jumlahDihash++;
      console.log(`  ✓ Password untuk "${user.email}" berhasil di-hash.`);
    }

    console.log(
      `\n✅ Selesai. ${jumlahDihash} password berhasil di-hash, ${jumlahDilewati} sudah berupa bcrypt hash (dilewati).`
    );
    if (jumlahDihash === 0 && jumlahDilewati === users.length) {
      console.log("   Semua password di tabel users sudah aman (bcrypt hash).");
    }
  } catch (err) {
    console.error("\n❌ Gagal menjalankan migration hash password:");
    console.error(`   ${err.message}`);
    process.exit(1);
  } finally {
    await connection.end();
  }
}

main().catch((err) => {
  console.error("Terjadi kesalahan tidak terduga:", err);
  process.exit(1);
});
