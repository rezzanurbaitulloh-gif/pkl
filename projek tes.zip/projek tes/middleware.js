import { NextResponse } from "next/server";

const SESSION_COOKIE = "simmas_session";

// Decode JWT tanpa verifikasi (hanya untuk routing di edge).
// Verifikasi penuh dilakukan di setiap server component via auth.js.
function decodeJwtPayload(token) {
  try {
    const base64 = token.split(".")[1];
    if (!base64) return null;
    // atob tersedia di Next.js middleware (edge runtime)
    const json = atob(base64.replace(/-/g, "+").replace(/_/g, "/"));
    return JSON.parse(json);
  } catch {
    return null;
  }
}

export async function middleware(request) {
  const { pathname } = request.nextUrl;
  const token = request.cookies.get(SESSION_COOKIE)?.value;

  let payload = null;
  if (token) {
    payload = decodeJwtPayload(token);
    // Cek expiry
    if (payload && payload.exp && payload.exp < Math.floor(Date.now() / 1000)) {
      payload = null;
    }
  }

  // Sudah login tapi buka /login -> redirect sesuai role
  if (pathname === "/login" && payload) {
    let dest = "/siswa/dashboard";
    if (payload.role === "admin") dest = "/admin/dashboard";
    else if (payload.role === "guru") dest = "/guru/dashboard";
    else if (payload.role === "dudi") dest = "/dudi/dashboard";
    return NextResponse.redirect(new URL(dest, request.url));
  }

  // Belum login tapi buka halaman protected -> ke /login
  if (!payload) {
    if (
      pathname.startsWith("/siswa") ||
      pathname.startsWith("/guru") ||
      pathname.startsWith("/admin") ||
      pathname.startsWith("/dudi")
    ) {
      return NextResponse.redirect(new URL("/login", request.url));
    }
    return NextResponse.next();
  }

  // Cegah akses lintas role
  if (pathname.startsWith("/admin") && payload.role !== "admin") {
    const dest =
      payload.role === "guru" ? "/guru/dashboard" :
      payload.role === "dudi" ? "/dudi/dashboard" :
      "/siswa/dashboard";
    return NextResponse.redirect(new URL(dest, request.url));
  }
  if (pathname.startsWith("/guru") && payload.role !== "guru") {
    const dest =
      payload.role === "admin" ? "/admin/dashboard" :
      payload.role === "dudi" ? "/dudi/dashboard" :
      "/siswa/dashboard";
    return NextResponse.redirect(new URL(dest, request.url));
  }
  if (pathname.startsWith("/siswa") && payload.role !== "siswa") {
    const dest =
      payload.role === "admin" ? "/admin/dashboard" :
      payload.role === "guru" ? "/guru/dashboard" :
      "/dudi/dashboard";
    return NextResponse.redirect(new URL(dest, request.url));
  }
  if (pathname.startsWith("/dudi") && payload.role !== "dudi") {
    const dest =
      payload.role === "admin" ? "/admin/dashboard" :
      payload.role === "guru" ? "/guru/dashboard" :
      "/siswa/dashboard";
    return NextResponse.redirect(new URL(dest, request.url));
  }

  return NextResponse.next();
}

export const config = {
  matcher: ["/login", "/siswa/:path*", "/guru/:path*", "/admin/:path*", "/dudi/:path*"],
};
