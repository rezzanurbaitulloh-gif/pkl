# LAPORAN PERBAIKAN SIMMAS — FINAL
**Status: 15 dari 15 bug SELESAI ✅**

Dokumen ini merangkum seluruh perbaikan yang diterapkan pada project SIMMAS,
berdasarkan `LAPORAN_PENGUJIAN_SIMMAS.md` (hasil analisis bug) dan hasil
perbaikan parsial yang sudah Anda kerjakan sebelumnya (`simmas-pkl-progress.zip`).

---

## 🔧 Perbaikan tambahan pasca-pengiriman (ditemukan saat verifikasi user)

**Bug urutan tabel `password_reset_tokens` vs `dudi` (Kritis — mencegah `schema.sql` berjalan sama sekali)**

Saat Bug #10 diperbaiki, kolom `dudi_id` (FK ke tabel `dudi`) ditambahkan ke
`password_reset_tokens`, namun tabel `password_reset_tokens` di `schema.sql`
posisinya **sebelum** tabel `dudi` didefinisikan. Akibatnya `CREATE TABLE`
gagal dengan error MySQL:
```
#1824 - Failed to open the referenced table 'dudi'
```
Ini membuat seluruh proses import schema gagal di tengah jalan (baik lewat
`npm run db:init` maupun lewat phpMyAdmin) — meski phpMyAdmin tetap
melaporkan "Import has been successfully finished, 23 queries executed"
untuk query-query SEBELUM titik kegagalan, sebagian tabel di belakangnya
(`password_reset_tokens` dan seluruh tabel setelahnya: `siswa`, `magang`,
`jurnal`, `pendaftaran`, `sertifikat_config`, beserta seed data-nya) **tidak
pernah benar-benar dibuat**.

**Perbaikan:** blok `CREATE TABLE password_reset_tokens` dipindahkan ke
posisi setelah `CREATE TABLE dudi`, sehingga MySQL bisa membuat foreign key
`dudi_id` dengan benar. Urutan tabel akhir:
`users → activity_logs → school_settings → guru → dudi →
password_reset_tokens → siswa → magang → jurnal → pendaftaran →
sertifikat_config`.

Seluruh foreign key di `schema.sql` sudah diverifikasi ulang secara
terprogram (setiap `REFERENCES tabel(...)` dipastikan merujuk ke tabel
yang sudah dibuat sebelumnya) — tidak ada lagi forward-reference yang
rusak.

**Jika sebelumnya Anda sempat mengimpor `schema.sql` versi lama (yang
errornya seperti screenshot) dan tabel-tabel utama (`siswa`, `magang`, dst.)
ternyata tidak ada — itu wajar, karena import berhenti di tengah jalan.
Solusinya cukup hapus database `simmas_db` lagi lalu import ulang dengan
`schema.sql` di paket ini (sudah diperbaiki).**

---

## ✅ Bug #1 — Error handling (Kritis)
**Status sebelumnya:** Selesai oleh Anda. **Diverifikasi: benar.**
`src/lib/apiHandler.js` (`withErrorHandler`) membungkus seluruh **41/41**
route handler di `src/app/api/**/route.js`. Error MySQL (NIS/NIP/email
duplikat, dll.) sekarang selalu balik sebagai JSON rapi, bukan halaman 500
HTML mentah.

## ✅ Bug #2 — Format sertifikat WEBP (Kritis)
**Status sebelumnya:** Selesai oleh Anda. **Diverifikasi: benar.**
`src/lib/sertifikatTemplate.js` jadi single source of truth daftar format
(PNG/JPG saja). Dipakai konsisten oleh endpoint upload
(`admin/settings/sertifikat`) dan generator PDF (`sertifikat/[id]`).

## ✅ Bug #3 — IDOR (Kritis)
**Status sebelumnya:** Sebagian (hanya `guru/magang/[id]`).
**Saya selesaikan sisanya:**
- `guru/jurnal/[id]/route.js` (PUT) — ditambahkan pengecekan kepemilikan:
  jurnal hanya bisa diubah jika siswa pemiliknya sedang dibimbing **aktif**
  oleh guru yang login (pola disamakan dengan `dudi/magang/[id]` dan
  `guru/pendaftaran/[id]`).
- `GET /api/guru/jurnal` — difilter hanya siswa dari magang berstatus
  `'aktif'` (sebelumnya tanpa filter status, sehingga guru lama tetap bisa
  melihat jurnal siswa yang sudah pindah ke guru lain).
- Dirapikan juga: `guru/stats/route.js` dan `guru/magang/route.js` memakai
  `resolveGuruId()` terpusat dari `src/lib/auth.js` (sebelumnya ada 3
  implementasi lokal duplikat di file berbeda).

## ✅ Bug #4 — Sinkronisasi users ↔ siswa/guru (Tinggi)
**Saya kerjakan dari nol (root cause fix):**
- `database/schema.sql` — tambah kolom `guru.user_id` (FK ke `users.id`).
- `database/migration-guru-user-id.sql` (baru) — migrasi untuk instalasi
  yang sudah ada (best-effort match by email, lalu pasang FK).
- `src/lib/auth.js` (`getCurrentGuru`) — JOIN sekarang via `user_id`
  (bukan `email` lagi), dengan fallback email untuk baris lama yang belum
  dimigrasikan.
- `src/lib/userSync.js` (baru) — helper terpusat:
  - `ensureUserForRole()` — buat/pakai ulang akun `users` saat siswa/guru
    baru dibuat.
  - `syncUserEmail()` — sinkronkan `users.email`/`nama` saat data
    siswa/guru diubah lewat menu admin.
  - `deleteLinkedUser()` — hapus akun `users` terkait saat siswa/guru
    dihapus (sebelumnya akun "yatim" tertinggal selamanya).
- Diterapkan di: `admin/siswa` (POST/PUT/DELETE), `admin/guru`
  (POST/PUT/DELETE), dan **arah sebaliknya** di `admin/pengguna/[id]`
  (PUT) — mengubah email/nama lewat menu Manajemen Pengguna sekarang juga
  menyinkronkan balik ke tabel `siswa`/`guru`.

## ✅ Bug #5 — Catatan wajib saat tolak pendaftaran (Sedang)
**Saya kerjakan:**
- `guru/pendaftaran/[id]/route.js` — backend mewajibkan `catatan` saat
  `status=ditolak` (400 jika kosong), dan benar-benar menyimpannya ke
  kolom `pendaftaran.catatan` (sebelumnya tidak pernah disimpan).
- `guru/magang/page.js` — modal "Tinjau" di frontend: validasi sebelum
  submit + label diperjelas ("wajib diisi jika menolak") + warning visual.
- `api/magang/route.js` — logic pesan auto-reject ke siswa diperjelas,
  tidak lagi menebak alasan semata dari ketiadaan catatan.

## ✅ Bug #6 — Dua jalur berhentikan magang tidak konsisten (Tinggi)
**Status sebelumnya:** Selesai oleh Anda. **Diverifikasi: benar.**
`src/lib/magang.js` (`stopMagang()`) dipakai identik di jalur admin
(`admin/magang/[id]/berhenti`) dan guru (`guru/magang/[id]`).

## ✅ Bug #7 — Validasi nilai magang (Tinggi)
**Status sebelumnya:** Selesai oleh Anda. **Diverifikasi: benar.**
`validateNilai()` di `src/lib/utils.js`, dipakai di `guru/magang/[id]`.

## ✅ Bug #8 — Log aktivitas hilang diam-diam (Sedang)
**Saya kerjakan:**
`src/lib/activityLog.js` — `description` otomatis dipotong (truncate) ke
255 karakter sebelum INSERT (sesuai batas kolom `VARCHAR(255)`), sehingga
INSERT log tidak pernah gagal hanya karena teks terlalu panjang. Jejak
audit tetap tersimpan (meski terpotong) alih-alih hilang total.

## ✅ Bug #9 — Dead code `/api/dashboard` (Sedang)
**Saya kerjakan:** Folder `src/app/api/dashboard/` **dihapus** — dikonfirmasi
tidak ada satupun pemanggilan `fetch("/api/dashboard")` di seluruh
frontend (dashboard siswa sudah query database langsung sebagai server
component, jauh lebih efisien daripada lewat endpoint ini).

## ✅ Bug #10 — Lupa password untuk DUDI (Tinggi)
**Saya kerjakan dari nol:**
- `database/schema.sql` — `password_reset_tokens.user_id` jadi nullable +
  kolom baru `dudi_id` (FK ke `dudi.id`).
- `database/migration-dudi-forgot-password.sql` (baru) — migrasi untuk
  instalasi yang sudah ada.
- `auth/forgot-password/route.js` — cek tabel `users` dulu, lalu
  `dudi.login_email` jika tidak ketemu.
- `auth/reset-password/route.js` — menangani token yang merujuk ke
  `user_id` ATAU `dudi_id`, update `users.password` atau
  `dudi.login_password` sesuai jenis token. Konsisten dengan cara hashing
  yang sama dipakai endpoint `admin/dudi/[id]/akun`.

## ✅ Bug #11 — Reuse email lintas role tanpa cek (Tinggi)
**Saya kerjakan:** Terintegrasi dalam `ensureUserForRole()` (lihat Bug #4)
— sekarang melempar error 409 yang jelas ("Email sudah digunakan oleh akun
dengan peran ...") jika email yang dimasukkan admin sudah dipakai role
lain, bukan diam-diam "menumpang" `user_id` akun lama.

## ✅ Bug #12 — Nama sekolah hardcode (Rendah)
**Saya kerjakan di seluruh lapisan aplikasi:**
- `src/lib/publicSchoolInfo.js` (baru) — helper server-side untuk ambil
  nama sekolah dari `school_settings` **tanpa perlu login** (karena
  `/api/settings` mewajibkan autentikasi, tidak bisa dipakai halaman
  publik).
- Halaman publik (`page.js`/landing, `login/page.js`, `forgot-password`,
  `reset-password`, `panduan`) — diubah jadi server component yang fetch
  nama sekolah dari database lalu kirim sebagai prop ke client component.
- `login/page.js`, `forgot-password/page.js` — sebelumnya client component
  langsung tanpa wrapper server; sekarang dipecah jadi
  `LoginClient.js`/`ForgotPasswordClient.js` + `page.js` server wrapper.
- `admin/layout.js`, `guru/layout.js`, `siswa/layout.js`, `dudi/layout.js`
  — `const SCHOOL_NAME = "SMK Negeri 1 Surabaya"` (hardcode) diganti
  `await getPublicSchoolInfo()`, sehingga render pertama kali (sebelum
  client-side fetch selesai) sudah menampilkan nama yang benar.
- 8 komponen sidebar/topbar (`AdminSidebar`, `AdminTopbar`, `GuruSidebar`,
  `GuruTopbar`, `SiswaSidebar`/`Sidebar`, `SiswaTopbar`/`Topbar`,
  `DudiSidebar`, `DudiTopbar`) — `useSchoolInfo()` sekarang menerima
  `schoolName` sebagai *initial value*, menghilangkan flash nama yang
  salah sesaat sebelum fetch client selesai.
- **Bonus temuan:** `src/app/login/layout.js` adalah sisa boilerplate
  Next.js default (`title: "Next.js"`, nested `<html>/<body>` tidak valid
  di App Router) — **dihapus** karena tidak konsisten dan berpotensi
  menyebabkan HTML nesting error.

## ✅ Bug #13 — Hint email usang di halaman login (Rendah)
**Saya kerjakan:** Teks hint
`"admin: @gmail.com | guru: .teacher@gmail.com | siswa: @student.sch.id"`
(menyiratkan domain dibatasi per role, padahal `isValidEmailForRole()`
sudah generik) diganti dengan keterangan netral dan akurat.

## ✅ Bug #14 — Typo CSS `transpareent` (Rendah)
**Saya kerjakan:** Diperbaiki di kedua lokasi tersisa di `src/app/page.js`
(navbar & footer landing page) menjadi `transparent`.
*(Lokasi di `login/page.js` sudah benar sejak awal — hanya `page.js` landing
yang punya typo ini.)*

## ✅ Bug #15 — Link Panduan Pengguna mati (Rendah)
**Saya kerjakan:** Dibuat halaman **`/panduan`** yang sungguhan berisi:
- Panduan langkah-demi-langkah untuk 4 role (Admin, Guru, Siswa, DUDI).
- FAQ singkat (lupa password, format email, sertifikat, dll).
- Link footer landing page diubah dari `href="#"` menjadi
  `<Link href="/panduan">`.

---

## File baru yang dibuat
- `src/lib/userSync.js`
- `src/lib/publicSchoolInfo.js`
- `src/app/login/LoginClient.js` (dipecah dari `page.js` lama)
- `src/app/login/page.js` (server wrapper baru)
- `src/app/forgot-password/ForgotPasswordClient.js` (dipecah dari `page.js` lama)
- `src/app/forgot-password/page.js` (server wrapper baru)
- `src/app/panduan/page.js`
- `database/migration-guru-user-id.sql`
- `database/migration-dudi-forgot-password.sql`

## File yang dihapus
- `src/app/api/dashboard/` (dead code, Bug #9)
- `src/app/login/layout.js` (boilerplate rusak, ditemukan saat mengerjakan Bug #12)

## File utama yang diubah
`database/schema.sql`, `src/lib/auth.js`, `src/lib/activityLog.js`,
`src/app/layout.js`, `src/app/page.js`,
`src/app/reset-password/page.js`, `src/app/reset-password/ResetPasswordClient.js`,
`src/app/admin/layout.js`, `src/app/guru/layout.js`, `src/app/siswa/layout.js`, `src/app/dudi/layout.js`,
`src/components/{Admin,Guru,Dudi}{Sidebar,Topbar}.js`, `src/components/Sidebar.js`, `src/components/Topbar.js`,
serta seluruh route API yang disebutkan di atas per masing-masing bug.

---

## ⚠️ PENTING — Sebelum menjalankan project

1. **Untuk instalasi BARU (fresh install):**
   ```bash
   npm install
   npm run db:init    # schema.sql sudah termasuk SEMUA perubahan skema
   npm run dev
   ```

2. **Untuk instalasi yang SUDAH ADA datanya (jangan jalankan `db:init` karena akan DROP database):**
   ```bash
   mysql -u root -p simmas_db < database/migration-guru-user-id.sql
   mysql -u root -p simmas_db < database/migration-dudi-forgot-password.sql
   npm install
   npm run dev
   ```

3. **Verifikasi runtime belum dijalankan di sandbox ini** (tidak ada akses
   internet/MySQL di lingkungan kerja saya, sama seperti keterbatasan yang
   disebutkan di laporan pengujian Anda). Seluruh 200+ file `.js` di project
   ini sudah lolos `node --check` (validasi sintaks), tapi **sangat
   disarankan** Anda menjalankan `npm run dev` dan menguji ulang skenario
   di `LAPORAN_PENGUJIAN_SIMMAS.md` satu per satu sebelum deploy ke
   produksi, terutama:
   - Login/reset password untuk akun DUDI (Bug #10) — paling kompleks secara skema.
   - Edit email siswa/guru lalu coba login pakai email baru (Bug #4).
   - Coba buat guru baru dengan email yang sudah dipakai siswa (Bug #11) — harus muncul error 409.
   - Tolak pendaftaran tanpa isi catatan (Bug #5) — harus ditolak validasi.
