-- ============================================================
-- MIGRATION: Tambah kolom user_id pada tabel guru (Perbaikan Bug #4)
-- Jalankan query ini di database simmas_db yang sudah ada
-- (untuk fresh install, kolom ini sudah termasuk di schema.sql)
-- ============================================================
--
-- Latar belakang: sebelumnya src/lib/auth.js (getCurrentGuru) mencocokkan
-- sesi guru ke baris tabel `guru` lewat JOIN guru.email = users.email.
-- Karena email di kedua tabel bisa diubah secara independen lewat menu
-- "Manajemen Guru" ATAU menu "Manajemen Pengguna", kedua nilai itu bisa
-- jadi tidak sinkron — begitu itu terjadi, sesi guru jatuh ke cabang
-- fallback yang membuat guru.id menjadi null, dan seluruh fitur sisi guru
-- yang butuh guru.id (daftar siswa bimbingan, dsb.) menjadi kosong/rusak.
--
-- Migrasi ini menambah relasi eksplisit lewat ID, yang tidak akan pernah
-- desync, lalu mengisi nilainya dari data email yang ada saat ini sebagai
-- upaya terbaik (best-effort) pencocokan satu kali.

USE simmas_db;

ALTER TABLE guru
  ADD COLUMN IF NOT EXISTS user_id INT NULL AFTER id;

-- Best-effort: cocokkan baris guru ke users yang sudah ada berdasarkan email
-- saat ini (hanya untuk guru yang belum punya user_id).
UPDATE guru g
JOIN users u ON u.email = g.email AND u.role = 'guru'
SET g.user_id = u.id
WHERE g.user_id IS NULL;

-- Tambahkan foreign key constraint (aman dijalankan ulang: abaikan jika
-- constraint dengan nama ini sudah ada).
SET @fk_exists = (
  SELECT COUNT(*) FROM information_schema.TABLE_CONSTRAINTS
  WHERE CONSTRAINT_SCHEMA = 'simmas_db'
    AND TABLE_NAME = 'guru'
    AND CONSTRAINT_NAME = 'guru_ibfk_user_id'
);
SET @sql := IF(@fk_exists = 0,
  'ALTER TABLE guru ADD CONSTRAINT guru_ibfk_user_id FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL',
  'SELECT "Constraint guru_ibfk_user_id sudah ada, dilewati."'
);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;
