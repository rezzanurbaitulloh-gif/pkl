-- ============================================================
-- MIGRATION: Portal Login DUDI
-- Jalankan query ini di database simmas_db yang sudah ada
-- (untuk fresh install, kolom ini sudah termasuk di schema.sql)
-- ============================================================

USE simmas_db;

ALTER TABLE dudi
  ADD COLUMN IF NOT EXISTS login_email VARCHAR(150) NULL UNIQUE,
  ADD COLUMN IF NOT EXISTS login_password VARCHAR(255) NULL;

ALTER TABLE magang
  ADD COLUMN IF NOT EXISTS catatan_dudi TEXT NULL,
  ADD COLUMN IF NOT EXISTS nilai_dudi INT NULL;
