-- ============================================================
-- MIGRATION: Dukungan Lupa Password untuk akun DUDI (Perbaikan Bug #10)
-- Jalankan query ini di database simmas_db yang sudah ada
-- (untuk fresh install, kolom ini sudah termasuk di schema.sql)
-- ============================================================
--
-- Latar belakang: akun DUDI login lewat dudi.login_email/login_password,
-- terpisah dari tabel `users`. Tabel password_reset_tokens sebelumnya hanya
-- punya user_id (NOT NULL, FK ke users), sehingga perwakilan perusahaan
-- mitra yang lupa password tidak punya cara mandiri untuk reset.

USE simmas_db;

ALTER TABLE password_reset_tokens
  MODIFY COLUMN user_id INT NULL,
  ADD COLUMN IF NOT EXISTS dudi_id INT NULL AFTER user_id;

SET @fk_exists = (
  SELECT COUNT(*) FROM information_schema.TABLE_CONSTRAINTS
  WHERE CONSTRAINT_SCHEMA = 'simmas_db'
    AND TABLE_NAME = 'password_reset_tokens'
    AND CONSTRAINT_NAME = 'prt_ibfk_dudi_id'
);
SET @sql := IF(@fk_exists = 0,
  'ALTER TABLE password_reset_tokens ADD CONSTRAINT prt_ibfk_dudi_id FOREIGN KEY (dudi_id) REFERENCES dudi(id) ON DELETE CASCADE',
  'SELECT "Constraint prt_ibfk_dudi_id sudah ada, dilewati."'
);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;
