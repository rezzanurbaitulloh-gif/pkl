-- ============================================================
-- MIGRATION: Fitur Cetak Sertifikat Magang (PKL)
-- Jalankan query ini di database simmas_db yang SUDAH ADA agar sinkron
-- dengan kode aplikasi terbaru (untuk fresh install, semua ini sudah
-- termasuk di schema.sql — jalankan `npm run db:init` saja).
--
-- File ini idempotent: aman dijalankan berulang kali.
-- ============================================================

USE simmas_db;

-- 1. Kolom sertifikat & data siswa tambahan yang dibutuhkan saat generate PDF
--    (lihat src/app/api/sertifikat/[id]/route.js)
ALTER TABLE school_settings
  ADD COLUMN IF NOT EXISTS sertifikat_template VARCHAR(255) DEFAULT '' AFTER logo_url,
  ADD COLUMN IF NOT EXISTS sertifikat_format_nomor VARCHAR(100) DEFAULT 'SKT/{urutan}/{tahun}' AFTER sertifikat_template,
  ADD COLUMN IF NOT EXISTS sertifikat_counter INT DEFAULT 0 AFTER sertifikat_format_nomor;

ALTER TABLE siswa
  ADD COLUMN IF NOT EXISTS nisn VARCHAR(20) NULL AFTER nis,
  ADD COLUMN IF NOT EXISTS tempat_lahir VARCHAR(100) NULL AFTER jurusan,
  ADD COLUMN IF NOT EXISTS tanggal_lahir DATE NULL AFTER tempat_lahir;

ALTER TABLE magang
  ADD COLUMN IF NOT EXISTS nomor_sertifikat VARCHAR(50) DEFAULT NULL AFTER nilai_dudi,
  ADD COLUMN IF NOT EXISTS sertifikat_generated_at DATETIME DEFAULT NULL AFTER nomor_sertifikat;

ALTER TABLE pendaftaran
  ADD COLUMN IF NOT EXISTS catatan TEXT NULL;

-- 2. Tabel konfigurasi posisi field sertifikat.
--    PENTING: nama kolom di bawah ini HARUS sama persis dengan yang dipakai
--    src/app/admin/settings/page.js & src/app/api/sertifikat/[id]/route.js
--    (nama, ttl, nisn, kompetensi, sekolah, deskripsi, kepsek, pimpinan, nomor).
--    Jika database Anda sebelumnya memakai versi lama migrasi ini (dengan
--    kolom field_nis/field_kelas/field_dudi/field_tanggal_mulai/dst), hapus
--    dahulu tabel lama tersebut sebelum menjalankan migrasi ini:
--      DROP TABLE IF EXISTS sertifikat_config;
CREATE TABLE IF NOT EXISTS sertifikat_config (
  id INT PRIMARY KEY DEFAULT 1,
  field_nama_x FLOAT DEFAULT 50,         field_nama_y FLOAT DEFAULT 38,         field_nama_size INT DEFAULT 26,         field_nama_color VARCHAR(7) DEFAULT '#1a1a1a',
  field_ttl_x FLOAT DEFAULT 50,          field_ttl_y FLOAT DEFAULT 47,          field_ttl_size INT DEFAULT 14,          field_ttl_color VARCHAR(7) DEFAULT '#333333',
  field_nisn_x FLOAT DEFAULT 50,         field_nisn_y FLOAT DEFAULT 52,         field_nisn_size INT DEFAULT 14,         field_nisn_color VARCHAR(7) DEFAULT '#333333',
  field_kompetensi_x FLOAT DEFAULT 50,   field_kompetensi_y FLOAT DEFAULT 57,   field_kompetensi_size INT DEFAULT 14,   field_kompetensi_color VARCHAR(7) DEFAULT '#333333',
  field_sekolah_x FLOAT DEFAULT 50,      field_sekolah_y FLOAT DEFAULT 62,      field_sekolah_size INT DEFAULT 14,      field_sekolah_color VARCHAR(7) DEFAULT '#333333',
  field_deskripsi_x FLOAT DEFAULT 50,    field_deskripsi_y FLOAT DEFAULT 68,    field_deskripsi_size INT DEFAULT 13,    field_deskripsi_color VARCHAR(7) DEFAULT '#333333',
  field_kepsek_x FLOAT DEFAULT 25,       field_kepsek_y FLOAT DEFAULT 85,       field_kepsek_size INT DEFAULT 13,       field_kepsek_color VARCHAR(7) DEFAULT '#1a1a1a',
  field_pimpinan_x FLOAT DEFAULT 75,     field_pimpinan_y FLOAT DEFAULT 85,     field_pimpinan_size INT DEFAULT 13,     field_pimpinan_color VARCHAR(7) DEFAULT '#1a1a1a',
  field_nomor_x FLOAT DEFAULT 50,        field_nomor_y FLOAT DEFAULT 18,        field_nomor_size INT DEFAULT 11,        field_nomor_color VARCHAR(7) DEFAULT '#666666',
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Insert default config jika belum ada
INSERT IGNORE INTO sertifikat_config (id) VALUES (1);
