-- ============================================================
-- SIMMAS - Sistem Manajemen Magang Siswa
-- Skema database MySQL untuk semua role (Admin, Guru, Siswa)
-- ============================================================

DROP DATABASE IF EXISTS simmas_db;
CREATE DATABASE IF NOT EXISTS simmas_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE simmas_db;

CREATE TABLE IF NOT EXISTS users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nama VARCHAR(150) NOT NULL,
  email VARCHAR(150) NOT NULL UNIQUE,
  password VARCHAR(255) NOT NULL,
  role ENUM('admin','guru','siswa') NOT NULL DEFAULT 'siswa',
  verified BOOLEAN DEFAULT TRUE,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS activity_logs (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NULL,
  user_nama VARCHAR(150) NOT NULL,
  role VARCHAR(20) NOT NULL,
  action VARCHAR(50) NOT NULL,
  description VARCHAR(255) NOT NULL,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS school_settings (
  id INT PRIMARY KEY DEFAULT 1,
  nama VARCHAR(150) NOT NULL DEFAULT 'SMK Negeri 1 Surabaya',
  alamat VARCHAR(255) DEFAULT '',
  telepon VARCHAR(30) DEFAULT '',
  email VARCHAR(150) DEFAULT '',
  website VARCHAR(150) DEFAULT '',
  kepala VARCHAR(150) DEFAULT '',
  npsn VARCHAR(30) DEFAULT '',
  logo_url VARCHAR(255) DEFAULT '',
  -- Kolom berikut dipakai oleh fitur "Sertifikat Magang (PKL)" di halaman
  -- Pengaturan Admin (lihat src/app/admin/settings/page.js & src/app/api/admin/settings/sertifikat/route.js)
  sertifikat_template VARCHAR(255) DEFAULT '',
  sertifikat_format_nomor VARCHAR(100) DEFAULT 'SKT/{urutan}/{tahun}',
  sertifikat_counter INT DEFAULT 0,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

INSERT INTO school_settings (id, nama, alamat, telepon, email, website, kepala, npsn, logo_url) VALUES
(1, 'SMK Negeri 1 Surabaya', 'Jl. SMEA No.4, Sawahan, Kec. Sawahan, Kota Surabaya, Jawa Timur 60252', '031-5678910', 'info@smkn1surabaya.sch.id', 'www.smkn1surabaya.sch.id', 'Drs. H. Sutrisno, M.Pd', '20567890', '');

-- user_id menghubungkan baris guru ke akun login di tabel `users` secara
-- eksplisit lewat ID (bukan lagi lewat pencocokan string email yang rapuh).
-- Lihat catatan Bug #4 pada laporan pengujian: sebelumnya getCurrentGuru()
-- melakukan JOIN guru.email = users.email, sehingga begitu email salah satu
-- tabel diubah sendiri-sendiri (lewat menu Manajemen Siswa/Guru ATAU lewat
-- menu Manajemen Pengguna), sesi guru bisa "kehilangan" guru.id-nya.
CREATE TABLE IF NOT EXISTS guru (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NULL,
  nip VARCHAR(30) NOT NULL,
  nama VARCHAR(150) NOT NULL,
  mapel VARCHAR(150),
  email VARCHAR(150),
  telepon VARCHAR(30),
  status VARCHAR(20) DEFAULT 'aktif',
  alamat VARCHAR(255),
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS dudi (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nama VARCHAR(150) NOT NULL,
  alamat VARCHAR(255),
  telepon VARCHAR(30),
  email VARCHAR(150),
  penanggung_jawab VARCHAR(150),
  status VARCHAR(20) DEFAULT 'aktif',
  login_email VARCHAR(150) NULL UNIQUE,
  login_password VARCHAR(255) NULL
);

-- Token untuk fitur lupa password. Satu token hanya berlaku sekali (used_at)
-- dan punya batas waktu kedaluwarsa (expires_at).
-- Perbaikan Bug #10: sebelumnya tabel ini hanya punya user_id (NOT NULL),
-- sehingga akun DUDI (yang login lewat dudi.login_email, BUKAN lewat tabel
-- users) tidak bisa memakai fitur lupa password sama sekali. Sekarang
-- user_id dibuat nullable dan ditambah kolom dudi_id nullable — setiap
-- baris token harus mengisi TEPAT SALAH SATU dari keduanya (divalidasi di
-- level aplikasi pada src/app/api/auth/forgot-password/route.js).
--
-- Catatan urutan: tabel ini SENGAJA didefinisikan SETELAH tabel `dudi`
-- (bukan di dekat `users`/`activity_logs` di atas) karena foreign key
-- `dudi_id` di bawah ini butuh tabel `dudi` SUDAH ada lebih dulu — MySQL
-- akan menolak CREATE TABLE dengan error #1824 "Failed to open the
-- referenced table" jika urutannya terbalik.
CREATE TABLE IF NOT EXISTS password_reset_tokens (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NULL,
  dudi_id INT NULL,
  token VARCHAR(255) NOT NULL UNIQUE,
  expires_at DATETIME NOT NULL,
  used_at DATETIME NULL,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (dudi_id) REFERENCES dudi(id) ON DELETE CASCADE
);

-- user_id bisa NULL untuk siswa yang belum punya akun user
CREATE TABLE IF NOT EXISTS siswa (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NULL,
  nis VARCHAR(20) NOT NULL UNIQUE,
  nisn VARCHAR(20) NULL,
  nama VARCHAR(150) NOT NULL,
  kelas VARCHAR(10),
  jurusan VARCHAR(50),
  tempat_lahir VARCHAR(100) NULL,
  tanggal_lahir DATE NULL,
  email VARCHAR(150),
  telepon VARCHAR(30),
  alamat VARCHAR(255),
  status VARCHAR(20) DEFAULT 'aktif',
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS magang (
  id INT AUTO_INCREMENT PRIMARY KEY,
  siswa_id INT NOT NULL,
  dudi_id INT,
  guru_id INT,
  status VARCHAR(20) DEFAULT 'aktif',
  tanggal_mulai DATE,
  tanggal_selesai DATE,
  catatan TEXT,
  nilai INT,
  diberhentikan BOOLEAN DEFAULT FALSE,
  tanggal_berhenti DATE NULL,
  alasan_berhenti TEXT NULL,
  catatan_dudi TEXT NULL,
  nilai_dudi INT NULL,
  -- Dipakai oleh fitur cetak sertifikat PKL (src/app/api/sertifikat/[id]/route.js)
  nomor_sertifikat VARCHAR(50) NULL,
  sertifikat_generated_at DATETIME NULL,
  FOREIGN KEY (siswa_id) REFERENCES siswa(id) ON DELETE CASCADE,
  FOREIGN KEY (dudi_id) REFERENCES dudi(id) ON DELETE SET NULL,
  FOREIGN KEY (guru_id) REFERENCES guru(id) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS jurnal (
  id INT AUTO_INCREMENT PRIMARY KEY,
  siswa_id INT NOT NULL,
  guru_id INT,
  tanggal DATE NOT NULL,
  kegiatan TEXT NOT NULL,
  kendala TEXT,
  file_path VARCHAR(255),
  file_name VARCHAR(255),
  status ENUM('menunggu','disetujui','ditolak') DEFAULT 'menunggu',
  catatan_guru TEXT,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (siswa_id) REFERENCES siswa(id) ON DELETE CASCADE,
  FOREIGN KEY (guru_id) REFERENCES guru(id) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS pendaftaran (
  id INT AUTO_INCREMENT PRIMARY KEY,
  siswa_id INT NOT NULL,
  dudi_id INT NOT NULL,
  guru_id INT NOT NULL,
  status ENUM('pending','diterima','ditolak') DEFAULT 'pending',
  tanggal_daftar DATE NOT NULL,
  -- Diisi otomatis oleh sistem saat pendaftaran lain ditolak otomatis
  -- (siswa diterima di tempat magang lain) — lihat src/app/api/guru/pendaftaran/[id]/route.js
  catatan TEXT NULL,
  FOREIGN KEY (siswa_id) REFERENCES siswa(id) ON DELETE CASCADE,
  FOREIGN KEY (dudi_id) REFERENCES dudi(id) ON DELETE CASCADE,
  FOREIGN KEY (guru_id) REFERENCES guru(id) ON DELETE CASCADE
);

-- Konfigurasi posisi & gaya tiap field teks pada template sertifikat PKL.
-- Nama kolom HARUS sinkron dengan SERTIFIKAT_FIELDS di
-- src/app/admin/settings/page.js dan src/app/api/sertifikat/[id]/route.js
CREATE TABLE IF NOT EXISTS sertifikat_config (
  id INT PRIMARY KEY DEFAULT 1,
  -- Posisi (persen dari ukuran gambar) dan ukuran font tiap field (pt)
  field_nama_x FLOAT DEFAULT 50,         field_nama_y FLOAT DEFAULT 38,         field_nama_size INT DEFAULT 26,         field_nama_color VARCHAR(7) DEFAULT '#1a1a1a',
  field_ttl_x FLOAT DEFAULT 50,          field_ttl_y FLOAT DEFAULT 47,          field_ttl_size INT DEFAULT 14,          field_ttl_color VARCHAR(7) DEFAULT '#333333',
  field_nisn_x FLOAT DEFAULT 50,         field_nisn_y FLOAT DEFAULT 52,         field_nisn_size INT DEFAULT 14,         field_nisn_color VARCHAR(7) DEFAULT '#333333',
  field_kompetensi_x FLOAT DEFAULT 50,   field_kompetensi_y FLOAT DEFAULT 57,   field_kompetensi_size INT DEFAULT 14,   field_kompetensi_color VARCHAR(7) DEFAULT '#333333',
  field_sekolah_x FLOAT DEFAULT 50,      field_sekolah_y FLOAT DEFAULT 62,      field_sekolah_size INT DEFAULT 14,      field_sekolah_color VARCHAR(7) DEFAULT '#333333',
  field_deskripsi_x FLOAT DEFAULT 50,    field_deskripsi_y FLOAT DEFAULT 68,    field_deskripsi_size INT DEFAULT 13,    field_deskripsi_color VARCHAR(7) DEFAULT '#333333',
  field_kepsek_x FLOAT DEFAULT 25,       field_kepsek_y FLOAT DEFAULT 85,       field_kepsek_size INT DEFAULT 13,       field_kepsek_color VARCHAR(7) DEFAULT '#1a1a1a',
  field_pimpinan_x FLOAT DEFAULT 75,     field_pimpinan_y FLOAT DEFAULT 85,     field_pimpinan_size INT DEFAULT 13,     field_pimpinan_color VARCHAR(7) DEFAULT '#1a1a1a',
  field_nomor_x FLOAT DEFAULT 50,        field_nomor_y FLOAT DEFAULT 18,        field_nomor_size INT DEFAULT 11,        field_nomor_color VARCHAR(7) DEFAULT '#666666',
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

INSERT INTO sertifikat_config (id) VALUES (1);

-- ============================================================
-- SEED DATA
-- ============================================================

-- Catatan: semua password seed di bawah adalah hash bcrypt dari "123"
-- (lihat README untuk daftar akun demo). JANGAN menyimpan password polos
-- di kolom ini — gunakan src/lib/password.js (hashPassword) saat membuat
-- atau mengubah password user dari kode aplikasi.
INSERT INTO users (id, nama, email, password, role) VALUES
(1, 'Admin Sistem',        'admin@gmail.com',           '$2b$10$rOmT0L5a8H0ncsn5HeDyt.WIBg4uwkvQbiHkWtuT29gI07TB4KUC2', 'admin'),
(2, 'Suryanto, S.Pd',      'suryanto@teacher.com',      '$2b$10$rOmT0L5a8H0ncsn5HeDyt.WIBg4uwkvQbiHkWtuT29gI07TB4KUC2', 'guru'),
(3, 'Kartika Sari, S.Kom', 'kartika@teacher.com',       '$2b$10$rOmT0L5a8H0ncsn5HeDyt.WIBg4uwkvQbiHkWtuT29gI07TB4KUC2', 'guru'),
(4, 'Ahmad Rizki Ramadhan','ahmad.rizki@student.sch.id','$2b$10$rOmT0L5a8H0ncsn5HeDyt.WIBg4uwkvQbiHkWtuT29gI07TB4KUC2', 'siswa'),
(5, 'Siti Nurhaliza',      'siti.nur@student.sch.id',   '$2b$10$rOmT0L5a8H0ncsn5HeDyt.WIBg4uwkvQbiHkWtuT29gI07TB4KUC2', 'siswa'),
(6, 'Fajar Pratama',       'fajar@student.sch.id',      '$2b$10$rOmT0L5a8H0ncsn5HeDyt.WIBg4uwkvQbiHkWtuT29gI07TB4KUC2', 'siswa');

-- Guru id 1 & 2 punya akun login (user_id terisi merujuk ke tabel users di
-- atas); guru id 3-5 belum punya akun login (user_id NULL), hanya data
-- administratif — sama seperti pola yang sudah dipakai tabel `siswa`.
INSERT INTO guru (id, user_id, nip, nama, mapel, email, telepon, status, alamat) VALUES
(1,2,'197501012000031001','Suryanto, S.Pd',      'Pemrograman Web & Mobile',       'suryanto@teacher.com',  '081234567800','aktif','Jl. Raya No. 1 Surabaya'),
(2,3,'198002052005012002','Kartika Sari, S.Kom', 'Basis Data & Sistem Informasi',  'kartika@teacher.com',   '081234567801','aktif','Jl. Raya No. 2 Surabaya'),
(3,NULL,'198505152010011003','Agus Wahyudi, S.T',   'Jaringan Komputer',              'agus@teacher.sch.id',   '081234567802','aktif','Jl. Raya No. 3 Surabaya'),
(4,NULL,'199003202015012004','Rina Puspitasari, S.Pd','Desain Grafis & Multimedia',  'rina@teacher.sch.id',   '081234567803','aktif','Jl. Raya No. 4 Surabaya'),
(5,NULL,'198812252012011005','Bambang Priyanto, S.Kom','Pemrograman Desktop & Game', 'bambang@teacher.sch.id','081234567804','aktif','Jl. Raya No. 5 Surabaya');

INSERT INTO dudi (id, nama, alamat, telepon, email, penanggung_jawab, status) VALUES
(1,'PT. Teknologi Nusantara',    'Jl. HR Muhammad No. 123, Surabaya','031-5551234','info@teknusa.co.id',          'Budi Santoso','aktif'),
(2,'CV. Digital Kreativa',       'Jl. Pemuda No. 45, Surabaya',      '031-5557890','contact@digitalkreativa.co.id','Maya Sari',   'aktif'),
(3,'PT. Inovasi Mandiri',        'Jl. Diponegoro No. 78, Surabaya',  '031-5553456','hr@inovasimandiri.co.id',      'Andi Wijaya', 'aktif'),
(4,'PT. Media Interaktif',       'Jl. Basuki Rahmat No. 90, Surabaya','031-5552345','info@mediainteraktif.co.id',  'Siti Aminah', 'aktif'),
(5,'CV. Solusi Digital Indonesia','Jl. Ahmad Yani No. 67, Surabaya', '031-5556789','contact@solusidigital.id',    'Rahman Hakim','aktif');

-- Siswa id 3,4,5 tidak punya akun login (user_id NULL), hanya data administratif
INSERT INTO siswa (id, user_id, nis, nama, kelas, jurusan, email, telepon, alamat, status) VALUES
(1,4,'2021001','Ahmad Rizki Ramadhan','XII','RPL','ahmad.rizki@student.sch.id','081234567890','Jl. Siswa No. 1 Surabaya','magang'),
(2,5,'2021002','Siti Nurhaliza',      'XII','RPL','siti.nur@student.sch.id',  '081234567891','Jl. Siswa No. 2 Surabaya','magang'),
(3,NULL,'2021003','Budi Santoso',     'XII','TKJ','budi@student.sch.id',      '081234567892','Jl. Siswa No. 3 Surabaya','magang'),
(4,NULL,'2021004','Dewi Lestari',     'XI', 'RPL','dewi@student.sch.id',      '081234567893','Jl. Siswa No. 4 Surabaya','selesai'),
(5,NULL,'2021005','Eko Prasetyo',     'XI', 'TKJ','eko@student.sch.id',       '081234567894','Jl. Siswa No. 5 Surabaya','aktif'),
(6,6,'2021006','Fajar Pratama',       'XI', 'RPL','fajar@student.sch.id',     '081234567895','Jl. Siswa No. 6 Surabaya','aktif');

INSERT INTO magang (id, siswa_id, dudi_id, guru_id, status, tanggal_mulai, tanggal_selesai, catatan, nilai) VALUES
(1,1,1,1,'aktif',   '2024-07-01','2024-09-30','',NULL),
(2,2,2,1,'aktif',   '2024-07-01','2024-09-30','',NULL),
(3,3,3,2,'aktif',   '2024-07-01','2024-09-30','',NULL),
(4,4,4,1,'selesai', '2024-06-15','2024-09-15','',88),
(5,5,5,2,'aktif',   '2024-08-01','2024-10-31','',NULL);

INSERT INTO jurnal (id, siswa_id, guru_id, tanggal, kegiatan, kendala, status, catatan_guru) VALUES
(1,1,1,'2024-07-21','Mempelajari sistem database dan melakukan backup data harian','','disetujui','Bagus, lanjutkan dengan implementasi'),
(2,2,1,'2024-07-21','Membuat design mockup untuk website perusahaan','Software design masih belum familiar','menunggu',''),
(3,1,1,'2024-07-20','Mengikuti training keamanan sistem informasi','Materi terlalu teknis','ditolak','Perlu diperdalam lagi'),
(4,2,1,'2024-07-17','Implementasi form validation dan state management menggunakan React Hook Form','Belum memahami konsep controlled vs uncontrolled components','menunggu',''),
(5,4,1,'2024-07-10','Debugging dan testing aplikasi mobile','Ditemukan beberapa bug pada fitur notifikasi push','disetujui','Kerja bagus, dokumentasi lengkap');

INSERT INTO pendaftaran (id, siswa_id, dudi_id, guru_id, status, tanggal_daftar) VALUES
(1,6,1,1,'pending',CURDATE());

-- ============================================================
-- MIGRATION: Tambah kolom diberhentikan pada tabel magang
-- Jalankan query ini jika database sudah ada sebelumnya
-- ============================================================
-- ALTER TABLE magang ADD COLUMN IF NOT EXISTS diberhentikan BOOLEAN DEFAULT FALSE;
-- ALTER TABLE magang ADD COLUMN IF NOT EXISTS tanggal_berhenti DATE NULL;
-- ALTER TABLE magang ADD COLUMN IF NOT EXISTS alasan_berhenti TEXT NULL;
-- ALTER TABLE magang ADD COLUMN IF NOT EXISTS nilai INT NULL;
