-- ============================================================
-- MIGRATION: Fitur Cetak Sertifikat Magang (UPDATE v2)
-- Kompatibel dengan MySQL 5.7+ dan MariaDB
-- ============================================================

USE simmas_db;

-- ─── 1. Tambah kolom data siswa yang belum ada ───
ALTER TABLE siswa ADD COLUMN nisn VARCHAR(20) DEFAULT NULL AFTER nis;
ALTER TABLE siswa ADD COLUMN tempat_lahir VARCHAR(100) DEFAULT NULL AFTER nisn;
ALTER TABLE siswa ADD COLUMN tanggal_lahir DATE DEFAULT NULL AFTER tempat_lahir;

-- ─── 2. Tambah kolom sertifikat di school_settings ───
ALTER TABLE school_settings ADD COLUMN sertifikat_template VARCHAR(255) DEFAULT '' AFTER logo_url;
ALTER TABLE school_settings ADD COLUMN sertifikat_format_nomor VARCHAR(100) DEFAULT 'SKT/{urutan}/{tahun}' AFTER sertifikat_template;
ALTER TABLE school_settings ADD COLUMN sertifikat_counter INT DEFAULT 0 AFTER sertifikat_format_nomor;

-- ─── 3. Tabel konfigurasi posisi field sertifikat ───
CREATE TABLE IF NOT EXISTS sertifikat_config (
  id INT PRIMARY KEY DEFAULT 1,

  -- Nama siswa (bold besar di tengah)
  field_nama_x         FLOAT DEFAULT 50,
  field_nama_y         FLOAT DEFAULT 38,
  field_nama_size      INT   DEFAULT 26,
  field_nama_color     VARCHAR(7) DEFAULT '#1a1a1a',

  -- Tempat, tanggal lahir
  field_ttl_x          FLOAT DEFAULT 50,
  field_ttl_y          FLOAT DEFAULT 47,
  field_ttl_size       INT   DEFAULT 14,
  field_ttl_color      VARCHAR(7) DEFAULT '#333333',

  -- NISN
  field_nisn_x         FLOAT DEFAULT 50,
  field_nisn_y         FLOAT DEFAULT 52,
  field_nisn_size      INT   DEFAULT 14,
  field_nisn_color     VARCHAR(7) DEFAULT '#333333',

  -- Kompetensi keahlian (jurusan)
  field_kompetensi_x   FLOAT DEFAULT 50,
  field_kompetensi_y   FLOAT DEFAULT 57,
  field_kompetensi_size INT  DEFAULT 14,
  field_kompetensi_color VARCHAR(7) DEFAULT '#333333',

  -- Satuan pendidikan (nama sekolah)
  field_sekolah_x      FLOAT DEFAULT 50,
  field_sekolah_y      FLOAT DEFAULT 62,
  field_sekolah_size   INT   DEFAULT 14,
  field_sekolah_color  VARCHAR(7) DEFAULT '#333333',

  -- Deskripsi pelaksanaan (kalimat narasi)
  field_deskripsi_x    FLOAT DEFAULT 50,
  field_deskripsi_y    FLOAT DEFAULT 68,
  field_deskripsi_size INT   DEFAULT 13,
  field_deskripsi_color VARCHAR(7) DEFAULT '#333333',

  -- Nama kepala sekolah (ttd kiri)
  field_kepsek_x       FLOAT DEFAULT 25,
  field_kepsek_y       FLOAT DEFAULT 85,
  field_kepsek_size    INT   DEFAULT 13,
  field_kepsek_color   VARCHAR(7) DEFAULT '#1a1a1a',

  -- Nama pimpinan DUDI (ttd kanan)
  field_pimpinan_x     FLOAT DEFAULT 75,
  field_pimpinan_y     FLOAT DEFAULT 85,
  field_pimpinan_size  INT   DEFAULT 13,
  field_pimpinan_color VARCHAR(7) DEFAULT '#1a1a1a',

  -- Nomor sertifikat (opsional, biasanya kecil di atas/bawah)
  field_nomor_x        FLOAT DEFAULT 50,
  field_nomor_y        FLOAT DEFAULT 18,
  field_nomor_size     INT   DEFAULT 11,
  field_nomor_color    VARCHAR(7) DEFAULT '#666666',

  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

INSERT IGNORE INTO sertifikat_config (id) VALUES (1);

-- ─── 4. Tambah kolom sertifikat di tabel magang ───
ALTER TABLE magang ADD COLUMN nomor_sertifikat VARCHAR(50) DEFAULT NULL AFTER nilai;
ALTER TABLE magang ADD COLUMN sertifikat_generated_at DATETIME DEFAULT NULL AFTER nomor_sertifikat;
