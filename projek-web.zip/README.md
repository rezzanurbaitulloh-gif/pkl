# SIMMAS — Sistem Manajemen Magang Siswa

Aplikasi web manajemen magang siswa SMK berbasis **Next.js 14** + **MySQL**.

---

## Persyaratan

- **Node.js** v18 atau lebih baru
- **MySQL** 5.7 / 8.x yang sudah berjalan

---

## Cara Setup & Menjalankan

### 1. Install dependensi

```bash
npm install
```

### 2. Konfigurasi database

File `.env.local` sudah disertakan dengan konfigurasi default:

```
DB_HOST=localhost
DB_PORT=3306
DB_USER=root
DB_PASSWORD=
DB_NAME=simmas_db
JWT_SECRET=simmas_rahasia_super_aman_2024
```

> Jika MySQL kamu menggunakan password, edit `DB_PASSWORD` di `.env.local`.

### 3. Inisialisasi database

Jalankan perintah berikut **sekali** untuk membuat database, tabel, dan data demo:

```bash
npm run db:init
```

### 4. Jalankan aplikasi

```bash
npm run dev
```

Buka **http://localhost:3000** di browser.

---

## Keamanan Autentikasi

- **Hash password (bcrypt).** Semua password di tabel `users` disimpan sebagai bcrypt hash (lihat `src/lib/password.js`). Tidak ada password polos yang tersimpan di database, termasuk data seed di `database/schema.sql`. Jika kamu memigrasikan database lama yang masih punya password polos, jalankan:
  ```bash
  npm run db:hash-passwords
  ```
  Script ini aman dijalankan berulang kali — password yang sudah berupa bcrypt hash otomatis dilewati.

- **Rate limiting login.** Endpoint `/api/auth/login` membatasi maksimal 5 percobaan gagal per email maupun per alamat IP dalam 15 menit (in-memory, lihat `src/lib/rateLimiter.js`). Setelah limit tercapai, server membalas status `429` dengan pesan yang menyebutkan kapan bisa mencoba lagi.

- **Lupa password.** Halaman `/forgot-password` dan `/reset-password` memungkinkan pengguna (admin/guru/siswa) mereset password sendiri:
  1. Isi email di `/forgot-password` → sistem membuat token reset (berlaku 1 jam) di tabel `password_reset_tokens`.
  2. **Catatan:** karena belum ada integrasi email asli, link reset untuk saat ini ditampilkan langsung di response halaman tersebut dan di log server (console) — bukan dikirim ke kotak masuk email pengguna. Ganti bagian ini dengan layanan email (SMTP/3rd party) sebelum digunakan secara produksi, dan saat itu juga hapus penampilan link di response agar tidak membocorkan keberadaan akun.
  3. Buka link reset → isi password baru di `/reset-password`. Token otomatis tidak berlaku lagi setelah dipakai atau kedaluwarsa.
  4. Setiap reset password berhasil tercatat di log aktivitas (`activity_logs`).

---

## Akun Demo (semua password: `123`)

| Role  | Email                        |
|-------|------------------------------|
| Admin | admin@gmail.com              |
| Guru  | suryanto@teacher.com         |
| Guru  | kartika@teacher.com          |
| Siswa | ahmad.rizki@student.sch.id   |
| Siswa | siti.nur@student.sch.id      |
| Siswa | fajar@student.sch.id         |

---

## Fitur per Role

### Admin
- Dashboard statistik
- Manajemen siswa, guru, DUDI, magang
- Manajemen pengguna
- Manajemen akun login DUDI (portal khusus perusahaan mitra)
- **Pengaturan sertifikat PKL**: upload gambar template sertifikat, atur posisi/ukuran/warna tiap teks (nama siswa, TTL, NISN, kompetensi, sekolah, deskripsi, kepala sekolah, pimpinan DUDI, nomor) langsung di atas preview template, serta atur format penomoran otomatis. Lihat menu **Pengaturan**.

### Guru
- Dashboard monitoring siswa binaan
- Review & setujui/tolak jurnal harian, termasuk **melihat lampiran (foto/dokumen) yang diunggah siswa** pada setiap jurnal
- Pantau data magang, ubah status magang (termasuk menandai "selesai" yang otomatis menerbitkan nomor sertifikat)

### Siswa
- Dashboard status magang
- Isi & kirim jurnal harian, dapat **melampirkan foto bukti kegiatan / dokumen (PDF, DOC, DOCX, JPG, PNG, maks 5MB)**
- Lihat data magang & pembimbing
- Unduh sertifikat PKL (PDF) setelah magang ditandai selesai oleh guru

---

## Struktur Folder Penting

```
src/
  app/
    login/          # Halaman login
    forgot-password/ # Halaman lupa password
    reset-password/  # Halaman reset password
    siswa/          # Halaman siswa (protected)
    guru/           # Halaman guru (protected)
    admin/          # Halaman admin (protected)
    api/            # REST API routes
  lib/
    db.js           # Koneksi MySQL pool
    auth.js         # JWT helper & getUser functions
    password.js     # Hash & verifikasi password (bcrypt)
    rateLimiter.js  # Rate limiting percobaan login
  components/       # Sidebar, Topbar, Badge, dsb.
database/
  schema.sql        # DDL + seed data (password sudah berupa bcrypt hash)
  init-db.js        # Script inisialisasi DB
  hash-passwords.js # Migration: hash ulang password lama yang masih plain text
middleware.js       # Route protection & role guard
.env.local          # Konfigurasi environment (sudah ada)
```

---

## Troubleshooting

**"Tidak dapat terhubung ke MySQL"**
→ Pastikan MySQL server sudah berjalan. Cek `DB_HOST`, `DB_PORT`, `DB_USER`, `DB_PASSWORD` di `.env.local`.

**"Database belum ditemukan"**
→ Jalankan `npm run db:init`.

**"Email atau password salah"**
→ Pastikan sudah menjalankan `npm run db:init` dan gunakan akun demo di atas.

**Login berhasil tapi langsung ke /login lagi**
→ Jalankan ulang `npm run db:init` dan restart server (`Ctrl+C` lalu `npm run dev`).

**"Terlalu banyak percobaan login gagal..." (status 429)**
→ Rate limit login tercapai (5x gagal dalam 15 menit, dihitung per email & per IP). Tunggu sesuai waktu yang ditampilkan, atau restart server untuk mengosongkan counter (in-memory).

**Lupa password akun demo**
→ Gunakan `/forgot-password`, link reset akan muncul di response halaman tersebut dan di log terminal server (lihat penjelasan di bagian "Keamanan Autentikasi").

**"Unknown column 'login_email' in 'where clause'" saat login**
→ Database kamu dibuat dari versi `schema.sql` lama sebelum kolom `login_email`/`login_password` (tabel `dudi`) dan `catatan_dudi`/`nilai_dudi` (tabel `magang`) ditambahkan. Jalankan ulang `npm run db:init` (fresh install, paling mudah), atau jika tidak ingin menghapus data yang sudah ada, jalankan `mysql -u root -p simmas_db < database/migration-dudi-login.sql`.

**"Unknown column 'nisn'/'tempat_lahir'/'sertifikat_template'/'nomor_sertifikat'" atau "Table 'sertifikat_config' doesn't exist"**
→ Database kamu dibuat sebelum fitur sertifikat PKL ditambahkan. Jalankan ulang `npm run db:init` (fresh install), atau jika ingin mempertahankan data yang sudah ada, jalankan `mysql -u root -p simmas_db < database/migration-sertifikat.sql`.
