import { NextResponse } from "next/server";
import { getCurrentAdmin } from "@/lib/auth";
import { query } from "@/lib/db";
import { logActivity } from "@/lib/activityLog";
import { withErrorHandler } from "@/lib/apiHandler";
import { stopMagang } from "@/lib/magang";

// POST /api/admin/magang/[id]/berhenti
// Memberhentikan siswa dari magang sebelum masa magang selesai
async function __POST(req, { params }) {
  const admin = await getCurrentAdmin();
  if (!admin) return NextResponse.json({ message: "Unauthorized" }, { status: 401 });

  const { alasan_berhenti } = await req.json();

  const rows = await query(
    `SELECT m.*, s.nama as siswa_nama, d.nama as dudi_nama
     FROM magang m
     LEFT JOIN siswa s ON s.id = m.siswa_id
     LEFT JOIN dudi d ON d.id = m.dudi_id
     WHERE m.id = ?`,
    [params.id]
  );
  const magang = rows[0];
  if (!magang) return NextResponse.json({ message: "Data magang tidak ditemukan" }, { status: 404 });
  if (magang.status !== "aktif") {
    return NextResponse.json({ message: "Magang ini sudah tidak aktif" }, { status: 400 });
  }
  if (magang.diberhentikan) {
    return NextResponse.json({ message: "Siswa ini sudah diberhentikan sebelumnya" }, { status: 400 });
  }

  // Tandai diberhentikan, ubah status ke 'dibatalkan' (konsisten dengan status
  // yang dipakai di seluruh aplikasi — lihat Badge.js, admin/magang/page.js,
  // dan banner pemberhentian di siswa/magang/MagangClient.js yang hanya
  // mengecek status 'dibatalkan'). catatan diisi juga supaya alasan
  // pemberhentian ini ditampilkan ke siswa seperti pada alur guru.
  // Memakai helper stopMagang() yang dipakai bersama dengan jalur guru,
  // supaya field diberhentikan/tanggal_berhenti/alasan_berhenti selalu
  // konsisten siapapun yang melakukan aksinya (lihat Bug #6).
  await stopMagang(params.id, alasan_berhenti);

  // Reset status siswa agar bisa daftar ulang
  await query("UPDATE siswa SET status='aktif' WHERE id = ?", [magang.siswa_id]);

  await logActivity(
    { id: admin.id, nama: admin.nama, role: "admin" },
    "update",
    `${admin.nama} memberhentikan ${magang.siswa_nama} dari magang di ${magang.dudi_nama}${alasan_berhenti ? ": " + alasan_berhenti : ""}`
  );

  return NextResponse.json({ message: "Siswa berhasil diberhentikan dari magang. Siswa dapat mendaftar ulang." });
}
export const POST = withErrorHandler(__POST);

