import { NextResponse } from "next/server";
import { getCurrentGuru, resolveGuruId } from "@/lib/auth";
import { query } from "@/lib/db";
import { logActivity } from "@/lib/activityLog";
import { withErrorHandler } from "@/lib/apiHandler";

async function __PUT(req, { params }) {
  const guru = await getCurrentGuru();
  if (!guru) return NextResponse.json({ message: "Unauthorized" }, { status: 401 });

  // Perbaikan Bug #3 (IDOR): sebelumnya query di bawah ini TIDAK membatasi
  // kepemilikan sama sekali — guru manapun bisa menyetujui/menolak jurnal
  // siswa bimbingan guru lain. Pola perbaikan ini disamakan dengan
  // `src/app/api/dudi/magang/[id]/route.js` dan
  // `src/app/api/guru/pendaftaran/[id]/route.js`: jurnal hanya bisa diubah
  // jika siswa pemilik jurnal tsb sedang dibimbing (lewat data magang AKTIF)
  // oleh guru yang sedang login.
  const guruId = await resolveGuruId(guru);
  if (!guruId) return NextResponse.json({ message: "Data guru tidak ditemukan" }, { status: 404 });

  const body = await req.json();
  const { status, catatan_guru } = body;

  const jurnalRows = await query(
    `SELECT j.id, j.siswa_id, j.tanggal, s.nama as siswa_nama
     FROM jurnal j
     LEFT JOIN siswa s ON s.id = j.siswa_id
     WHERE j.id = ?
       AND j.siswa_id IN (
         SELECT siswa_id FROM magang WHERE guru_id = ? AND status = 'aktif'
       )`,
    [params.id, guruId]
  );
  const jurnal = jurnalRows[0];
  if (!jurnal) {
    return NextResponse.json(
      { message: "Jurnal tidak ditemukan atau bukan milik siswa bimbingan Anda." },
      { status: 404 }
    );
  }

  await query("UPDATE jurnal SET status=?, catatan_guru=? WHERE id=?", [status, catatan_guru||"", params.id]);

  await logActivity(
    { id: guru.id, nama: guru.nama, role: "guru" },
    status === "disetujui" ? "approve" : status === "ditolak" ? "reject" : "update",
    `${guru.nama} ${status === "disetujui" ? "menyetujui" : status === "ditolak" ? "menolak" : "memperbarui"} jurnal ${jurnal.siswa_nama || "siswa"} tanggal ${jurnal.tanggal || "-"}`
  );

  return NextResponse.json({ message: "Berhasil diperbarui" });
}
export const PUT = withErrorHandler(__PUT);

