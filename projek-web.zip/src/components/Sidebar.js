"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useSchoolInfo } from "@/lib/useSchoolInfo";

const navItems = [
  { href: "/siswa/dashboard", icon: "📊", label: "Dashboard", sub: "Ringkasan aktivitas" },
  { href: "/siswa/jurnal", icon: "📖", label: "Jurnal Harian", sub: "Catatan harian" },
  { href: "/siswa/magang", icon: "🎓", label: "Magang", sub: "Data magang saya" },
];

export default function Sidebar({ schoolName, isOpen, onClose }) {
  const pathname = usePathname();
  // schoolName sudah berasal dari database (dikirim dari layout.js server
  // component), dipakai sebagai initial agar tidak ada flash nama yang
  // salah sebelum useSchoolInfo() selesai fetch ulang dari /api/settings.
  const school = useSchoolInfo(schoolName ? { nama: schoolName } : null);
  const displayName = school?.nama || schoolName;
  const logoUrl = school?.logo_url;

  return (
    <>
      {isOpen && (
        <div className="sidebar-overlay" onClick={onClose} />
      )}
      <div className={`sidebar ${isOpen ? "sidebar-open" : ""}`}>
        <div className="sidebar-logo">
          <h1>SIMMAS</h1>
          <p>Panel Siswa</p>
        </div>
        <div className="sidebar-school">
          {logoUrl && <img src={logoUrl} alt="Logo Sekolah" className="sidebar-school-img" />}
          <div className="sidebar-school-text">
            <strong>{displayName}</strong>
            <p>Sistem Manajemen Magang Siswa</p>
          </div>
        </div>
        <nav className="sidebar-nav">
          {navItems.map((item) => (
            <Link
              key={item.href}
              href={item.href}
              onClick={onClose}
              className={`nav-item ${pathname?.startsWith(item.href) ? "active" : ""}`}
            >
              <span className="nav-icon">{item.icon}</span>
              <div className="nav-label">
                <span>{item.label}</span>
                <small>{item.sub}</small>
              </div>
            </Link>
          ))}
        </nav>
        <div className="sidebar-footer">
          UKK SMK Project
          <br />
          Powered by UBIG
        </div>
      </div>
    </>
  );
}
