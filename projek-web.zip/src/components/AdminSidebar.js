"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useSchoolInfo } from "@/lib/useSchoolInfo";

const navItems = [
  { href: "/admin/dashboard", icon: "📊", label: "Dashboard", sub: "Ringkasan sistem" },
  { href: "/admin/siswa", icon: "👤", label: "Siswa", sub: "Manajemen siswa" },
  { href: "/admin/guru", icon: "👨‍🏫", label: "Guru", sub: "Manajemen guru" },
  { href: "/admin/dudi", icon: "🏢", label: "DUDI", sub: "Perusahaan mitra" },
  { href: "/admin/magang", icon: "🎓", label: "Magang", sub: "Penempatan magang" },
  { href: "/admin/pengguna", icon: "👥", label: "Pengguna", sub: "Manajemen user" },
  { href: "/admin/activity-logs", icon: "🕘", label: "Activity Logs", sub: "Riwayat aktivitas" },
  { href: "/admin/settings", icon: "⚙️", label: "Pengaturan", sub: "Konfigurasi sistem" },
];

export default function AdminSidebar({ schoolName, isOpen, onClose }) {
  const pathname = usePathname();
  // schoolName di sini sudah berasal dari database (lihat src/app/admin/layout.js),
  // dipakai sebagai initial agar tidak ada flash nama yang salah sebelum
  // useSchoolInfo() selesai fetch ulang dari /api/settings.
  const school = useSchoolInfo(schoolName ? { nama: schoolName } : null);
  const displayName = school?.nama || schoolName;
  const logoUrl = school?.logo_url;

  return (
    <>
      {/* Overlay for mobile */}
      {isOpen && (
        <div className="sidebar-overlay" onClick={onClose} />
      )}
      <div className={`sidebar ${isOpen ? "sidebar-open" : ""}`}>
        <div className="sidebar-logo">
          <h1>SIMMAS</h1>
          <p>Panel Admin</p>
        </div>
        <div className="sidebar-school">
          {logoUrl && <img src={logoUrl} alt="Logo Sekolah" className="sidebar-school-img" />}
          <div className="sidebar-school-text">
            <strong>{displayName}</strong>
            <p>Sistem Manajemen Magang Siswa</p>
          </div>
        </div>
        <nav className="sidebar-nav">
          {navItems.map((item) => (
            <Link
              key={item.href}
              href={item.href}
              onClick={onClose}
              className={`nav-item ${pathname?.startsWith(item.href) ? "active" : ""}`}
            >
              <span className="nav-icon">{item.icon}</span>
              <div className="nav-label">
                <span>{item.label}</span>
                <small>{item.sub}</small>
              </div>
            </Link>
          ))}
        </nav>
        <div className="sidebar-footer">
          UKK SMK Project
          <br />
          Powered by REJAKK
        </div>
      </div>
    </>
  );
}
